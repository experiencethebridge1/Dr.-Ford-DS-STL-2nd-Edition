#ifndef BOUNDED_STACK_CLASS
#define BOUNDED_STACK_CLASS

#include "d_except.h"

// number of elements in the array that implements the stack.
// value is global, and so it is accessible to any calling block and to
// all bstack objects, independent of their type
const int MAXSTACKSIZE = 50;

template <typename T>
class bstack
{
	public:
		bstack();
			// constructor. create an empty stack
  
		void push(const T& item);
			// push item onto the top of the stack.
			// Precondition: stack not full.
			// throws overflowError exception if stack is full.
			// Postcondition: the stack has a new topmost element and
			// the stack size increases by 1

		void pop();
			// remove the item from the top of the stack.
			// Precondition: the stack is not empty.
			// if the stack is empty, the function throws
			// the underflowError exception

		T& top();
			// return a reference to the element on the top
			// of the stack.
			// Precondition: the stack is not empty.
			// if the stack is empty, the function throws
			// the underflowError exception
  		const T& top() const;
			// constant version of top()

		bool empty() const;
			// determine whether the stack is empty

		int size() const;
			// return the number of elements in the stack

		bool full() const;
			// return true if the stack has MAXSTACKSIZE elements

	private:
		// array holds the stack elements
		T stackList[MAXSTACKSIZE];
		// topIndex is the index of the stack's top
		int topIndex;
};

// stack is empty when topIndex is -1
template <typename T>
bstack<T>::bstack(): topIndex(-1)
{}

template <typename T>
void bstack<T>::push(const T& item)
{
	// stack is full if topIndex is MAXSTACKSIZE-1
	if (topIndex == MAXSTACKSIZE-1)
		throw overflowError("bstack push(): stack is full");

	// move to next slot of stackList
	topIndex++;

	// insert item into stackList
	stackList[topIndex] = item;
}

template <typename T>
void bstack<T>::pop()
{
	// stack is empty if topIndex is -1
	if (topIndex == -1)
		throw underflowError("bstack pop(): stack is empty");

	// decrement topIndex
	topIndex--;
}

template <typename T>
T& bstack<T>::top()
{
	// stack is empty if topIndex is -1
	if (topIndex == -1)
		throw underflowError("bstack pop(): stack is empty");

	// return the value at the top of the stack
	return stackList[topIndex];
}

template <typename T>
const T& bstack<T>::top() const
{
	// stack is empty if topIndex is -1
	if (topIndex == -1)
		throw underflowError("bstack pop(): stack is empty");

	// return the value at the top of the stack
	return stackList[topIndex];
}

template <typename T>
bool bstack<T>::empty() const
{
	// stack is empty if topIndex is -1
	return topIndex == -1;
}

template <typename T>
int bstack<T>::size() const
{
	// number of elements in the stack is topIndex+1
	return topIndex+1;
}

template <typename T>
bool bstack<T>::full() const
{
	// stack is full if topIndex is MAXSTACKSIZE-1
	return topIndex == MAXSTACKSIZE-1;
}

#endif	// BOUNDED_STACK_CLASS
