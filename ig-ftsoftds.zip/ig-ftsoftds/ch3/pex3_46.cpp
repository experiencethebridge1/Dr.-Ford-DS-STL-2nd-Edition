#include <iostream>
#include <string>

using namespace std;

// recursive function that determines if the substring of str
// in the index range [startIndex, endIndex) is a palindrome
bool isPal(const string& str, int startIndex, int endIndex);

int main()
{
	string str;
	int i;

	for (i=0;i < 5;i++)
	{
		cout << "Input a string: ";
		cin >> str;
		if (isPal(str, 0, str.length()))
			cout << str << " is a palindrome" << endl;
		else
			cout << str << " is not a palindrome" << endl;
		cout << endl;
	}

   return 0;
}

bool isPal(const string& str, int startIndex, int endIndex)
{
	// str is a palindrome if startIndex >= endIndex
	if (startIndex >= endIndex-1)
		return true;
	// str is not a palindrome if str[startIndex] != str[endIndex-1]
	else if (str[startIndex] != str[endIndex-1])
		return false;
	else
		// str[startIndex] == str[endIndex-1]. check to see if
		// the characters in the range [startIndex+1,endIndex-1) are
		// a palindrome
		return isPal(str, startIndex+1, endIndex-1);
}

/*
Run:

Input a string: amanaplanacanalpanama
amanaplanacanalpanama is a palindrome

Input a string: gohangasalamiimalasagnahog
gohangasalamiimalasagnahog is a palindrome

Input a string: abcdecba
abcdecba is not a palindrome

Input a string: science
science is not a palindrome

Input a string: madamimadam
madamimadam is a palindrome
*/
