#ifndef CIRCLE_CLASS
#define CIRCLE_CLASS

const double PI = 3.141592653589793;

class circle
{
	public:
		circle(double r = 0.0): radius(r)
		{}

		double getRadius() const
		{ return radius; }

		void setRadius(double r)
		{ radius = r; }

		double area() const
		{ return PI * radius * radius; }

		double circumference() const
		{ return 2.0 * PI * radius; }

	private:
		double radius;
};

#endif	// CIRCLE_CLASS
