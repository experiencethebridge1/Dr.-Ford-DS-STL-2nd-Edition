#ifndef TEXTFILE_CLASS
#define TEXTFILE_CLASS

#include <iostream>
#include <fstream>
#include <string>

#include "d_except.h"

using namespace std;

class textfile
{
	public:
		textfile();
			// constructor

		void assign(const string& fname);
			// sets file name

		void reset();
			// if file already open, seeks to beginning
			// of the file; otherwise, opens file fname
			// for input.
			// Preconditions: access type must be IN and it
			// must be possible to open the file. if the access
			// type is OUT, the function throws the fileError
			// exception, and if it is not possible to open
			// the file, it throws the fileOpenError exception

		void rewrite();
			// opens file for output and truncates any existing
			// version of the file.
			// Preconditions: the file must not be open and it
			// must be possible to open the file. if the file
			// is already open, the function throws the fileError
			// exception, and if it is not possible to open
			// the file, it throws the fileOpenError exception

		int endFile() const;
			// determine whether end-of-file has been reached.
			// Preconditions: the file must be open. if the file is
			// not open, the function throws the fileError exception

		void close();
			// close file

		int read(char arr[], int n);
			// read a maximum of n characters into array arr
			// and return the actual number of characters read.
			// Preconditions: access type must be IN, n must be >= 0,
			// and the file must be open. if any precondition is
			// violated, the function throws the fileError exception

		void write(char arr[],int n);
			// writes n characters from array arr to the file.  
			// Preconditions: access type must be OUT, n must be >= 0,
			// and the file must be open. if any precondition is
			// violated, the function throws the fileError exception
	private:
		enum access  {IN, OUT};
			// defines the data flow of the file

		fstream f;
			// C++ file stream
		string fileName;
			// file name
		access accesstype;
			// data flow is IN or OUT
		bool isOpen;
			// true when a file is open
};

// constructor. mark file as unopened
textfile::textfile(): isOpen(false)
{}

void textfile::assign(const string& fname)
{
	fileName = fname;
}

void textfile::reset()
{
	if (isOpen)
		if (accesstype == IN)
			// seek to the beginning of the file
   			f.seekg(0,ios::beg);
   	else
   		throw
				fileError("textfile reset(): Cannot reset an output file");
   else
   {
   	// access is input
   	accesstype = IN;
   	// open fname for input
      f.open(fileName.c_str(), ios::in);

		// verify the the open succeeded
      if (!f)
      	throw
				fileOpenError(fileName);
      else
      	isOpen = true;
   }
}

void textfile::rewrite()
{
	if (isOpen)
		throw fileError("textfile rewrite(): file already open");
   else
   {
		// access is output
   	accesstype = OUT;
   	// open fname for output. truncate the file
   	// if it exists
      f.open(fileName.c_str(), ios::out | ios::trunc);

		// verify the the open succeeded
      if (!f)
      	throw
				fileOpenError(fileName);
      else
      	isOpen = true;
	}
}

void textfile::close()
{
	if (isOpen)
   	// close the file
   	f.close();

   isOpen = false;
}

int textfile::endFile() const
{
	if(!isOpen)
      throw
			fileError("textfile endFile(): file is closed");

	// use the stream member function eof
	return f.eof();
}

int textfile::read(char arr[], int n)
{
	if (accesstype == OUT)
		throw
			fileError("textfile read(): file is open for output");
	else if (n < 0) 
		throw
			fileError("textfile read(): invalid character count");
   else if(!isOpen)
		throw
			fileError("textfile read(): file is closed");

	// read up to n characters from stream f
	f.read(arr, n);

	// return the number of characters read. this
	// may be less than n if end of file was reached
	return f.gcount();
}

void textfile::write(char arr[], int n)
{   
	if (accesstype == IN)
		throw
			fileError("textfile write(): file is open for input");
	else if (n < 0) 
		throw
			fileError("textfile write(): invalid character count");
   else if(!isOpen)
		throw
			fileError("textfile write(): file is closed");

	// write n bytes to f
	f.write(arr,n);
}

#endif	// TEXTFILE_CLASS
