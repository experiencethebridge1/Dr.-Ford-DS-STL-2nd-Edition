#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <list>

#include "intentry.h"
#include "d_util.h"		// for writeList()

using namespace std;

// computes the prime factorization of n and
// stores the entries in the list primes. for
// instance, if 2 occurs 3 times in the prime
// factorization, there is an intEntry object in
// primes with value = 2, count = 3
void loadPrimes(list<intEntry>& primes, int n);

// return the primes common to both mList and nList
list<intEntry> commonPrimes(const list<intEntry>& mList,
									 const list<intEntry>& nList);

// form the product of the prime factors in primeList
int product(const list<intEntry>& primeList);

int main()
{
	int m, n;
	list<intEntry> primeFactm, primeFactn, cprimes;

	cout << "Enter two integers m and n > 1: ";
	cin >> m >> n;

	// find the prime factors of m and n
	loadPrimes(primeFactm, m);
	loadPrimes(primeFactn, n);

	// output the prime factorizations
	cout << "The prime factorization of " << m
		  << " and " << n << " is " << endl;
	cout << m << ":  ";
	writeList(primeFactm);
	cout << n << ":  ";
	writeList(primeFactn);
	cout << endl;

	// find and output the common primes
	cprimes = commonPrimes(primeFactm, primeFactn);
	cout << "The list of common factors is: ";
	writeList(cprimes);

	// output the greatest common divisor of m and n
	cout << "The gcd(" << m << ',' << n
		  << ") = " << product(cprimes) << endl;

	return 0;
}

void loadPrimes(list<intEntry>& primes, int n)
{
	// 2 is the first possible prime factor
	int i = 2;
	// count of the repeats of the current prime
	int nc = 0;

	// loop until all prime factors are found
	do
	{
		// if i divides n, it is a prime factor
		if (n % i == 0)
		{
			// increment count for this factor and
			// divide it out of n. stay with i, since
			// there may still be more i's in n
			nc++;
			n = n/i;
		}
		else
		{
			// if nc > 0, then i is a prime factor. insert
			// it and its count into the list
			if (nc > 0)
				primes.push_back(intEntry(i, nc));

			// reset count to 0 and increment i
			nc = 0;
			i++;
		}
	}
	// continue if n > 0 or nc != 0. test the latter condition
	// to handle cases such as n = 4 where n = 1, i = 2, and nc = 2
	// after two iterations. we still need to append intEntry(2,2)
	// to the list
	while (n > 1 || nc != 0);
}

list<intEntry> commonPrimes(const list<intEntry>& mList,
									 const list<intEntry>& nList)
{
	// we build the list of common primes in returnList
	list<intEntry> returnList;
	// iterators to traverse each list
	list<intEntry>::const_iterator mListIter, nListIter;

	// start with the first item of each list
	mListIter = mList.begin();
	nListIter = nList.begin();

	// move through the lists until we reach the end of one or
	// both
	while (mListIter != mList.end() && nListIter != nList.end())
	{
		// WE EXPLOIT THE FACT THAT MLIST AND NLIST ARE ORDERED BY VALUE

		if (*mListIter < *nListIter)
			// if *mListIter < *nListIter, *mListIter cannot occur in both
			// lists. move its iterator forward
			mListIter++;
		else if (*nListIter < *mListIter)
			// if *nListIter < *mListIter, *nListIter cannot occur in both
			// lists. move its iterator forward
			nListIter++;
		else
		{
			// *mListIter and *nListIter are equal. insert the intEntry
			// object with the smallest count at the back of returnList
			if ((*mListIter).getCount() < (*nListIter).getCount())
				returnList.push_back(*mListIter);
			else
				returnList.push_back(*nListIter);

			// move both iterators forward
			mListIter++;
			nListIter++;
		}
	}

	// if there are no common primes, then the two integers are
	// said to be relatively prime. in this case, return an
	// intEntry object with value 1 and count 1
	if (returnList.empty())
		returnList.push_back(intEntry(1,1));

	return returnList;
}

// form the product of the prime factors in primeList
int product(const list<intEntry>& primeList)
{
	int retValue = 1, value, count;
	list<intEntry>::const_iterator iter;
	int i;

	iter = primeList.begin();
	while (iter != primeList.end())
	{
		value = (*iter).getValue();
		count = (*iter).getCount();

		for (i=0;i < count;i++)
			retValue *= value;

		iter++;
	}

	return retValue;
}

/*
Run 1:

Enter two integers m and n > 1: 60 18
The prime factorization of 60 and 18 is
60:  2 2   3   5
18:  2   3 3

The list of common factors is: 2   3
The gcd(60,18) = 6

Run 2:

Enter two integers m and n > 1: 250149900 47322730
The prime factorization of 250149900 and 47322730 is
250149900:  2 2   3   5 5   7 7 7   11   13   17
47322730:  2   5   7 7   13   17   19   23

The list of common factors is: 2   5   7 7   13   17
The gcd(250149900,47322730) = 108290

Run 3:

Enter two integers m and n > 1: 67 45
The prime factorization of 67 and 45 is
67:  67
45:  3 3   5

The list of common factors is: 1
The gcd(67,45) = 1
*/
