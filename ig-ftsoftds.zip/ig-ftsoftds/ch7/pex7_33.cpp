#include <iostream>

#include "dualstk.h"		// dualStack class

using namespace std;

int main()
{
	dualStack<int> ds;
	int i, n;

	cout << "Enter 20 integers:" << endl;
	for (i=0;i < 20;i++)
	{
		// input an integer. if it is even, push it on
		// stack One; otherwise, push it on stack Two
		cin >> n;
		if (n%2 == 0)
			ds.push(n, One);
		else
			ds.push(n, Two);
	}
	cout << endl;

	cout << "Even integers in reverse order:" << endl;
	// flush and output stack One
	while (!ds.empty(One))
	{
		cout << ds.top(One) << "  ";
		ds.pop(One);
	}
	cout << endl;

	cout << "Odd integers in reverse order:" << endl;
	// flush and output stack Two
	while (!ds.empty(Two))
	{
		cout << ds.top(Two) << "  ";
		ds.pop(Two);
	}
	cout << endl;

	return 0;
}

/*
Run:

Enter 20 integers:
5 13 25 16 2 4 5 17 457 88 1 9 26 55 100
75 36 8 10 35

Even integers in reverse order:
10  8  36  100  26  88  4  2  16
Odd integers in reverse order:
35  75  55  9  1  457  17  5  25  13  5
*/
