#include <iostream>

#include "d_stree.h"

using namespace std;

int main()
{
	// tree intTree has values from the array intArr5
	int intArr[] = {14, 79, 18, 2, 91, 35, 28};
	int arrSize = sizeof(intArr)/sizeof(int);
	stree<int> intTree(intArr, intArr+arrSize);
	// declare an integer tree iterator
	stree<int>::iterator iter;

	// the smallest value is pointed to by intTree.begin()
	iter = intTree.begin();
	cout << "Smallest value in the tree is " << *iter << endl;

	// set iter to the end of the tree and move back one position.
	// this is the largest value in the tree
	iter = intTree.end();
	iter--;
	cout << "Largest value in the tree is " << *iter << endl;

   return 0;
}

/*
Run:

Smallest value in the tree is 2
Largest value in the tree is 91
*/
