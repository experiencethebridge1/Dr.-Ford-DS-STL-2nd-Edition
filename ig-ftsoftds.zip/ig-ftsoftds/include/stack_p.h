#ifndef STACK_CLASS_WITH_PRIORITY_QUEUE
#define STACK_CLASS_WITH_PRIORITY_QUEUE

#include <functional>	// for function object type greater<T>

#include "d_pqueue.h"
#include "d_except.h"

#ifdef _MSC_VER
// VC++ 6.0 requires the following pre-class declaration
// statements
template <typename T>
class priorityData;

template <typename T>
bool operator< (const priorityData<T>& lhs,
					 const priorityData<T>& rhs);

template <typename T>
bool operator> (const priorityData<T>& lhs,
					 const priorityData<T>& rhs);
#endif	// _MSC_VER

// priorityData objects are maintained by the
// miniStack implementation
template <typename T>
class priorityData
{
	public:
		T data;
		int priority;

	// order objects by priorityData
	friend bool operator< (const priorityData<T>& lhs,
								  const priorityData<T>& rhs)
	{
		return lhs.priority < rhs.priority;
	}

	friend bool operator> (const priorityData<T>& lhs,
								  const priorityData<T>& rhs)
	{
		return lhs.priority > rhs.priority;
	}
};

template <typename T>
class miniStack
{
    public:
		miniStack();
			// constructor; create an empty stack
		
		void push(const T& item);
			// insert item on the top of the stack
			// Postcondition: the stack has one more element

		void pop();
			// remove an element from the top of the stack.
			// Precondition: the stack is not empty. if the
			// stack is empty, the function throws the
			// underflowError exception
			// Postcondition: the stack has one less element

		T& top();
			// return a reference to the top of the stack.
			// Preconditon: the stack is not empty. if the
			// the stack is empty, the function throws the
			// underflowError exception
		const T& top() const;
			// constant version of top()
                
     int size() const;
			// return the stack size
		
		bool empty() const;
			// is the stack empty?

    private:
		int priorityLevel;
			// priority of the next item to go on the top
			// of the stack. increases after each insertion
		miniPQ<priorityData<T>, greater<priorityData<T> > > pq;
			// maintains the stack items and stack size. it is
			// a maximum priority queue ordered by the priority
			// field of its priorityData objects
};

// initial priorityLevel is 0
template <typename T>
miniStack<T>::miniStack(): priorityLevel(0)
{}

template <typename T>
void miniStack<T>::push(const T& item)
{
	priorityData<T> pd;

	// initialize pd
	pd.data = item;
	pd.priority = priorityLevel;

	// increment the priority level
	priorityLevel++;

	pq.push(pd);
}

template <typename T>
void miniStack<T>::pop()
{
	if (pq.size() == 0)
		throw underflowError("miniStack pop(): stack is empty");

	// pops the highest priority item, which is the one most
	// recently inserted
	pq.pop();
}

template <typename T>
T& miniStack<T>::top()
{
	if (pq.size() == 0)
		throw underflowError("miniStack top(): stack is empty");

	// returns the highest priority item, which is the one most
	// recently inserted
	return pq.top().data;
}

template <typename T>
const T& miniStack<T>::top() const
{
	if (pq.size() == 0)
		throw underflowError("miniStack top(): stack is empty");

	// returns the highest priority item, which is the one most
	// recently inserted
	return pq.top().data;
}
          
template <typename T>
int miniStack<T>::size() const
{
	return pq.size();
}

template <typename T>
bool miniStack<T>::empty() const
{
	return pq.empty();
}

#endif	// STACK_CLASS_WITH_PRIORITY_QUEUE
 