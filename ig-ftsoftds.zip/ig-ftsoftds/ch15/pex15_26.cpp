#include <iostream>
#include <vector>

#include "d_sort.h"
#include "d_random.h"

using namespace std;

// sort a vector using quicksort and insertion sort.
template <typename T>
void quicksort15(vector<T>& v, int first, int last);

int main()
{
	vector<int> v;
	randomNumber rnd;
	int i;

	// initialize with 250 random integers in the range
	// 0 to 999
	for (i=0;i< 250;i++)
		v.push_back(rnd.random(1000));

	// sort using quicksort15()
	quicksort15(v, 0, v.size());

	// output the first 10 values from v
	cout << "First 10 values: ";
	for (i=0;i < 10;i++)
		cout << v[i] << "  ";
	cout << endl;

	// output the last 10 values from v
	cout << "Last 10 values: ";
	for (i=v.size()-10;i < v.size();i++)
		cout << v[i] << "  ";
	cout << endl;

	return 0;
}

template <typename T>
void quicksort15(vector<T>& v, int first, int last)
{
   // index of the pivot
   int pivotLoc;
	// temp used for an exchange when [first,last) has
	// two elements
	T temp;

   // if the range is not at least two elements, return
   if (last - first <= 1)
		return;

	// if sublist has two elements, compare v[first] and
	// v[last-1] and exchange if necessary
   else if (last - first == 2)
	{
		if (v[last-1] < v[first])
		{
			temp = v[last-1];
			v[last-1] = v[first];
			v[first] = temp;
		}
		return;
	}
	// if 3 <= sublist size <= 15, use insertion sort
	else if (last - first <= 15)
		insertionSort(v, first, last);
   else
	{
		pivotLoc = pivotIndex(v, first, last);

		// make the recursive call
		quicksort(v, first, pivotLoc);

		// make the recursive call
		quicksort(v, pivotLoc +1, last);
	}
}

/*
Run:

First 10 values: 7  11  13  13  15  20  22  32  35  35
Last 10 values: 971  973  976  982  983  983  984  992  993  995
*/
