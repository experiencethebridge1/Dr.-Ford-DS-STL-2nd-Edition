#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>

#include "adjgraph.h"
#include "d_util.h"

using namespace std;

int main()
{	
	graph<char> g;
	set<char> bfsSet;
	ifstream fin;

	fin.open("fg16-29a.dat");
	fin >> g;

	// do a breadth-first search from A and output the
	// vertices the search reaches
	bfsSet = bfs(g, 'A');
	cout << "Breadth-first search from A reaches vertices: ";
	writeContainer(bfsSet.begin(), bfsSet.end());
	cout << endl;

	// erase vertex C and edge (B,E). output the properties
	// of the updated graph
	g.eraseVertex('C');
	g.eraseEdge('B', 'E');
	cout << "After erasing vertex C and edge (B,E), the new graph has"
			  " properties:" << endl << endl;
	cout << g << endl;

	// add vertex F and edges (F,A), (E,F), and (B,F).
	// output the properties of the final graph
	g.insertVertex('F');
	g.insertEdge('F', 'A', 3);
	g.insertEdge('E', 'F', 2);
	g.insertEdge('B', 'F', 5);

	cout << "The final graph has properties:"
		  << endl << endl;
	cout << g << endl;

	return 0;
}

/*
Run:

After erasing vertex C and edge (B,E), the new graph has properties:

A: in-degree 2  out-degree 1
    Edges: B (5)
B: in-degree 1  out-degree 1
    Edges: A (2)
D: in-degree 0  out-degree 1
    Edges:
E: in-degree 1  out-degree 1
    Edges: A (3)

The final graph has properties:

A: in-degree 3  out-degree 1
    Edges: B (5)
B: in-degree 1  out-degree 2
    Edges: A (2)  F (5)
F: in-degree 2  out-degree 1
    Edges: A (3)
D: in-degree 0  out-degree 1
    Edges: E (2)
E: in-degree 1  out-degree 2
    Edges: A (3)  F (2)
*/
