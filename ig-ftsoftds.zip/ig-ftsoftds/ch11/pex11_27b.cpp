#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>

#include "d_state.h"
#include "d_util.h"

using namespace std;

int main()
{
	// vals contains initial values for ms
	stateCity vals[] = {stateCity("Arizona", "Phoenix"),
							  stateCity("Illinois", "Chicago"),
							  stateCity("Illinois", "Gary"),
							  stateCity("Illinois", "Evanston"),
							  stateCity("Nevada", "Reno"),
							  stateCity("California", "Sacramento") };
	int valsSize = sizeof(vals)/sizeof(stateCity);
	multiset<stateCity> ms(vals, vals+valsSize);
	multiset<stateCity>::iterator iter;
	// use with equal_range
	pair<multiset<stateCity>::iterator,multiset<stateCity>::iterator> p;
	string state;

	cout << "Enter a state: ";
	getline(cin, state);
	cout << endl;

	// determine an iterator range for elements matching state
	p = ms.equal_range(stateCity(state));

	// output the elements in the range [p.first, p.second)
	iter = p.first;
	while (iter != p.second)
	{
		cout << *iter << endl;
		iter++;
	}

	return 0;
}

/*
Run:

Enter a state: Illinois

Chicago, Illinois
Gary, Illinois
Evanston, Illinois
*/
