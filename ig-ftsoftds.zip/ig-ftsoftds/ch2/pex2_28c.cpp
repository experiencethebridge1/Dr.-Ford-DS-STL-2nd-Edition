#include <iostream>

#include "complexx.h"

using namespace std;

// evaluate the complex function f(z) = z**3 -3z*z + 4z - 2
complex f(const complex& z);

int main()
{
	// values for which the program computes f
	complex vals[] = { complex(2,3), complex(-1,1), complex(1,1),
							 complex(1,-1), complex(1,0) };
	int k;

	// evaluate f(z), z = 2+3i, -1+i, 1+i, 1-i, 1+0i
	for(k=0;k < 5;k++)
		cout << f(vals[k]) << "  ";
	cout << endl;

	return 0;
}

complex f(const complex& z)
{
	return z*z*z - 3*z*z + 4*z - 2;
}

/*
Run:

(-25,-15)  (-4,12)  (0,0)  (0,0)  (0,0)
*/
