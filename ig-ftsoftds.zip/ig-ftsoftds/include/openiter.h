#ifdef __BORLANDC__
// suppress the warning message that functions containing for are not
// expanded inline
#pragma warn -8027
#endif	// __BORLANDC__

class iterator;
friend class iterator;

class const_iterator;
friend class const_iterator;
	// give the iterator classes access to private
	// section of openHash

class iterator
{
	public:

		friend class openHash<T,HashFunc>;
		friend class const_iterator;

		iterator()
		{}

		bool operator== (const iterator& rhs) const
		{
			if (currentIndex == rhs.currentIndex)
				return true;
			else
				return false;
		}

		bool operator!= (const iterator& rhs) const
		{
			if (currentIndex != rhs.currentIndex)
				return true;
			else
				return false;
		}

		T& operator* ()
		{
			if (currentIndex == -1)
				throw referenceError("openHash iterator operator *: "
						  "invalid reference");

			// return the data in the table element
			return hashTable->bucket[currentIndex].data;
		}

		iterator& operator++ ()
		{
			// move forward until we find a filled slot or get back
			// to table location 0
			do
			{
				currentIndex = (currentIndex+1) % hashTable->numBuckets;
			} while (currentIndex != 0 &&
						hashTable->bucket[currentIndex].available == true);

			// the iteration is complete if we have come around the table
			// back to 0. indicate end() by assigning -1 to currentIndex
			if (currentIndex == 0)
				currentIndex = -1;

			return *this;
		}

		iterator operator++ (int)
		{
			// record the current state of the iterator
			iterator tmp = *this;

			// move forward using prefix ++
			++(*this);

			// return the original iterator state
			return tmp;
		}

	private:

		// points to the hash table that must be traversed
		openHash<T, HashFunc> *hashTable;

		// index of current table slot. -1 indicates end()
		int currentIndex;

		// used by openHash when it needs to construct an iterator
		// return value
		iterator(openHash<T,HashFunc> *ht, int loc):
			hashTable(ht), currentIndex(loc)
		{}
};

// the constant iterator class
class const_iterator
{
	public:
		friend class openHash<T,HashFunc>;

		const_iterator()
		{}

		// converts a const iterator to a const_iterator
		const_iterator (const iterator& x):
			hashTable(x.hashTable),
			currentIndex(x.currentIndex)
		{}

		bool operator== (const const_iterator& rhs) const
		{
			if (currentIndex == rhs.currentIndex)
				return true;
			else
				return false;
		}

		bool operator!= (const const_iterator& rhs) const
		{
			if (currentIndex != rhs.currentIndex)
				return true;
			else
				return false;
		}

		const T& operator* () const
		{
			if (currentIndex == -1)
				throw referenceError("openHash iterator operator *: "
						  "invalid reference");

			// return the data in the table element
			return hashTable->buckets[currentIndex].data;
		}

		const_iterator& operator++ ()
		{
			// move forward until we find a filled slot or get back
			// to table location 0
			do
			{
				currentIndex = (currentIndex+1) % hashTable->numBuckets;
			} while (current != 0 &&
						hashTable->table[currentIndex].available == true);

			// the iteration is complete if we have come around the table
			// back to 0. indicate end() by assigning -1 to currentIndex
			if (currentIndex == 0)
				currentIndex = -1;

			return *this;
		}

		const_iterator operator++ (int)
		{
			// record the current state of the iterator
			const_iterator tmp = *this;

			// move forward using prefix ++
			++(*this);

			// return the original iterator state
			return tmp;
		}

	private:

		// points to the hash table that must be traversed.
		// note that the hash table is const
		const openHash<T, HashFunc> *hashTable;

		// index of current table slot. -1 indicates end()
		int currentIndex;

		// used by openHash when it needs to construct an iterator
		// return value
		const_iterator(const openHash<T,HashFunc> *ht, int loc):
			hashTable(ht), currentIndex(loc)
		{}
};

