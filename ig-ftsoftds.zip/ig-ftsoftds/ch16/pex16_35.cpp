#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>

#include "d_graph.h"
#include "d_util.h"	// for writeContainer()

using namespace std;

// output the strong components
template <typename T>
void outputStrongComponents(const vector<set<T> >& component);

int main()
{
	graph<char> g;
	ifstream fin;
	// stores the strong components of g
	vector<set<char> > component;
	int i;

	fin.open("graphB.dat");
	fin >> g;

	// compute and output the strong components of graphB
	strongComponents(g, component);

	cout << "Original strong components of graphB:" << endl;
	outputStrongComponents(component);
	cout << endl;

	// remove all vertices in 1-element strong components
	for (i=0;i < component.size();i++)
		if (component[i].size() == 1)
			g.eraseVertex(*component[i].begin());


	// compute and output the new set of strong components for graphB
	strongComponents(g, component);

	cout << "Strong components after erasing all single-element strong "
			  "components" << endl;
	outputStrongComponents(component);

	return 0;
}

template <typename T>
void outputStrongComponents(const vector<set<T> >& component)
{
	int i;

	for (i=0;i < component.size();i++)
	{
		writeContainer(component[i].begin(), component[i].end());
		cout << endl;
	}
}

/*
Run:

Original strong components of graphB:
A  B  C
D
E  F

Strong components after erasing all single-element strong components
A  B  C
E  F
*/
