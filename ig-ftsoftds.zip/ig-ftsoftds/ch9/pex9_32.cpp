#include <iostream>

#include "d_dnode.h"
#include "d_nodel.h"
#include "d_random.h"

using namespace std;

// return a pointer to the maximum element in the
// doubly linked list
template <typename T>
dnode<T> *getMax(dnode<T> *header);

// if target is in the doubly linked list, remove its first
// occurrence; otherwise, do not modify the list
template <typename T>
void eraseValue(dnode<T> *header, const T& target);

int main()
{
	dnode<int> *header = new dnode<int>, *p;
	randomNumber rnd;
	int listCount, i, rndInteger;

	cout << "Enter the size of the list: ";
	cin >> listCount;

	for (i = 0; i < listCount; i++)
	{
		// generate a random integer in the range 0..99
		rndInteger = rnd.random(100);
		// insert the value before header->next,which is
		// at the front of the list
		insert(header->next, rndInteger);
	}

	cout << "Original List of Values:    ";
	writeDLinkedList(header);
	cout << endl;

	cout << "Output in Descending Order: ";
	while (header->next != header)
	{
		// obtain the address of the node having the maximum value
		// and output the value
		p = getMax(header);
		cout << p->nodeValue << "  ";
		// erase the node p
		erase(p);
	}

	cout << endl;

	return 0;
}

template <typename T>
dnode<T> *getMax(dnode<T> *header)
{
	// curr points to the 1st list node, and maxPtr
	// is its address
	dnode<T> *curr = header->next, *maxPtr = curr;

	// return if the list is empty
	if (header->next == header)
		return NULL;

	// move curr to the second list node
	curr = curr->next;

	// cycle through the list and updata maxPtr
	while (curr != header)
	{
		// if curr->nodeValue is larger, set maxPtr to curr
		if (maxPtr->nodeValue < curr->nodeValue)
			maxPtr = curr;
		// advance curr
		curr = curr->next;
	}

	return maxPtr;
}

/*
Run:

Enter the size of the list: 9
Original List of Values:    25  70  95  93  77  55  84  56  77
Output in Descending Order: 95  93  84  77  77  70  56  55  25
*/
