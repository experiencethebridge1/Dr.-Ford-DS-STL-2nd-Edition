#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

int main()
{
	int arr[] = {1, 6, 2, 9, 12, 15, 33, 28};
	int arrSize = sizeof(arr)/sizeof(int);
	// vector containing the values in array arr
	vector<int> v(arr, arr+arrSize);
	double average = 0.0;
	int i;

	// form the sum of the elements in v
	for (i=0;i < v.size();i++)
		average += v[i];

	// compute and output the average
	average = average/v.size();
	cout << "Average = " << average << endl << endl;

	// output the deviation of each value in v from the average
	cout << "Index  Deviation" << endl;
	for (i=0;i < v.size();i++)
		cout << i << ":" << setw(12) << v[i] - average << endl;


   return 0;
}

/*
Run:

Average = 13.25

Index  Deviation
0:      -12.25
1:       -7.25
2:      -11.25
3:       -4.25
4:       -1.25
5:        1.75
6:       19.75
7:       14.75
*/
