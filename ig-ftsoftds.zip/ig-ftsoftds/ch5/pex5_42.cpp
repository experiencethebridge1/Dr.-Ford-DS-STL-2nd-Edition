#include <iostream>

#include "minivec.h"
#include "d_random.h"

using namespace std;

// v is in increasing order
//    v[0] <= v[1] <= v[2] <= ... <= v[v.size()-1]
// insert item into v so that v remains in increasing
// order
template <typename T>
void insertOrder(miniVector<T>& v, const T& item);

// v is in increasing order. erase duplicate values
// from v. for example, if T = int, transform the
// vector
//   v = {1, 1, 2, 3, 3, 3, 7, 7, 8, 9, 9, 10}
// to
//   v = {1, 2, 3, 7, 8, 9, 10}
template <typename T>
void removeDuplicates(miniVector<T>& v);

// output v
template <typename T>
void writeMiniVector(const miniVector<T>& v);

int main()
{
	miniVector<int> randInt;
	int i;
	randomNumber rnd;

	for (i=0;i < 15;i++)
		insertOrder(randInt, int(rnd.random(20)));

	cout << "Original vector of values in the range 0 to 19:"
		  << endl;
	writeMiniVector(randInt);

	// remove the duplicate values and output the modified vector
	removeDuplicates(randInt);
	cout << "Vector after removing duplicates:"
		  << endl;
	writeMiniVector(randInt);

	return 0;
}

template <typename T>
void insertOrder(miniVector<T>& v, const T& item)
{
	int curr = 0, end = v.size();

	// if the list is empty, insert item using push_back()
	if (v.empty())
		v.push_back(item);
	else
	{
		// find the insertion point, which may be at end of list
		while ((curr != end) && (v[curr] < item))
			curr++;

		// use insert()
		v.insert(curr, item);
	}
}

template <typename T>
void removeDuplicates(miniVector<T>& v)
{
	// current data value
   T currValue;
   // the two indices we use
   int curr, p;
    
   // start at the front of the list
   curr = 0;
    
   // cycle through the list
   while(curr != v.size())
   {	
		// record the current list data value
      currValue = v[curr];

      // set p one element to the right of curr
      p = curr;
      p++;

      // move forward as long as we do not encounter the end
		// of the vector and v[p] equals currValue. each iteration
		// erases the duplicate of currValue
      while(p != v.size() && v[p] == currValue)
			// erase current element. p is then the index of
			// the next element
 			v.erase(p);
      // duplicates of currValue removed. move to the next
      // data value and repeat the process
      curr++;
   }
}

template <typename T>
void writeMiniVector(const miniVector<T>& v)
{
	// capture the size of the vector in n
	int i, n = v.size();

	for(i = 0; i < n; i++)
		cout << v[i] << "  ";
	cout << endl;
}

/*
Run:

Original vector of values in the range 0 to 19:
1  2  3  4  5  11  11  11  11  11  12  13  15  16  19
Vector after removing duplicates:
1  2  3  4  5  11  12  13  15  16  19
*/
