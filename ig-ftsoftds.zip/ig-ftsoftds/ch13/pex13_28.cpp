#include <iostream>

#include "student.h"		// student and studentAthlete classes

using namespace std;

int main()
{
 	student ja("John Anderson", "345-12-3547");
	student bw("Bill Williams", "286-72-6194");
	studentAthlete bj("Bob Johnson", "294-87-6285", "football");
	studentAthlete dr("Dick Robinson", "669-289-9296", "baseball");
	// list of student pointers
	student* stud[] = {&ja, &bw, &bj, &dr};
	int sizeStud = sizeof(stud)/sizeof(student *), i;

	for (i=0;i < sizeStud;i++)
	{
		stud[i]->identify();
		cout << endl;
	}

	return 0;
}

/*
Run:

Student John Anderson    Social Security Number 345-12-3547

Student Bill Williams    Social Security Number 286-72-6194

Student Bob Johnson    Social Security Number 294-87-6285
Sport football

Student Dick Robinson    Social Security Number 669-289-9296
Sport baseball
*/
