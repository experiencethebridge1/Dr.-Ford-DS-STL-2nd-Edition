#ifndef ACCUMUATOR_CLASS
#define ACCUMUATOR_CLASS

class accumulator
{
   public:
      accumulator(double value = 0.0);    // initialize total
      double getTotal();                  // return total
      void addValue(double value = 1.0);  // add to total

   private:
      double total;
	      // total accumulated by the object
};

// initialize total
accumulator::accumulator(double value): total(value)
{}

// return the current total
double accumulator::getTotal()
{
   return total;
}

// add value to total
void accumulator::addValue(double value)
{
   total += value;
}

#endif   // ACCUMUATOR_CLASS
