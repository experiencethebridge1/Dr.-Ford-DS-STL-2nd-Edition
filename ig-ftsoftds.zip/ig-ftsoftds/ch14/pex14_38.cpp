#include <iostream>

#include "queue_p.h"

using namespace std;

int main()
{
	int i, n;
	miniQueue<int> q;

	cout << "Enter 5 integer values: ";

	for (i=0;i < 5;i++)
	{
		cin >> n;
		q.push(n);
	}

	cout << "Flushing the queue: ";
	while (!q.empty())
	{
		cout << q.front() << "  ";
		q.pop();
	}
	cout << endl;

	return 0;
}

/*
Run:

Enter 5 integer values: 45 235 55 8 3
Flushing the queue: 45  235  55  8  3
*/