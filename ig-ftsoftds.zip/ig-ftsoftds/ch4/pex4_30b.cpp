#ifdef __BORLANDC__
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
#endif	// __BORLANDC__

#include <iostream>
#include <vector>

#include "d_util.h"

using namespace std;

// return a vector whose elements are in the reverse order of
// those in v
template <typename T>
vector<T> reverseVector(const vector<T>& v);

int main()
{
	int arr[] = {9, 12, 6, 24, 16, 8, 3, 19, 11, 4};
	int arrSize = sizeof(arr)/sizeof(int);
	vector<int> v(arr, arr+arrSize), reverse;

	// assign reverse the result of calling reverseVector(v)
	// and output reverse
	reverse = reverseVector(v);
	writeVector(reverse);

   return 0;
}

template <typename T>
vector<T> reverseVector(const vector<T>& v)
{
	vector<T> rvec;
	int i;

	// push v[v.size()-1] v[v.size()-2] ... v[1] v[0] onto the
	// back of rvec. rvec is the reverse of v
	for (i=v.size()-1;i >= 0;i--)
		rvec.push_back(v[i]);

	return rvec;
}

/*
Run:

4  11  19  3  8  16  24  6  12  9
*/
