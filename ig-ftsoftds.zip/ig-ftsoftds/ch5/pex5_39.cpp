#include <iostream>

#include "d_vector.h"
#include "d_random.h"

using namespace std;

// output miniVector v
template <typename T>
void writeMiniVector(const miniVector<T>& v);

// use insertion sort to place miniVector v in descending order
template <typename T>
void sortMiniVector(miniVector<T>& v);

int main()
{	
	miniVector<int> v;
	randomNumber rnd;
	int i;

	// fill v with 15 random integers in the range 0 to 99 and
	// output the vector
	for (i=0;i < 15;i++)
		v.push_back(rnd.random(100));
	cout << "Original: ";
	writeMiniVector(v);

	sortMiniVector(v);
	cout << "Sorted: ";
	writeMiniVector(v);

	return 0;
}

template <typename T>
void writeMiniVector(const miniVector<T>& v)
{
	int i;

	for (i=0;i < v.size();i++)
		cout << v[i] << "  ";
	cout << endl;
}

template <typename T>
void sortMiniVector(miniVector<T>& v)
{
   int i, j, n = v.size();
   T temp;

	// place v[i] into the sublist
	//   v[0] ... v[i-1], 1 <= i < n,
	// so it is in the correct position
   for (i = 1; i < n; i++) 
   {
      // index j scans down list from v[i] looking for
      // correct position to locate target. assigns it to
      // v[j]
      j = i;
      temp = v[i];
      // locate insertion point by scanning downward as long
      // as temp < v[j-1] and we have not encountered the
      // beginning of the list
      while (j > 0 && v[j-1] < temp)
      { 
         // shift elements up list to make room for insertion
         v[j] = v[j-1];
         j--;
      }
      // the location is found; insert temp
      v[j] = temp;
   }
}

/*
Run:

Original: 59  18  60  91  49  47  83  93  55  52  15  36  83  56  91
Sorted: 93  91  91  83  83  60  59  56  55  52  49  47  36  18  15
*/

