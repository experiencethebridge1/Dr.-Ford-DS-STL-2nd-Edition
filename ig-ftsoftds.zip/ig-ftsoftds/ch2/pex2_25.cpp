#include <iostream>

#include "accum_o.h"

using namespace std;

int main()
{
	accumulator x(5), y(3), z(-9), w;

	// test the operators +=, +, -, and <<
	x += 3;
	w = x + y;
	z = -z;
	cout << w << "  " << z << endl;

   return 0;
}

/*
Run:

11  9 
*/
