#ifndef COMPLEX_CLASS
#define COMPLEX_CLASS

#include <iostream>
#include <cmath>			// for sqrt()

using namespace std;

class complex
{
	public:
		complex(double x = 0.0, double y = 0.0);
			// constructor

		double magnitude() const;	// return magnitude
		double realPart() const;	// return real part
		double imagPart() const;	// return imaginary part
			// access member functions

		friend complex operator+ (const complex& lhs,
										  const complex& rhs);
			// complex addition

		friend complex operator- (const complex& lhs,
										  const complex& rhs);
			// complex subtraction

		friend complex operator* (const complex& lhs,
										  const complex& rhs);
			// complex multiplication

		friend complex operator/ (const complex& lhs,
										  const complex& rhs);
			// complex division

		friend bool operator== (const complex& lhs,
										const complex& rhs);
			// equality of complex numbers

   	complex operator- () const;
			// negation of a complex number
   				
		friend ostream& operator<< (ostream& ostr,
											 const complex& x);
			// output in format (real,imag)
		friend istream& operator>> (istream& ostr,
											 complex& x);
			// input complex number in format (real,imag)
	private:
		double real;	// real part
		double imag;	// complex part

};

// form complex number x+iy. serves as a default constructor
// by building 0+i0
complex::complex(double x, double y):real(x), imag(y)
{}

// return the real part of the complex number
double complex::magnitude() const
{
	return sqrt(real*real + imag*imag);
}

// return the real part of the complex number
double complex::realPart() const
{
	return real;
}

// return the imaginary part of the complex number
double complex::imagPart() const
{
	return imag;
}

// addition of complex numbers
complex operator+ (const complex& lhs,
						 const complex& rhs)
{
	return complex(lhs.real+rhs.real, lhs.imag+rhs.imag);
}

// subtraction of complex numbers
complex operator- (const complex& lhs,
						 const complex& rhs)
{
	return complex(lhs.real-rhs.real, lhs.imag-rhs.imag);
}

// multiplication of complex numbers
complex operator* (const complex& lhs,
						 const complex& rhs)
{
	return complex(lhs.real*rhs.real - lhs.imag*rhs.imag,
				   lhs.real*rhs.imag+lhs.imag*rhs.real);
}

// division of complex numbers
complex operator/ (const complex& lhs,
						 const complex& rhs)
{
	double denom = rhs.real*rhs.real+rhs.imag*rhs.imag;
	
	return complex((lhs.real*rhs.real+lhs.imag*rhs.imag)/denom,
				   (lhs.imag*rhs.real-lhs.real*rhs.imag)/denom);
}

// comparison of complex numbers
bool operator== (const complex& lhs,
					  const complex& rhs)
{
	return lhs.real == rhs.real && lhs.imag == rhs.imag;
}

// negation of a complex number
complex complex::operator- () const
{
	return complex(-real,-imag);
}

// stream output in format (real,imag)
ostream& operator<< (ostream& ostr,const complex& x)
{
	ostr << '(' << x.real << ',' << x.imag << ')';
	return ostr;
}

// stream input in format (real,imag)
istream& operator>> (istream& istr,complex& x)
{
	// used to check for presence of '(', ')' and ','
	char paren, comma;

	// read the left parentheses '('
	istr >> paren;
	// return with an error if did not read '('
	if (paren != '(')
	{
		// set failure bit in the stream
		istr.clear(ios::failbit);
		return istr;
	}
	// read real part component
	istr>> x.real;
	// read the comma ','
	istr >> comma;
	// return with an error if did not read ','
	if (comma != ',')
	{
		// set failure bit in the stream
		istr.clear(ios::failbit);
		return istr;
	}
	// read the imaginary part
	istr >> x.imag;
	// read the closing right parentheses ')'
	istr >> paren;
	// note an error if did not read ')'
	if (paren != ')')
		// set failure bit in the stream
		istr.clear(ios::failbit);

	return istr;
}

#endif	// COMPLEX_CLASS