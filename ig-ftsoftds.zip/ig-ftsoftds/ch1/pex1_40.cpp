#include <iostream>
#include <string>

using namespace std;

// return the string strA + ch + strB
string linkNames(const string& strA, const string& strB, char ch);

int main()
{
	string algs = "Algorithms ",
			 dataStruc = " Data Structures ",
			 programs = " Programs",
			 title;

	cout << linkNames(linkNames(algs, dataStruc, '+'), programs, '=')
		  << endl;

	return 0;
}

string linkNames(const string& strA, const string& strB, char ch)
{
	return strA + ch + strB;
}

/*
Run:

Algorithms + Data Structures = Programs
*/