#include <iostream>
#include <vector>

#include "d_sort.h"
#include "d_util.h"
#include "d_timer.h"
#include "d_random.h"

using namespace std;

enum sortType {Selection, Insertion, Bubble, Exchange, Shell};
enum testType {Rand, Ascending, Descending};

// create a vector with vecSize entries whose values are determined
// by the argument tst. apply the sort stype and output the time
// in seconds required by the sort
void timeSort(sortType stype, testType tst, int vecSize);

// sorts an array using the bubble sort
template <typename T>
void bubbleSort(vector<T>& v);

// sort an array using the exchange sort algorithm
template <class T>
void exchangeSort(vector<T>& v);

// sort a vector using the Shell sort
template <class T>
void shellSort(vector<T>& v);

int main()
{
	sortType s;
	testType t;

	// for each type of data, run all sorts
	for (t=Rand;t <= Descending;t = testType(int(t) + 1))
	{
		for (s=Selection;s <= Shell;s = sortType(int(s) + 1))
			timeSort(s,t,10000);
		cout << endl;
	}

   return 0;
}

void timeSort(sortType stype, testType tst, int vecSize)
{
	vector<int> v;
	// use one random sequence for the whole program
	static randomNumber rnd;
	timer t;
	int i;

	// generate the data
	switch(tst)
	{
		case Rand:
						// random data
						for (i=0;i < vecSize;i++)
							v.push_back(rnd.random(1000000));
						cout << "Random data - ";
						break;

		case Ascending:
						// 1 2 3...vecSize
						for (i=0;i < vecSize;i++)
							v.push_back(i+1);
						cout << "Data in ascending order - ";
								break;

		case Descending:
						// vecSize...3 2 1
						for (i=0;i < vecSize;i++)
							v.push_back(vecSize-i);
						cout << "Data in descending order - ";
						break;
	}

	// start the timer, call the requested sort, and output the time
	// required
	t.start();
	switch(stype)
	{
		case Selection:	selectionSort(v);
								t.stop();
								cout << "selection sort: " << t.time()
									  << endl;
								break;

		case Insertion:	insertionSort(v);
								t.stop();
								cout << "insertion sort: " << t.time()
									  << endl;
								break;

		case Bubble:		bubbleSort(v);
								t.stop();
								cout << "bubble sort: " << t.time()
									  << endl;
								break;

		case Exchange:		exchangeSort(v);
								t.stop();
								cout << "exchange sort: " << t.time()
									  << endl;
								break;

		case Shell:			shellSort(v);
								t.stop();
								cout << "Shell sort: " << t.time()
									  << endl;
								break;
	}
}

template <typename T>
void bubbleSort(vector<T>& v)
{
	int i,j, n = v.size();             
	// index of last exchange 
	bool exchangeOccurs = true;
	T temp;

	// i is the index of last element in the current sublist
	i = n-1;

	// continue the process until we make no exchanges or
	// we have made n-1 passes
	while (i > 0 && exchangeOccurs) 
	{
		// assume no exchange occurs
		exchangeOccurs= false;
      
		// scan the sublist v[0] to v[i]
		for (j = 0; j < i; j++)
			// exchange a pair and assign true to exchangeOccurs
			if (v[j+1] < v[j])
			{
				temp = v[j];
				v[j] = v[j+1];
				v[j+1] = temp;
				exchangeOccurs= true;
			}
		// move i downward one element
		i--;
	}
}

template <class T>
void exchangeSort(vector<T>& v)
{
   int pass, i, n = v.size();
	T temp;
   
	// make n-1 passes through the data
	for (pass = 0; pass < n-1; pass++)
   	// locate least of v[pass] ... v[n-1] at v[pass]
      for (i = pass+1; i < n; i++)
         if (v[i] < v[pass])
			{
				temp = v[pass];
				v[pass] = v[i];
				v[i] = temp;
			}
}

template <class T>
void shellSort(vector<T>& v)
{	   
	int i,j,k, n = v.size();
	T target;

	// select k from the increment sequence
	// ..., 1093, 364, 121, 40, 13, 4, 1. it can
	// be shown that the Shell sort does well with
	// this increment sequence
	for(k=1;k <= n/9;k = 3*k+1);
	
	while (k >= 1)
	{
		// sort the sublists. locate v[k] in the sublist
		// v[0],v[k], locate v[k+1] in the sublist v[1],v[k+1],
		// locate v[k+2] in the sublist v[2],v[k+2], etc.
		// when we process i=n-1, all sublists will be sorted
		for(i = k; i < n; i++) 
		{
			target = v[i];
			// move to the sublist value before v[j]
			j = i - k;
			// insert target in its sublist. same code as for
			// the insertion sort, except we are using decrement
			// k
			while (j >= 0 && target < v[j]) 
			{
				v[j + k] = v[j];
				j = j - k;
			}  
			v[j + k] = target;
		}

		k /= 3;
	}
}

/*
Run:

Random data - selection sort: 20.249
Random data - insertion sort: 14.881
Random data - bubble sort: 40.238
Random data - exchange sort: 40.098
Random data - Shell sort: 0.14

Data in ascending order - selection sort: 20.199
Data in ascending order - insertion sort: 0.01
Data in ascending order - bubble sort: 0
Data in ascending order - exchange sort: 20.079
Data in ascending order - Shell sort: 0.04

Data in descending order - selection sort: 20.109
Data in descending order - insertion sort: 29.753
Data in descending order - bubble sort: 59.395
Data in descending order - exchange sort: 59.656
Data in descending order - Shell sort: 0.08
*/
