#include <iostream>
#include <stack>

using namespace std;

// moves the nth element (counting from top, which is element 1) of the
// stack to the top, leaving the order of all other elements unchanged
template <typename T>
void n2top(stack<T>& s, int n);

int main()
{
	int i, value;
	stack<int> s;

	// enter 5 integer values and push them onto s
	cout << "Enter 5 integer values: ";
	for (i=0;i < 5;i++)
	{
		cin >> value;
		s.push(value);
	}

	// move the second element to the top of the stack
	n2top(s, 2);
	// move the last element to the top of the stack
	n2top(s, s.size());
	cout << "The last element was moved to the top of the stack."
		  << endl << "Its value is " << s.top() << endl;

	cout << "Contents of the stack: ";
	// output and pop elements until s is empty
	while (!s.empty())
	{
		cout << s.top() << "  ";
		s.pop();
	}
	cout << endl;

	return 0;
}

template <typename T>
void n2top(stack<T>& s, int n)
{
	// algorithm uses a temporary stack
	stack<T> tmp;
	// use to save nth value
	T newTop;
	int i;

	// move top n-1 items from s to tmp. note that their order
	// on tmp is the opposite of their order on s
	for (i=1;i <= n-1;i++)
	{
		tmp.push(s.top());
		s.pop();
	}

	// save nth item and pop s
	newTop = s.top();
	s.pop();

	// move n-1 items from tmp back to s. their order is the
	// reverse of that on tmp, so they are in their original
	// order on s
	for (i=1;i <= n-1;i++)
	{
		s.push(tmp.top());
		tmp.pop();
	}

	// push the nth element onto the top of s
	s.push(newTop);
}

/*
Run:

Enter 5 integer values: 1 2 3 4 5
The last element was moved to the top of the stack.
Its value is 1
Contents of the stack: 1  4  5  3  2
*/
