#include <iostream>
#include <queue>

#include "d_dnode.h"
#include "d_nodel.h"

using namespace std;

int main()
{
	// doubly-linked list header
	dnode<int> *intList = new dnode<int>, *curr;
	// removes largest integer in the container
	priority_queue<int> pq;
	int n, i, intValue;

	cout << "Enter an integer: ";
	cin >> n;

	cout << "Enter " << n << " integer values: ";

	for (i=0;i < n;i++)
	{
		cin >> intValue;
		// insert the value before the header, which is at
		// the back of the list
		insert(intList, intValue);
	}

	cout << "Original list of values:    ";
	writeDLinkedList(intList);
	cout << endl;

	// scan the linked list and push each value onto the priority queue
	curr = intList->next;
	while (curr != intList)
	{
		pq.push(curr->nodeValue);
		curr = curr->next;
	}

	// scan the list again, this time from back to front
	curr = intList->prev;
	while (!pq.empty())
	{
		// get the current maximum value from the priority queue
		intValue = pq.top();
		// erase the value
		pq.pop();
		// assign the value to the current linked list element. the
		// largest value goes at the rear, the second largest next
		// to the rear, and so forth
		curr->nodeValue = intValue;

		// move backward
		curr = curr->prev;
	}

	cout << "Final list of values:    ";
	writeDLinkedList(intList);
	cout << endl;

	return 0;
}

/*
Run:

Enter an integer: 10
Enter 10 integer values: 3 5 -9 15 35 3 26 5 55 19
Original list of values:    3  5  -9  15  35  3  26  5  55  19
Final list of values:    -9  3  3  5  5  15  19  26  35  55
*/
