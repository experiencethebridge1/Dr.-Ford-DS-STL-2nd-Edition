#include <iostream>

#include "xrect.h"
#include "circle.h"

using namespace std;

int main()
{
	double r;

	cout << "Enter the radius of the inner circle: ";
	cin >> r;
	cout << endl;

	// declare the inner circle
	circle innerCircle(r);
	// inner square is 2r x 2r
	rectangle innerSquare(2*r, 2*r);
	// radius of outer circle is 1/2 diagonal of inner square
	circle outerCircle(innerSquare.diagonal()/2);

	// output the required results
	cout << "Perimeter outer circle/perimeter inner square = "
		  << outerCircle.circumference()/innerSquare.perimeter()
		  << endl;

	cout << "Area inner square/area inner circle = "
		  << innerSquare.area()/innerCircle.area()
		  << endl;

	return 0;
}

/*
Run 1:

Enter the radius of the inner circle: 2
Perimeter outer circle/perimeter inner square = 1.11072

Area inner square/area inner circle = 1.27324

Run 2:

Enter the radius of the inner circle: 100
Perimeter outer circle/perimeter inner square = 1.11072

Area inner square/area inner circle = 1.27324
*/
