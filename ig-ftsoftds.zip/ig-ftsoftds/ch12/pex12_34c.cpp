#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <fstream>
#include <cstdlib>

#include "d_hash.h"		// hash class
#include "d_timer.h"		// timer class

using namespace std;

class hFstr
{
	public:
		unsigned int operator () (const string& s) const
		{
			int i;
			unsigned int hashval = 0;

			for(i=0;i < s.length();i++)
				hashval += s[i];

			return hashval;
		}
};

int main()
{
	// hash table of string objects
	hash<string, hFstr> ht(1423);
	// use to read "sdict.dat" and "udict.dat"
	ifstream sdictStream, udictStream;
	string word;
	// time the hash table search
	timer t;

	// open "sdict.dat"
	sdictStream.open("sdict.dat");
	if (!sdictStream)
	{
		cerr << "Cannot open 'sdict.dat'" << endl;
		exit(1);
	}

	while (true)
	{
		sdictStream >> word;
		if (!sdictStream)
			break;

		ht.insert(word);
	}
	sdictStream.close();

	// open "udict.dat"
	udictStream.open("udict.dat");
	if (!udictStream)
	{
		cerr << "Cannot open 'udict.dat'" << endl;
		exit(1);
	}

	// start the timer and input words from "udict.dat".
	// look each word up in the hash table
	t.start();
	while (true)
	{
		udictStream >> word;
		if (!udictStream)
			break;

		ht.find(word);
	}
	// stop the timer and output the search time
	t.stop();
	cout << "Time for the search: " << t.time() << " seconds"
		  << endl;

	udictStream.close();

   return 0;
}

/*
Run:

Time for the search: 2.484 seconds
*/
