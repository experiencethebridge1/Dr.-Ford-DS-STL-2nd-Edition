#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>
#include <list>

#include "d_util.h"

using namespace std;

// remove duplicates from aList and arrange its elements
// in descending order
template <typename T>
void removeDuplicates(list<T>& aList);

main()
{
	// initital values for list aList
	int arr[] = {6, 7, 7, 2, 9, 7, 6, 6};
	int arrSize = sizeof(arr)/sizeof(int);
	list<int> aList(arr, arr+arrSize);

	// remove duplicates and put aList in desending
	// order
	removeDuplicates(aList);

	// output aList
	writeList(aList);

	return 0;
}

template <typename T>
void removeDuplicates(list<T>& aList)
{
	// use listIterator to move through aList
	list<T>::iterator listIterator;
	// unique elements of aList go into s
	set<T> s;
	// use setIterator to move through s
	set<T>::iterator setIterator;

	// traverse aList and insert each of its elements into s
	listIterator = aList.begin();
	while (listIterator != aList.end())
	{
		s.insert(*listIterator);
		listIterator++;
	}

	// erase all the elements in aList
	aList.erase(aList.begin(), aList.end());

	// move from smallest to largest in s and insert each
	// element on the front of aList. aList is then in
	// descending order without duplicates
	setIterator = s.begin();
	while (setIterator != s.end())
	{
		aList.push_front(*setIterator);
		setIterator++;
	}
}

/*
Run:

9  7  6  2
*/
