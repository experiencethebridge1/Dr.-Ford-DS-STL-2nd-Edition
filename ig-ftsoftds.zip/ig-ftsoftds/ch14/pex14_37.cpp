#include <iostream>
#include <string>
#include <functional>

#include "preqrec.h"
#include "d_pqueue.h"	// miniPQ class
#include "d_random.h"

using namespace std;

int main ()
{

	// mpq is a minimum priority queue of procReqRec objects
	miniPQ<procReqRec, less<procReqRec> > mpq;
	procReqRec record;
	char c;
	// replace 'X' by 'A' through 'J'
	string procName = "Process X";
	randomNumber rnd;

	// initialize the priority queue
	for (c='A';c <= 'J';c++)
	{
		// replace the last character by c
		procName[8] = c;
		// set the process name to be procName
		record.setName(procName);
		// set the priority as a random integer in the range
		// from 0 to 39
		record.setPriority(rnd.random(40));
		// insert record into the priority queue
		mpq.push(record);
	}

	// flush the priority queue and output its elements
	while (!mpq.empty())
	{
		cout << mpq.top() << endl;
		mpq.pop();
	}

	return 0;
}

/*
Run:

Process G: 0
Process J: 1
Process F: 1
Process B: 3
Process C: 17
Process E: 21
Process H: 23
Process D: 24
Process I: 26
Process A: 35
*/
