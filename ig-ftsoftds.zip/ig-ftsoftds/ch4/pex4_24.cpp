#include <iostream>
#include <vector>

#include "d_util.h"

using namespace std;

int main()
{
	vector<double> v;
	double zero = 0.0;
	// start max at -infinity
	double max = -1.0/zero;
	double sum = 0.0, x;

	cout << "Enter a sequence of real value. Terminate input with 0.0"
		  << endl;

	cin >> x;
	while (x != 0.0)
	{
		// insert x at the back of v
		v.push_back(x);
		// is x a new maximum
		if (x > max)
			max = x;

		// add x to the sum
		sum += x;

		// get a new value of x
		cin >> x;
	}

	// output the vector
	cout << "The vector = ";
	writeVector(v);
	cout << endl;

	// output the maximum and the average
	cout << "Maximum value = " << max << endl
		  << "Average value = " << sum/v.size() << endl;

   return 0;
}

/*
Run:

Enter a sequence of real value. Terminate input with 0.0
2.3 6.7 -9.84 15.53 36.3 19.8 -10.865 36.5 13.98 12.0 0
The vector = 2.3  6.7  -9.84  15.53  36.3  19.8  -10.865  36.5  13.98  12

Maximum value = 36.5
Average value = 12.2405
*/
