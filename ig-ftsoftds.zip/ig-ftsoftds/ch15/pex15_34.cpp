#include <iostream>
#include <iomanip>

#include "d_matrix.h"

using namespace std;

// computes a tour of (n*n)-1 moves (if there is one) such
// that the knight visits every square on the board once
// and once only. the matrix object board is of size n x n.
// the values of (i,j) when the function is first called are
// the starting square for the knight, and k = 1. as the search
// for a solution progresses, the current position of the knight
// is (i,j). if (i,j) is in the tour, it will be the kth square
// visited by the knight. we record this information by
// assigning board[i][j] = k. if the square (i,j) is not on
// the tour, board[i][j] = 0. the search for a solution is
// successful if k reaches n*n, and knight() returns true;
// otherwise, knight() returns false to indicate that a tour
// does not exist
bool knight(matrix<int>& board, int k, int i, int j);

int main()
{
	// board size and starting position
	int n, row, col;

	cout << "Enter the board size: ";
	cin >> n;
	cout << "Enter the starting row and column for the tour: ";
	cin >> row >> col;
	cout << endl;

	// declare the board
	matrix<int> board(n,n,0);

	// use for displaying the solution
	int i,j;

	// see if there is a tour and, if there is,
	// output the solution
	if (knight(board, 1, row, col) == true)
	{
		for (i=0;i < n;i++)
		{
			for (j=0;j < n;j++)
				cout << setw(4) << board[i][j];
			cout << endl;
		}
		cout << endl;
	}
	else
		cout << "No solution" << endl;

	return 0;
}

bool knight(matrix<int>& board, int k, int i, int j)
{
	// result of this call
	bool result;
	// u, v are coordinates of the next move
	int u, v, m;
	// the board size
	const int n = board.rows();
	// use these offsets to determine the next move
	// to (u,v) from (i,j)
	static int dx[] = {2,1,-1,-2,-2,-1,1,2},
				  dy[] = {1,2,2,1,-1,-2,-2,-1};

	// assume this square will be move k
   board[i][j] = k;

   if (k == n*n)
		// success! return true
      result = true;
   else
   {
		// assume result is false
		result = false; 
		m = 0;

		// look at all 8 possible moves and see if one
		// leads to a solution
		while ( (result == false) && (m < 8) ) 
		{
			// use dx, dy to determine (u,v)
			u = i + dx[m]; 
			v = j + dy[m];

			// if board[u][v] is on the board and has not been
			// visited, try to find a solution by moving there
			if ( (0 <= u) && (u <= n-1) && (0 <= v) && (v <= n-1) &&
              (board[u][v] == 0) ) 
				result = knight(board, k + 1, u, v);
			m++;
		}

		// if this position (i,j) did not work out, assign
		// 0 to board[i][j] and return false. we'll come
		// back here later
		if (result == false)
        board[i][j] = 0;
	}

	return result;
}

/*
Run 1:

Enter the board size: 5
Enter the starting row and column for the tour: 0 0

   1   6  15  10  21
  14   9  20   5  16
  19   2   7  22  11
   8  13  24  17   4
  25  18   3  12  23
  
Run 2:

Enter the board size: 5
Enter the starting row and column for the tour: 0 3

No solution

Run 3:

Enter the board size: 6
Enter the starting row and column for the tour: 0 0

   1  16   7  26  11  14
  34  25  12  15   6  27
  17   2  33   8  13  10
  32  35  24  21  28   5
  23  18   3  30   9  20
  36  31  22  19   4  29
  
Run 4:

Enter the board size: 6
Enter the starting row and column for the tour: 0 3

  28  13  10   1  26   3
  11  34  27   4   9  36
  14  29  12  35   2  25
  33  22  31  18   5   8
  30  15  20   7  24  17
  21  32  23  16  19   6
  
Run 5:

Enter the board size: 8
Enter the starting row and column for the tour: 0 0

   1  60  39  34  31  18   9  64
  38  35  32  61  10  63  30  17
  59   2  37  40  33  28  19   8
  36  49  42  27  62  11  16  29
  43  58   3  50  41  24   7  20
  48  51  46  55  26  21  12  15
  57  44  53   4  23  14  25   6
  52  47  56  45  54   5  22  13
*/