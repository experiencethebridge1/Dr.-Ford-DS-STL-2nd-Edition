#include <iostream>

#include "d_random.h"
#include "d_util.h"

using namespace std;

// sorts an array using the bubble sort
template <typename T>
void bubbleSort(T arr[], int n);

int main()
{
	int arr[10];
	int i;
	randomNumber rnd;

	// initialize arr with random integer values in the range 0 to 999
	for (i=0;i < 10;i++)
		arr[i] = rnd.random(1000);

	// output the array
	writeArray(arr, 10);
	cout << endl;

	// use bubble sort to order the array and output the array
	bubbleSort(arr, 10);
	writeArray(arr, 10);
	cout << endl;

   return 0;
}

template <typename T>
void bubbleSort(T arr[], int n)
{
	int i,j;             
	// index of last exchange 
	bool exchangeOccurs = true;
	T temp;

	// i is the index of last element in the current sublist
	i = n-1;

	// continue the process until we make no exchanges or
	// we have made n-1 passes
	while (i > 0 && exchangeOccurs) 
	{
		// assume no exchange occurs
		exchangeOccurs= false;
      
		// scan the sublist arr[0] to arr[i]
		for (j = 0; j < i; j++)
			// exchange a pair and assign true to exchangeOccurs
			if (arr[j+1] < arr[j])
			{
				temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
				exchangeOccurs= true;
			}
		// move i downward one element
		i--;
	}
}

/*
Run:

185  233  411  176  998  324  618  28  539  722

28  176  185  233  324  411  539  618  722  998
*/
