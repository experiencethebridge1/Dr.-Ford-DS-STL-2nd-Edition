#include <iostream>
#include <vector>

#include "d_sort.h"	// for insertionSort()

using namespace std;

int main()
{
	int n, i, val;
	vector<int> v;

	// prompt for n
	cout << "Enter n: ";
	cin >> n;

	// it is unlikely, but the user could enter n = 0
	if (n == 0)
		return 0;

	// input n integers and insert each at the back
	// of v
	cout << "Enter " << n << " integer values: ";
	for (i=0;i < n;i++)
	{
		cin >> val;
		v.push_back(val);
	}

	// use insertion sort to order v
	insertionSort(v);

	cout << "Median = " << v[n/2] << endl;

   return 0;
}

/*
Run 1:

Enter n: 7
Enter 7 integer values: 9 16 3 8 2 12 6
Median = 8

Run 2:

Enter n: 6
Enter 6 integer values: 15 34 18 6 55 78
Median = 34
*/
