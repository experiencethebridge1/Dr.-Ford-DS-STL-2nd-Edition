#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>

#include "d_util.h"		// for writeContainer()

using namespace std;

// sort v by copying its elements to and from a multiset
template <typename T>
void multisetSort(vector<T>& v);

int main()
{
	// arr determines the initial values for v
	int arr[] = {6, 2, 8, 3, 8, 4, 3};
	int arrSize = sizeof(arr)/sizeof(int);
	vector<int> v(arr, arr+arrSize);

	// sort v using a multiset
	multisetSort(v);

	// output the sorted vector
	cout << "Sorted vector: ";
	writeContainer(v.begin(), v.end());
	cout << endl;

	return 0;
}

template <typename T>
void multisetSort(vector<T>& v)
{
	// use ms to order the elements of v
	multiset<T> ms;
	// use msiter to copy elements from ms to v
	multiset<T>::iterator msiter;
	int i;

	// insert each element of v into the multiset
	for (i=0;i < v.size();i++)
		ms.insert(v[i]);

	// copy from the multiset to the vector
	msiter = ms.begin();
	i = 0;
	while (msiter != ms.end())
	{
		v[i] = *msiter;
		msiter++;
		i++;
	}
}

/*
Run:

Sorted vector: 2  3  3  4  6  8  8
*/
