#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <vector>

#include "d_random.h"

using namespace std;

// exchange the values of x and y
template <typename T>
void exchange(T& x, T& y);

// define mid = (first + last)/2. put v[first], v[mid] and v[last-1]
// in order  v[first] <= v[mid] <= v[last-1], swap pivot v[mid]
// with v[first+1] and return pivot
template <typename T>
T& median3(vector<T>& v, int first, int last);

// using the value from median3() as the pivot,
// locate the pivot in its final location so all elements
// to its left are <= to its value and all elements to the
// right are >= to its value. return the index of the pivot
template <typename T>
int pivotIndexMed_3(vector<T>& v, int first, int last);

// median-3 quicksort of v over range [first, last)
template <typename T>
void quicksortMed_3(vector<T>& v, int first, int last);

int main()
{
	vector<int> v;
	randomNumber rnd;
	int i;

	// initialize with 250 random integers in the range
	// 0 to 999
	for (i=0;i< 250;i++)
		v.push_back(rnd.random(1000));

	// sort using quicksort15()
	quicksortMed_3(v, 0, v.size());

	// output the first 10 values from v
	cout << "First 10 values: ";
	for (i=0;i < 10;i++)
		cout << v[i] << "  ";
	cout << endl;

	// output the last 10 values from v
	cout << "Last 10 values: ";
	for (i=v.size()-10;i < v.size();i++)
		cout << v[i] << "  ";
	cout << endl;

	return 0;
}

template <typename T>
void exchange(T& x, T& y)
{
	T tmp = x;

	x = y;
	y = tmp;
}

template <class T>
T& median3(vector<T>& v, int first, int last)
{
	int mid = (first + last) /2, right = last-1;

	if (v[mid] < v[first])
		exchange(v[first], v[mid]);
	if (v[right] < v[first] )
		exchange(v[first], v[right]);
	if (v[right] < v[mid])
		exchange(v[mid], v[right]);

	// v[first] <= v[mid] <= v[right]

	// exchange pivot v[mid] with v[first+1] and
	// return the pivot value
	exchange(v[mid], v[first+1]);

	return v[first+1];
}

template <typename T>
int pivotIndexMed_3(vector<T>& v, int first, int last)
{
	// index for the midpoint of [first,last) and the
	// indices that scan the index range in tandem
	int scanUp, scanDown;
	// pivot value and object used for exchanges
	T pivot;

	if (first == last)
		return last;
	else if (first == last-1)
		return first;
	else
	{
		pivot = median3(v, first, last);

		// initialize the indices scanUp and scanDown.
		scanUp = first + 2;
		scanDown = last - 2;

		// manage the indices to locate elements that are in
		// the wrong sublist; stop when scanDown <= scanUp
		for(;;)
		{
			// move up lower sublist; stop when scanUp enters
			// upper sublist or identifies an element >= pivot
			while (scanUp <= scanDown && v[scanUp] < pivot)
				scanUp++;

			// scan down upper sublist; stop when scanDown locates
			// an element <= pivot; we guarantee we stop at arr[first]
			while (pivot < v[scanDown])
				scanDown--;

			// if indices are not in their sublists, partition complete
			if (scanUp >= scanDown)
				break;

			// indices are still in their sublists and identify
			// two elements in wrong sublists. exchange
			exchange(v[scanUp], v[scanDown]);

			scanUp++;
			scanDown--;
		}

		// copy pivot to index (scanDown) that partitions sublists
		// and return scanDown
		v[first+1] = v[scanDown];
		v[scanDown] = pivot;
		return scanDown;
	}
}

template <typename T>
void quicksortMed_3(vector<T>& v, int first, int last)
{
   // index of the pivot
   int pivotLoc;

   // if the range is not at least two elements, return
   if (last - first <= 1)
		return;

	// if sublist has two elements, compare v[first] and
	// v[last-1] and exchange if necessary
   else if (last - first == 2)
	{
		if (v[last-1] < v[first])
			exchange(v[last-1], v[first]);
		return;
	}
   else
	{
		pivotLoc = pivotIndexMed_3(v, first, last);

		// make the recursive call
		quicksortMed_3(v, first, pivotLoc);

		// make the recursive call
		quicksortMed_3(v, pivotLoc+1, last);
	}
}

/*
Run:

First 10 values: 9  15  22  23  30  32  35  38  44  46
Last 10 values: 970  971  975  976  978  982  985  989  996  997
*/
