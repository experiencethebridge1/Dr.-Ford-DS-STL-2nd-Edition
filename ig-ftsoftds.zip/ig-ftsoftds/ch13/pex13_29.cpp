#include <iostream>
#include <vector>

#include "d_orderl.h"	// orderedList class
#include "d_except.h"	// for underflowError exception

using namespace std;

// return the median of v
template <class T>
T median (const vector<T>& v);

int main()
{
	vector<int> v;
	int n,i,value;

	// prompt for the vector size n and enter n values
	// into v
	cout << "Enter the vector size: ";
	cin >> n;
	cout <<"Enter " << n << " integer values: ";
	for (i=0;i < n;i++)
	{
		cin >> value;
		v.push_back(value);
	}

	// output the median
	cout << "The median of the " << n << " values is "
		  << median(v) << endl;

	return 0;
}

template <class T>
T median (const vector<T>& v)
{
	// ordered list used to find the median
	orderedList<T> ov;
	// use iter to move through ov to the median
	orderedList<T>::iterator iter;
	// capture the list size in n
	int n = v.size(), i;

	// throw an exception if the vector is empty
	if (n == 0)
		throw underflowError("median(): vector is empty");

	// insert each element of v into the ordered list ov
	for (i=0;i < n;i++)
		ov.insert(v[i]);

	// move forward in the ordered list n/2 times.
	// the iterator will then point at the median value
	iter = ov.begin();
	for(i=0;i < n/2;i++)
		iter++;

	// return the median
	return *iter;
}

/*
Run:

Enter the vector size: 5
Enter 5 integer values: 5 8 1 3 6
The median of the 5 values is 5
*/
