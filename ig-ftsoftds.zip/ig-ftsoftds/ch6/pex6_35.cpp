#include <iostream>
#include <string>
#include <list>

#include "d_random.h"
#include "d_listl.h"		// for insertOrder()
#include "d_util.h"		// for writeList()

using namespace std;

// removes duplicate values from an ordered list
template <typename T>
void rmOrderedDuplicates(list<T>& aList);

int main()
{
	list<char> charList;
	int i;
	randomNumber rnd;

	// initialize the ordered list charList with 200 characters
	// in the range from 'a' to 'z'
	for (i=0;i < 35;i++)
		insertOrder(charList, char('a' + rnd.random(26)));

	// remove duplicate values
	rmOrderedDuplicates(charList);

	cout << "The size of the modified list is " << charList.size()
		  << endl;
	// output the modified list
	cout << "The modified list is:" << endl;
	writeList(charList);

	return 0;
}

template <typename T>
void rmOrderedDuplicates(list<T>& aList)
{
	// current data value
   T currValue;
   // the two iterators we use
   list<T>::iterator curr, p;
    
   // start at the front of the list
   curr = aList.begin();
    
   // cycle through the list
   while(curr != aList.end())
   {	
		// record the current list data value
      currValue = *curr;

      // set p one element to the right of curr
      p = curr;
      p++;

      // move forward as long as we do not encounter the end
		// of the list and *p equals currValue. each iteration
		// erases the duplicate of currValue
      while(p != aList.end() && *p == currValue)
			// erase current element and move p forward
 			aList.erase(p++);
      // duplicates of currValue removed. move to the next
      // data value and repeat the process
      curr++;
   }
}

/*
Run:

The size of the modified list is 21
The modified list is:
a  b  c  d  e  f  k  l  m  n  o  p  q  r  s  t  v  w  x  y  z
*/
