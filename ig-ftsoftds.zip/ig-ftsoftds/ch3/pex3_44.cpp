#include <iostream>
#include <string>

#include "d_time24.h"
#include "d_search.h"	// for seqSearch()
#include "d_util.h"

using namespace std;

// returns the number of elements that occur only once in the array
template <typename T>
int numUnique(T arr[], int n);

int main()
{
	int intArr[8] = {2, 6, 2, 9, 8, 8, 2, 7};
	string strArr[9] = {"dog", "cat", "horse", "iguana", "horse", "bird",
							  "iguana", "bird", "iguana"};
	time24 timeArr[5] = {time24(5,15), time24(8,45), time24(15,0),
								time24(8,45), time24(15,0)};

	cout << "The number of unique items in intArr = "
		  << numUnique(intArr, 8) << endl;

	cout << "The number of unique items in strArr = "
		  << numUnique(strArr, 9) << endl;

	cout << "The number of unique items in timeArr = "
		  << numUnique(timeArr, 5) << endl;

   return 0;
}

template <typename T>
int numUnique(T arr[], int n)
{
	T target;
	int k = 0, i;

	for (i = 0; i < n; i++)
	{
		target = arr[i];
		// is target in the index range [0,i)?
		if (seqSearch(arr, 0, i, target) == i)
			// target is not in the index range [0,i). is it in the range
			// [i+1,n)?
			if (seqSearch(arr, i+1, n, target) == n)
				// target is unique. increment k
				k++;
	}

	return k;
}

/*
Run:

The number of unique items in intArr = 3
The number of unique items in strArr = 2
The number of unique items in timeArr = 1
*/
