#include <iostream>

#include "d_node.h"
#include "d_nodel.h"

using namespace std;

// inserts item at the front of the list only if it is greater
// than any current element in the list.
template <typename T>
void insertMax(node<T>* & front, const T& item);

int main()
{
	// list initially empty
	node<int> *front = NULL;
	int i, n, value;

	cout << "Enter an integer value: ";
	cin >> n;

	cout << "Input " << n << " integer values:" << endl;

	// input n integer values and call insertMax() for each one
	for (i=0;i < n;i++)
	{
		cin >> value;
		insertMax(front, value);
	}

	// output the list
	cout << "Built the list:" << endl;
	writeLinkedList(front);
	cout << endl;

	return 0;
}

template <typename T>
void insertMax(node<T>* & front, const T& item)
{
	// move curr through the list
	node<T> *curr = front;

	while (curr != NULL)
	{
		// if item is <= the current list value, break out
		// of the loop
		if (item <= curr->nodeValue)
			break;

		// move to the next list node
		curr = curr->next;
	}

	// if curr is NULL, we went through the whole list, so
	// item is > any list element
	if (curr == NULL)
		front = new node<T> (item, front);
}

/*
Run:

Run 1:

Enter an integer value: 5
Input 5 integer values:
5 4 3 2 1
Built the list:
5

Run 2:

Enter an integer value: 4
Input 4 integer values:
4 3 2 1
Built the list:
4

Run 3:

Enter an integer value: 6
Input 6 integer values:
3 6 2 9 4 8
Built the list:
9 6 3
*/
