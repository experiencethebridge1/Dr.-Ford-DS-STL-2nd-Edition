#include <iostream>
#include <fstream>
#include <iomanip>
#include <ctype.h>	// character handling functions
#include <string>

#include "d_sort.h"	// for heapSort()

using namespace std;

class charRec
{
	public:
		char key;
		int count;

		friend bool operator< (const charRec& lhs, const charRec& rhs)
		{
			return lhs.count < rhs.count;
		}
};

int main()
{
	// use to perform I/O with a binary file
	fstream f;
	// stream for input of a textfile
	ifstream fin;
	// use to create records in the binary file
	charRec rec;
	char c;
	string fileName;
	int i;
	// use to sort charaters by frequency
	vector<charRec> v;

	// open the binary file for input and output and truncate any
	// previous version of the file
	f.open("letcount.dat", ios::in | ios::out | ios::binary | ios::trunc);

	// create 26 records in the binary file. record 0 has
	// key 'A', record 1 has key 'B', and so forth
	rec.count = 0;
	for (c='A';c <= 'Z';c++)
	{
		// assign c to the key field of rec
		rec.key = c;
		// output rec to the binary file
		f.write((char *)&rec, sizeof(charRec));
	}

	// prompt for and open a text file
	cout << "Enter a file name: ";
	cin >> fileName;
	cout << endl;

	fin.open(fileName.c_str());
	if (!fin)
	{
		cerr << "Cannot open '" << fileName << "'" << endl;
		exit(1);
	}

	while (fin.get(c))
	{
		// see if c is alphabetic
		if (isalpha(c))
		{
			// make sure c is uppercase
			c = toupper(c);

			// seek to record c - 'A'
			f.seekg((c-'A')*sizeof(charRec), ios::beg);

			// read the record and update its count
			f.read((char *)&rec, sizeof(charRec));
			rec.count++;

			// move the file pointer backward to the record
			// we just read and write the new data to the file
			f.seekg(-int(sizeof(charRec)), ios::cur);
			f.write((char *)&rec, sizeof(charRec));
		}
	}

	// rewind to the beginning of the file
	f.seekg(0, ios::beg);

	// read through the file and output the
	// characters and their frequencies. also
	// insert each record into vector v
	cout << "Character frequencies:" << endl;
	for (i=1;i <= 26;i++)
	{
		f.read((char *)&rec, sizeof(charRec));
		cout << rec.key << ": " << setw(6) << rec.count << "  ";
		v.push_back(rec);
		if (i % 5 == 0)
			cout << endl;
	}
	cout << endl << endl;

	// use heapsort to sort v in decreasing order of count
	// and output the results
	heapSort(v, less<charRec>());
	for (i=0;i < v.size();i++)
	{
		cout << v[i].key << ": " << setw(6)
			  << v[i].count << "  ";
		if ((i+1) % 5 == 0)
			cout << endl;
	}
	cout << endl;

	return 0;
}

/*
Run:

Enter a file name: dict.dat

Character frequencies:
A:  16431  B:   4113  C:   8217  D:   5773  E:  20099
F:   2665  G:   4124  H:   5181  I:  13978  J:    430
K:   1929  L:  10033  M:   5834  N:  12071  O:  12710
P:   5518  Q:    377  R:  13423  S:  10179  T:  12798
U:   6479  V:   1891  W:   1956  X:    620  Y:   3625
Z:    432

E:  20099  A:  16431  I:  13978  R:  13423  T:  12798
O:  12710  N:  12071  S:  10179  L:  10033  C:   8217
U:   6479  M:   5834  D:   5773  P:   5518  H:   5181
G:   4124  B:   4113  Y:   3625  F:   2665  W:   1956
K:   1929  V:   1891  X:    620  Z:    432  J:    430
Q:    377
*/