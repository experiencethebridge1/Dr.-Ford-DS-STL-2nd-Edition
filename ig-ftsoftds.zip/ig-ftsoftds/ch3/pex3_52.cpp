#include <iostream>

#include "d_sort.h"
#include "d_random.h"
#include "d_timer.h"

using namespace std;

// sorts an array using the bubble sort
template <typename T>
void bubbleSort(T arr[], int n);

// time sorting arr1 with selection sort and arr2 with
// bubble sort. output results
void timeSorts(int arr1[], int arr2[], int n);

int main()
{
	int arr1[50000], arr2[50000];
	int i;
	randomNumber rnd;

	// time sorting of 50,000 random integers in the range 0..999999 
	for (i=0;i < 50000;i++)
		arr1[i] = arr2[i] = rnd.random(1000000);
	timeSorts(arr1,arr2, 50000);
	cout << endl;

	// time sorting of the 50,0000 integers 1, 2, 3, ..., 50000
	for (i=0;i < 50000;i++)
		arr1[i] = arr2[i] = i+1;
	timeSorts(arr1,arr2, 50000);
	cout << endl;


	// time sorting of the 50,0000 integers 50000, 49999, ..., 1
	for (i=0;i < 50000;i++)
		arr1[i] = arr2[i] = 50000-i;
	timeSorts(arr1,arr2, 50000);
	cout << endl;

   return 0;
}

template <typename T>
void bubbleSort(T arr[], int n)
{
	int i,j;             
	// index of last exchange 
	bool exchangeOccurs = true;
	T temp;

	// i is the index of last element in the current sublist
	i = n-1;

	// continue the process until we make no exchanges or
	// we have made n-1 passes
	while (i > 0 && exchangeOccurs) 
	{
		// assume no exchange occurs
		exchangeOccurs= false;
      
		// scan the sublist arr[0] to arr[i]
		for (j = 0; j < i; j++)
			// exchange a pair and assign true to exchangeOccurs
			if (arr[j+1] < arr[j])
			{
				temp = arr[j];
				arr[j] = arr[j+1];
				arr[j+1] = temp;
				exchangeOccurs= true;
			}
		// move i downward one element
		i--;
	}
}

void timeSorts(int arr1[], int arr2[], int n)
{
	timer t;

	t.start();
	selectionSort(arr1,n);
	t.stop();
	cout << "Time for selection sort = " << t.time() << endl;

	t.start();
	bubbleSort(arr2,n);
	t.stop();
	cout << "Time for bubble sort = " << t.time() << endl;
}

/*
Run:

Time for selection sort = 19.798
Time for bubble sort = 41.42

Time for selection sort = 19.758
Time for bubble sort = 0

Time for selection sort = 20.87
Time for bubble sort = 45.445
*/
