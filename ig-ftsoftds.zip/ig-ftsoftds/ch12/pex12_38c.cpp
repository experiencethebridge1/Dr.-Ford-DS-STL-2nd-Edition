#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>
#include <cstdlib>		// for exit()
#include <string>
#include <ctype.h>		// for character functions isalpha(), etc.

#include "openhash.h"	// openHash class
#include "d_hashf.h"		// hash function object types. use hFstring

using namespace std;

// extract a word from fin
ifstream& getWord(ifstream& fin, string& w);

int main()
{
	// doument name and a string object used to read words
	// from the document
	string document, word;
	// input streams for the dictionary and the document
	ifstream dictIn, docIn;
	// hash table with 35353 slots
	openHash<string, hFstring> dictionary(35353);
	// only output "Misspelled words" if there are words misspelled
	bool foundMisspelledWord = false;

	// open the dictionary
	dictIn.open("dict.dat");
	if (!dictIn)
	{
		cerr << "Cannot open 'dict.dat'" << endl;
		exit(1);
	}

	// insert the words into the dictionary
	while (dictIn >> word)
		dictionary.insert(word);

	// prompt for the document name and open it
	cout << "Enter the document name: ";
	cin >> document;

	docIn.open(document.c_str());
	if (!docIn)
	{
		cerr << "Cannot open " << document << endl;
		exit(1);
	}

	// read words one at a time from the document
	while (getWord(docIn,word))
		// look the word up in the dictionary (hash table)
		if (dictionary.find(word) == dictionary.end())
		{
			// the first time we find a misspelled word, output
			// a label and then set foundMisspelledWord to true
			// so we won't do it again
			if (foundMisspelledWord == false)
			{
				cout << "Misspelled words:" << endl << endl;
				foundMisspelledWord = true;
			}
			cout << word << endl;
		}

	return 0;
}

ifstream& getWord(ifstream& fin, string& w)
{
	char c;

	w = "";	// clear the string of characters

	while (fin.get(c) && !isalpha(c))
		;	// do nothing. just ignore c

	// return on end-of-file
	if (fin.eof())
		return fin;

	// record first letter of the word
	w += tolower(c);

	// collect letters and digits
	while (fin.get(c) && (isalpha(c) || isdigit(c)))
		w += tolower(c);

	return fin;
}

/*
File "spelltst.txt"

When a persn types a documnt, he or she
often makes mistakes and mispells one or
more of teh sords.

Run:

Enter the document name: spelltst.txt
Misspelled words:

persn
types
documnt
makes
mistakes
mispells
teh
sords
*/
