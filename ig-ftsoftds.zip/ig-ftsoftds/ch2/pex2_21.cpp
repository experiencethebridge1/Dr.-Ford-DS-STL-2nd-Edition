#include <iostream>

#include "square.h"
#include "circle.h"

using namespace std;

int main()
{
   // 4 x 4 inner square
   square innerSq(4);
	// circle circumscribes innerSq
	circle circ(innerSq.diagonal()/2);
	// square circumscribes circ
	square outerSq(2*circ.getRadius());

   cout << "Area of the crossline region = "
		  << circ.area() - innerSq.area() << endl;

	cout << "Perimeter of the shaded region = "
		  << outerSq.perimeter() + circ.circumference() << endl;

   return 0;
}

/*
Run:

Area of the crossline region = 9.13274
Perimeter of the shaded region = 40.3989
*/
