#include <iostream>

#include "d_tnodel.h"

using namespace std;

// output the nodes of t in RLN order
template <typename T>
void rlnOutput(tnode<T> *t, const string& separator = "  ");

int main()
{
	tnode<char> *tree1;

	// tree1 is root of Tree 1
	tree1 = buildTree(1);

	// output Tree 1 in RLN order
	rlnOutput(tree1);
	cout << endl;

	return 0;
}

template <typename T>
void rlnOutput(tnode<T> *t, const string& separator)
{
   // the recursive scan terminates on a empty subtree
   if (t != NULL)
   {
      rlnOutput(t->right, separator);		// descend right
      rlnOutput(t->left, separator);		// descend left
      cout << t->nodeValue << separator;	// output the node
   }
}

/*
Run:

I  H  F  C  G  E  D  B  A
*/
