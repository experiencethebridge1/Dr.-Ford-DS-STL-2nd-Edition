#ifndef ACCUMULATOR_CLASS
#define ACCUMULATOR_CLASS

template <typename T>
class accumulator
{
	public:
		accumulator(const T& value = T());	// constructor
		T getTotal() const;              	// return total
		void addValue(const T& value); 		// add (+) value to total
	private:
      // total accumulated by the object
		T total;
};

template <typename T>
accumulator<T>::accumulator(const T& value): total(value)
{}

template <typename T>
T accumulator<T>::getTotal() const
{ return total; }

template <typename T>
void accumulator<T>::addValue(const T& value)
{ total += value; }

#endif	// ACCUMULATOR_CLASS
