#include <iostream>

using namespace std;

// output integer n as a fixed length base 2 (binary) number
void dec2bin(int n, int length);

int main()
{
	int n, len;
	int i;

	for (i=0;i < 5;i++)
	{
		cout << "Input a number and the length for its binary representation: ";
		cin >> n >> len;
		dec2bin(n, len);
		cout << endl << endl;
	}

   return 0;
}

void dec2bin(int n, int length)
{
	// no more digits to output
	if (length == 0)
			return;
	else
	{
		// output n/2, which contains the 2's digit, the 4's digit,
		// and so forth of n using length-1 digits
		dec2bin(n/2,length-1);
		// output the 1's digit
		cout << n % 2;
	}
}

/*
Run:

Input a number and the length for its binary representation: 11 5
01011

Input a number and the length for its binary representation: 97 8
01100001

Input a number and the length for its binary representation: 20 6
010100

Input a number and the length for its binary representation: 13 4
1101

Input a number and the length for its binary representation: 65 7
1000001
*/
