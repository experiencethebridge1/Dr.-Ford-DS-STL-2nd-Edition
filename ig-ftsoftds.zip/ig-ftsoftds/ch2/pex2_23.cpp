#include <iostream>

#include "d_time24.h"

using namespace std;

int main()
{
	time24 timeArr[8] = {time24(8,00), time24(9,30), time24(8,30),
								time24(11,00), time24(13,00), time24(12,30),
								time24(12,00), time24(16,00)};
	int i;

	// output the duration between timeArr[i] and timeArr[i+1],
	// for 0 <= i < 8-1 = 7
	for (i=0;i < 7;i++)
	{
		// calling duration() may cause a rangeError exception. enclose
		// the output statement in a try block
		try
		{
			cout << timeArr[i].duration(timeArr[i+1]) << endl;
		}

		// if a rangeError exception occurs, catch it here and output
		// the error message
		catch (const rangeError& re)
		{
			cout << re.what() << endl;
		}
	}

   return 0;
}

/*
Run:

 1:30
time24 duration(): argument is an earlier time
 2:30
 2:00
time24 duration(): argument is an earlier time
time24 duration(): argument is an earlier time
 4:00
*/
