#include <iostream>

#include "xgrade.h"

using namespace std;

int main()
{	
	// current record for dHarris
	gradeRecord dHarris("558-29-4424", 100, 180);


	// output GPA for the student
	cout << "dHarris GPA = " << dHarris.gpa() << endl;

	// replace 4 units of D by 4 units of A
	dHarris.replaceGrade(4, 4, 4, 16);
	// output the new GPA for dHarris
	cout << "After replacing 4 units of D by 4 units of A:"
		  << endl << "GPA = " << dHarris.gpa() << endl;

	// replace 8 units of F (0 grade points) by 8 units
	// of B (8*3 = 24 grade points)
	dHarris.replaceGrade(8, 0, 8, 24);
	cout << "dHarris substitutes a B for an F in two 4-unit classes:"
		  << endl << "GPA = " << dHarris.gpa() << endl;

	return 0;
}


/*
Run:

dHarris GPA = 1.8
After replacing 4 units of D by 4 units of A:
GPA = 1.92
dHarris substitutes a B for an F in two 4-unit classes:
GPA = 2.16
*/