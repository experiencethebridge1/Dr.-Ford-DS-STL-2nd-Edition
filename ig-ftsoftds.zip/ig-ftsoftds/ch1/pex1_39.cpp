#include <iostream>

#include "hilo.h"

using namespace std;

int main()
{
	// guess holds player input
	int guess, result;
	// number of tries. used in loop control
	int numTries;
	// specifies whether player wins or loses. used in
	// loop control
	bool success = false;
	// object used to play the game
	playHiLow player;
	
	// a player always has at least one try
	numTries = 1;
	// continue until player wins or has made 10 tries
	while (success == false && numTries <= 10)
	{
		// input player's number
		cout << "Guess: ";
		cin >> guess;

		// indicate whether the guess is higher or lower
		// than the target. if the player guesses the
		// number, set success to true and cause loop
		// termination
		result = player.makeGuess(guess);
		if (result < 0)
			cout << "LOWER" << endl;
		else if (result > 0)
			cout << "HIGHER" << endl;
		else
			success = true;

		// determine number of the next guess
		numTries++;
	}

	// output result of the game
	if (success)
		cout << "You win!" << endl;
	else
	{
		cout << "Sorry. ";
		player.writeTarget();
		cout << endl;
	}

	return 0;
}

/*
Run:

Guess: 500
HIGHER
Guess: 750
LOWER
Guess: 625
LOWER
Guess: 565
LOWER
Guess: 530
LOWER
Guess: 515
HIGHER
Guess: 522
HIGHER
Guess: 526
HIGHER
Guess: 528
You win!
*/
