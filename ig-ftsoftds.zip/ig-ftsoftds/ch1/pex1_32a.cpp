#include <iostream>

#include "grade.h"

using namespace std;

int main()
{	
	// current record for tMartin
	gradeRecord tMartin("716-29-4238", 20, 50);

	// output initial GPA
	cout << "Initial GPA = " << tMartin.gpa() << endl;

	// add 15 units and 40 grade points
	tMartin.updateGradeInfo(15, 40);

	// output the new record
	cout << "Update grade information:" << endl;
	tMartin.writeGradeInfo();

	return 0;
}


/*
Run:

Initial GPA = 2.5
Update grade information:
Student:  716-29-4238  Units:  35  GradePts:  90  GPA:  2.57143
*/