#ifndef QUEUE_CLASS_WITH_PRIORITY_QUEUE
#define QUEUE_CLASS_WITH_PRIORITY_QUEUE

#include <functional>	// for function object type less<T>

#include "d_pqueue.h"
#include "d_except.h"

#ifdef _MSC_VER
// VC++ 6.0 requires the following pre-class declaration
// statements
template <typename T>
class priorityData;

template <typename T>
bool operator< (const priorityData<T>& lhs,
					 const priorityData<T>& rhs);

template <typename T>
bool operator> (const priorityData<T>& lhs,
					 const priorityData<T>& rhs);
#endif	// _MSC_VER

// priorityData objects are maintained by the
// miniQueue implementation
template <typename T>
class priorityData
{
	public:
		T data;
		int priority;

	// order objects by priorityData
	friend bool operator< (const priorityData<T>& lhs,
								  const priorityData<T>& rhs)
	{
		return lhs.priority < rhs.priority;
	}

	friend bool operator> (const priorityData<T>& lhs,
								  const priorityData<T>& rhs)
	{
		return lhs.priority > rhs.priority;
	}
};

template <typename T>
class miniQueue
{
    public:
		miniQueue();
			// constructor; create an empty queue
		
		void push(const T& item);
			// insert an element at the back of the queue.
			// Postcondition: the queue has one more element

		void pop();
			// remove an element from the front of the queue.
			// Precondition: the queue is not empty. if the
			// queue is empty, the function throws the
			// underflowError exception
			// Postcondition: the queue has one less element

		T& front();
			// return a reference to the front of the queue.
			// Preconditon: the queue is not empty. if the
			// the queue is empty, the function throws the
			// underflowError exception
		const T& front() const;
			// constant version of front()
                
     int size() const;
			// return the queue size
		
		bool empty() const;
			// is the queue empty?

    private:
		int priorityLevel;
			// priority of the next item to come into the queue.
			// increases after each insertion
		miniPQ<priorityData<T>, less<priorityData<T> > > pq;
			// maintains the queue items and queue size. it is
			// a minimum priority queue ordered by the priority
			// field of its priorityData objects
};

// initial priorityLevel is 0
template <typename T>
miniQueue<T>::miniQueue(): priorityLevel(0)
{}

template <typename T>
void miniQueue<T>::push(const T& item)
{
	priorityData<T> pd;

	// initialize pd
	pd.data = item;
	pd.priority = priorityLevel;

	// increment the priority level
	priorityLevel++;

	pq.push(pd);
}

template <typename T>
void miniQueue<T>::pop()
{
	if (pq.size() == 0)
		throw underflowError("miniQueue pop(): queue is empty");

	// pops the lowest priority item, which is the one waiting
	// the longest
	pq.pop();
}

template <typename T>
T& miniQueue<T>::front()
{
	if (pq.size() == 0)
		throw underflowError("miniQueue front(): queue is empty");

	// returns the lowest priority item, which is the one waiting
	// the longest
	return pq.top().data;
}

template <typename T>
const T& miniQueue<T>::front() const
{
	if (pq.size() == 0)
		throw underflowError("miniQueue front(): queue is empty");

	// returns the lowest priority item, which is the one waiting
	// the longest
	return pq.top().data;
}
          
template <typename T>
int miniQueue<T>::size() const
{
	return pq.size();
}

template <typename T>
bool miniQueue<T>::empty() const
{
	return pq.empty();
}

#endif	// QUEUE_CLASS_WITH_PRIORITY_QUEUE
 