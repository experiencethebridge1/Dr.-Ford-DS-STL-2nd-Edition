#include <iostream>
#include <string>

#include "accum_t.h"

using namespace std;

int main()
{
	accumulator<string> strAcc("template");

	strAcc.addValue("-based");
	strAcc.addValue(" container");
	cout << strAcc.getTotal() << endl;

   return 0;
}

/*
Run:

template-based container
*/
