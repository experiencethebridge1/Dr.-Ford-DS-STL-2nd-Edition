#include <iostream>

#include "circle.h"
#include "d_rect.h"

using namespace std;

int main()
{
	double r;

	cout << "Enter the radius of the circle: ";
	cin >> r;

	// declare a circle of radius r
	circle circ(r);
	// rect circumscribes the circle
	rectangle rect(2*r, 2*r);

	cout << "The area between the circle and the circumscribed "
			  "square is " << (rect.area() - circ.area()) << endl;

	return 0;
}

/*
Run:

Enter the radius of the circle: 5
The area between the circle and the circumscribed square is 21.4602
*/
