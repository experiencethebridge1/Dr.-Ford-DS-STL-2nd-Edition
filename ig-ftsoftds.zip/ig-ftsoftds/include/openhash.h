#ifndef OPENPROBE_HASH_CLASS
#define OPENPROBE_HASH_CLASS

#include <vector>

#include "d_except.h"

template <class T, class HashFunc>
class openHash
{
	public:

#include "openiter.h"
			// hash table iterator nested classes

		openHash(int nbuckets, const HashFunc& hfunc = HashFunc());
			// constructor specifying the number of buckets in the hash table
			// and the hash function
      
      openHash(T *first, T *last, int nbuckets, const HashFunc& hfunc = HashFunc());
			// constructor with arguments including a pointer range
			// [first, last) of values to insert, the number of
			// buckets in the hash table, and the hash function
      
      bool empty() const;
			// is the hash table empty?
      int size() const;
			// return number of elements in the hash table

		iterator find(const T& item);
		const_iterator find(const T& item) const;
			// return an iterator pointing at item if it is in the
			// table; otherwise, return end()

      pair<iterator,bool> insert(const T& item);
			// if item is not in the table, insert it and
			// return a pair whose iterator component points
			// at item and whose bool component is true. if item
			// is in the table, return a pair whose iterator
			// component points at the existing item and whose
			// bool component is false.
			// Precondition: there must be an available table slot
			// for item. if the table is full, the function throws
			// the overflowError exception.
			// Postcondition: the table size increases by 1 if item
			// is not in the table

		int erase(const T& item);
			// if item is in the table, erase it and return 1;
			// otherwise, return 0
			// Postcondition: the table size decreases by 1 if
			// item is in the table
		void erase(iterator pos);
			// erase the item pointed to by pos.
			// Precondition: the table is not empty and pos points
			// to an item in the table. if the table is empty, the
			// function throws the underflowError exception. if the
			// iterator is invalid, the function throws the
			// referenceError exception.
			// Postcondition: the tree size decreases by 1
		void erase(iterator first, iterator last);
			// erase all items in the range [first, last).
			// Precondition: the table is not empty. if the table
			// is empty, the function throws the underflowError
			// exception.
			// Postcondition: the size of the table decreases by
			// the number of elements in the range [first, last)

      iterator begin();
			// return an iterator positioned at the start of the
			// hash table
      const_iterator begin() const;
			// constant version
      iterator end();
			// return an iterator positioned past the last element of the
			// hash table
      const_iterator end() const;
			// constant version

	private:

		class tableRecord
		{
			public:
				// entry available (true or false)
				bool available;
				// data was previously deleted (true or false)
				bool deletedData;

				// the data itself
				T data;

				tableRecord(): available(true), deletedData(false)
				{}
		};

		int numBuckets;
			// number of buckets in the table
		vector<tableRecord> bucket;
			// the hash table is a vector of tableRecord entries
		int hashTableSize;
			// number of elements in the hash table
		HashFunc hf;
			// the hash function
};


// initialize the hash table. assign table size of 0, and the
// number of buckets as nbuckets. assign the hash function as
// hfunc and allocate the hash table with nbuckets entries. the
// default constructor for tableRecord creates each entry with
// avaiable = true and deletedData = false
template <class T, class HashFunc>
openHash<T, HashFunc>::openHash(int nbuckets, const HashFunc& hfunc):
		hashTableSize(0), numBuckets(nbuckets), hf(hfunc),
		bucket(nbuckets)
{}

// create an empty hash table just as we do for the previous
// constructor, and then insert each element in the range
// [first, last) into the table
template <class T, class HashFunc>
openHash<T, HashFunc>::openHash(T *first, T *last, int nbuckets,
							 const HashFunc& hfunc):
		hashTableSize(0), numBuckets(nbuckets), hf(hfunc),
		bucket(nbuckets)
{
	T *p = first;

	while (p != last)
	{
		insert(*p);
		p++;
	}
}

template <class T, class HashFunc>
bool openHash<T, HashFunc>::empty() const
{
	return hashTableSize == 0;
}

template <class T, class HashFunc>
int openHash<T, HashFunc>::size() const
{
	return hashTableSize;
}

template <class T, class HashFunc>
openHash<T, HashFunc>::iterator
openHash<T, HashFunc>::find(const T& item)
{
	// compute the hash index
	int index = int(hf(item) % numBuckets), origindex;
	// foundItem indicates whether the search is successful,
	// and continueSearch is used to stop the do while loop
	bool foundItem = false, continueSearch = true;

	// save the original hash index
	origindex = index;

	// cycle through the table, ignoring any slot with
	// deletedData == true until we locate item,
	// find any emtpy slot, or search every slot
	do
	{
		if (!bucket[index].deletedData)
			if (bucket[index].available)
				continueSearch = false;
			else if(bucket[index].data == item)
			{
				foundItem = true;
				continueSearch = false;
			}
			else
				// advance forward
				index = (index+1) % numBuckets;
		else
			// advance forward
			index = (index+1) % numBuckets;
	} while (continueSearch && index != origindex);

	if (foundItem)
		return iterator(this, index);
	else
		return iterator(this, -1);
}

template <class T, class HashFunc>
openHash<T, HashFunc>::const_iterator
openHash<T, HashFunc>::find(const T& item) const
{
	// compute the hash index
	int index = int(hf(item) % numBuckets), origindex;
	// foundItem indicates whether the search is successful,
	// and continueSearch is used to stop the do while loop
	bool foundItem = false, continueSearch = true;

	// save the original hash index
	origindex = index;

	// cycle through the table, ignoring any slot with
	// deletedData == true until we locate item,
	// find any emtpy slot, or search every slot
	do
	{
		if (!bucket[index].deletedData)
			if (bucket[index].available)
				continueSearch = false;
			else if(bucket[index].data == item)
			{
				foundItem = true;
				continueSearch = false;
			}
			else
				// advance forward
				index = (index+1) % numBuckets;
		else
			// advance forward
			index = (index+1) % numBuckets;
	} while (continueSearch && index != origindex);

	if (foundItem)
		return const_iterator(this, index);
	else
		return const_iterator(this, -1);
}

template <class T, class HashFunc>
pair<openHash<T, HashFunc>::iterator,bool>
openHash<T, HashFunc>::insert(const T& item)
{
	// compute the hash index
	int index = int(hf(item) % numBuckets), origindex;
	// foundItem indicates whether the item is already
	// in the table. foundAvail slot determines
	// whether an empty slot that is not marked with
	// deleteData is found for item
	bool foundItem = false, foundAvailSlot = false;
	// continueSearch is used to stop the do while loop
	bool continueSearch = true;
	// use to mark the first occurrence of a slot in
	// which a deletion has taken place
	int firstDeletedDataLoc = -1;
	// construct the return value in this pair
	pair<iterator, bool> returnValue;

	// save the original hash index
	origindex = index;

	// cycle through the table, ignoring any slot with
	// deletedData == true until we locate item,
	// find any emtpy slot, or search every slot
	do
	{
		if (!bucket[index].deletedData)
			if (bucket[index].available)
			{
				// we have found an empty table entry at
				// which a previous deletion did not occur
				foundAvailSlot = true;
				continueSearch = false;
			}
			else if(bucket[index].data == item)
			{
				foundItem = true;
				continueSearch = false;
			}
			else
				// advance forward
				index = (index+1) % numBuckets;
		else
		{
			// we are at a table entry at which a deletion took
			// place. if this is the first such location
			// we have found, indicate this by assigning
			// firstDeletedDataLoc the location
			if (firstDeletedDataLoc == -1)
				firstDeletedDataLoc = index;

			// advance forward
			index = (index+1) % numBuckets;
		}
	} while (continueSearch && index != origindex);

	if (foundItem)
		// item already in the table at index. construct
		// a pair whose first component points at index
		// and whose second component is false
		returnValue = pair<iterator,bool> (iterator(this, index), false);
	else if (foundAvailSlot)
	{
		// item not already in the table, and an empty slot found
		// at which no data was previously deleted. insert item and
		// mark the slot unavailable. construct a pair whose first
		// component points at index and whose second component is true
		bucket[index].data = item;
		bucket[index].available = false;
		returnValue = pair<iterator,bool> (iterator(this,index), true);

		// increment the table size
		hashTableSize++;
	} else if (firstDeletedDataLoc != -1)
	{
		// item not already in the table, and only a table slot at which
		// a previous deletion occurred is available. insert item,
		// mark the slot unavailable, and set deletedData to false.
		// construct a pair whose first component points at index and
		// whose second component is true
		bucket[firstDeletedDataLoc].data = item;
		bucket[firstDeletedDataLoc].available = false;
		bucket[firstDeletedDataLoc].deletedData = false;
		returnValue = pair<iterator,bool> (iterator(this,index), true);

		// increment the table size
		hashTableSize++;
	}
	else
		throw overflowError("openHash insert(): hash table full");

	return returnValue;
}

template <class T, class HashFunc>
int openHash<T, HashFunc>::erase(const T& item)
{
	// search for item using find()
	iterator iter = find(item);
	// will be 1 or 0
	int count;

	// see if find() was successful
	if (iter != end())
	{
		// item is in the table at index iter.currentIndex.
		// mark it as deleted and available, decrement
		// the hash table size and set count = 1
		bucket[iter.currentIndex].deletedData = true;
		bucket[iter.currentIndex].available = true;
		hashTableSize--;
		count = 1;
	}
	else
		// item is not in the table
		count = 0;

	return count;
}

template <class T, class HashFunc>
void openHash<T, HashFunc>::erase(iterator pos)
{
	// check for an empty table or an invalid iterator
	if (hashTableSize == 0)
		throw
			underflowError("openHash erase(pos): hash table empty");
	if (pos.currentIndex == -1)
		throw
			referenceError("openHash erase(pos): invalid iterator");

	// mark the slot as deleted and available
	bucket[pos.currentIndex].deletedData = true;
	bucket[pos.currentIndex].available = true;

	// decrement the hash table size
	hashTableSize--;
}

template <class T, class HashFunc>
void openHash<T, HashFunc>::erase(iterator first, iterator last)
{
	// check for an empty hash table
	if (hashTableSize == 0)
		throw
			underflowError("openHash erase(first, last): hash table empty");

	// erase each element of the range [first, last)
	while (first != last)
		erase(first++);
}

template <class T, class HashFunc>
openHash<T, HashFunc>::iterator openHash<T, HashFunc>::begin()
{
	iterator returnIter;
	int i;

	// if the table is empty, return iterator is end()
	if (hashTableSize == 0)
		returnIter = iterator(this, -1);
	else
	{
		// the table is not empty. start at index 0 and look
		// for an occupied table slot
		i = 0;
		while(bucket[i].available)
			i++;

		// build an iterator starting at slot i
		returnIter = iterator(this, i);
	}

	return returnIter;
}

template <class T, class HashFunc>
openHash<T, HashFunc>::const_iterator openHash<T, HashFunc>::begin() const
{
	const_iterator returnIter;
	int i;

	// if the table is empty, return iterator is end()
	if (hashTableSize == 0)
		returnIter = const_iterator(this, -1);
	else
	{
		// the table is not empty. start at index 0 and look
		// for an occupied table slot
		i = 0;
		while(bucket[i].available)
			i++;

		// build an iterator starting at slot i
		returnIter = const_iterator(this, i);
	}

	return returnIter;
}

template <class T, class HashFunc>
openHash<T, HashFunc>::iterator openHash<T, HashFunc>::end()
{
	return iterator(this, -1);
}

template <class T, class HashFunc>
openHash<T, HashFunc>::const_iterator openHash<T, HashFunc>::end() const
{
	return const_iterator(this, -1);
}

#endif	// OPENPROBE_HASH_CLASS
