#include "sqshape.h"		// squareShape class
#include "d_draw.h"		// drawing functions

int main()
{
	// begin with the large square at (2.5, 1.5), sides = 5,
	// and color lightblue
	squareShape sq(2.5,1.5,5,lightblue);
	// use c to cycle through the colors
	shapeColor c = lightblue;
	// location and side of a square. set to the values
	// of the large square
	double x = 2.5, y = 1.5, side = 5.0;
	int i;

	// create the drawing window
	openWindow();

	for (i=0;i < 5;i++)
	{
		// draw the current square shape
		sq.draw();

		// move to the next color in the palette
		c++;
		// decrease the side by 1.0
		side -= 1.0;
		// increase x and y by 0.5
		x += 0.5;
		y += 0.5;

		// assign the new attributes
		sq.setColor(c);
		sq.setSide(side);
		sq.move(x,y);
	}

	// view the nested squares
	viewWindow();

	// close the window
	closeWindow();

	return 0;
}
