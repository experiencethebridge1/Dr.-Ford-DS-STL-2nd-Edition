#include <iostream>

#include "d_comm.h"

using namespace std;

int main()
{
	int n,i;
	
	// input the degree of the polynomial
	cout << "Enter n: ";
	cin >> n;
	
	// output the polymomial from highest to lowest
	// powers of x
	cout << "(1+x)^" << n << " = ";
	for(i=n;i >= 0;i--)
	{
		// omit the leading coefficient C(n,n) = 1
		if (i != n)
			cout << commDynB(n,i);

		// do not output x^0
		if (i != 0)
		{
			// output x^1 as x
			if (i == 1)
				cout << 'x';
			else
			{
				cout << "x^" << i;
			}
			// follow all but the last term by +
			cout << " + ";
		}
	}
	cout << endl;

	return 0;
}

/*
Run:

Enter n: 8
(1+x)^8 = x^8 + 8x^7 + 28x^6 + 56x^5 + 70x^4 + 56x^3 + 28x^2 + 8x + 1
*/
