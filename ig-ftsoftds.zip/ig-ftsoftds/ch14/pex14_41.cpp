#include <iostream>

#include "d_bitvec.h"

using namespace std;

int main()
{
	int intSize = 8*sizeof(int);
	bitVector b, lastTwoBits(intSize), mask(intSize);
	int n, i, ternaryDigit;

	// make mask = 11000...000
	mask.set(0);
	mask.set(1);

	cout << "Enter an integer value: ";
	cin >> n;

	// assign the bits in n to b
	b = n;

	// look at each pair of bits in b left to right
	for (i=0;i < intSize/2;i++)
	{
		// isolate the two most significant bits of b in bits
		// 0 and 1 of lastTwoBits
		lastTwoBits = b & mask;
		// form the ternary digit and output it
		ternaryDigit = lastTwoBits.bit(0) * 2 + lastTwoBits.bit(1);
		cout << ternaryDigit;

		// shift out the 2 most significant bits of b
		b = b << 2;
	}
	cout << endl;

	return 0;
}

/*
Run:

Enter an integer value: 16542345
0000333012222021
*/
