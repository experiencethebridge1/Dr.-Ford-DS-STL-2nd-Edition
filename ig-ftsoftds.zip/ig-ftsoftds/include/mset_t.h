#ifndef MINIMULTISET_CLASS_TREE_BASED
#define MINIMULTISET_CLASS_TREE_BASED

#include "mstree.h"		// for mstree class
#include "d_except.h"

using namespace std;

template <typename T>
class miniMultiSet
{
	public:

		typedef typename mstree<T>::iterator iterator;
		typedef typename mstree<T>::const_iterator const_iterator;
			// miniMultiSet iterators are simply mstree iterators

		miniMultiSet();
			// default constructor

		miniMultiSet(T *first, T *last);
			// build a multiset whose data are determined by
			// the pointer range [first, last)

		bool empty() const;
			// is the multiset empty?

		int size() const;
			// return the number of elements in the multiset

		int count (const T& item) const;
			// return the number of duplicate occurrences of item
			// in the multiset

		iterator find(const T& item);
			// search for item in the multiset and return an iterator
			// pointing at the first occurrence matching item or end()
			// if it is not found
		const_iterator find(const T& item) const;
			// constant version

		pair<iterator, iterator> equal_range(const T& item);
			// return a pair of iterators such that all occurrences
			// of item are in the iterator range
			// [first member of pair, second member of pair)
		pair<const_iterator, const_iterator>
		  equal_range(const T& item) const;
			// constant version
			
		iterator insert(const T& item);
			// insert item into the multiset and return an
			// iterator pointing at the new element.
			// Postcondition: the element item is added to the multiset

		int erase(const T& item);
			// erase all occurrences of item from the multiset
			// and return the number of items erased.
			// Postcondition: the size of the multiset is reduced
			// by the number of occurrences of item in the multiset

		void erase(iterator pos);
			// erase the item pointed to by pos.
			// Preconditions: the multiset is not empty and pos points
			// to an item in the multiset. if the multiset is empty,
			// the function throws the underflowError exception. if the
			// iterator is invalid, the function throws the
			// referenceError exception.
			// Postcondition: the multiset size decreases by 1

		void erase(iterator first, iterator last);
			// erase the elements in the range [first, last)
			// Precondition: the multiset is not empty. if the
			// multiset is empty, the function throws the
			// underflowError exception.
			// Postcondition: the multiset size decreases by the number
			// elements in the range

		iterator begin();
			// return an iterator pointing at the first member
			// in the multiset
		const_iterator begin() const;
			// constant version of begin()

		iterator end();
			// return an iterator pointing just past the last
			// member in the multiset
		const_iterator end() const;
			// constant version of end()

	private:
		mstree<T> t;
			// multiset implemented using a binary search tree that
			// allows duplicates

		int distance(iterator first, iterator last);
			// return the number of items in the range [first, last)
		int distance(const_iterator first, const_iterator last) const;
			// constant version
};

// IMPLEMENT THE miniMultiSet MEMBER FUNCTIONS BY CALLING THE
// CORRESPONDING MEMBER FUNCTIONS FROM THE MSTREE CLASS

template <typename T>
int miniMultiSet<T>::distance(iterator first, iterator last)
{
	return t.distance(first,last);
}

template <typename T>
int miniMultiSet<T>::distance(const_iterator first, const_iterator last) const
{
	return t.distance(first,last);
}

template <typename T>
miniMultiSet<T>::miniMultiSet()
{}

// insert the items into the underlying tree
template <typename T>
miniMultiSet<T>::miniMultiSet(T *first, T *last):
	t(first,last)
{}

template <typename T>
bool miniMultiSet<T>::empty() const
{
	return t.empty();
}

template <typename T>
int miniMultiSet<T>::size() const
{
	return t.size();
}

template <typename T>
int miniMultiSet<T>::count (const T& item) const
{
	return t.count(item);
}

template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::find(const T& item)
{
	return t.find(item);
}

template <typename T>
miniMultiSet<T>::const_iterator miniMultiSet<T>::find(const T& item) const
{
	return t.find(item);
}

template <typename T>
pair<miniMultiSet<T>::iterator, miniMultiSet<T>::iterator>
miniMultiSet<T>::equal_range(const T& item)
{
	return t.equal_range(item);
}

template <typename T>
pair<miniMultiSet<T>::const_iterator, miniMultiSet<T>::const_iterator>
miniMultiSet<T>::equal_range(const T& item) const
{
	return t.equal_range(item);
}
	
template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::insert(const T& item)
{
	return t.insert(item);
}

template <typename T>
int miniMultiSet<T>::erase(const T& item)
{
	return t.erase(item);
}

template <typename T>
void miniMultiSet<T>::erase(iterator pos)
{
	if (t.empty())
		throw
			underflowError("miniMultiSet erase(pos): multiset empty");
	else if (pos == t.end())
		throw
		  referenceError("miniMultiSet erase(pos): invalid iterator");

	// erase element at location pos in t
	t.erase(pos);
}

template <typename T>
void miniMultiSet<T>::erase(iterator first, iterator last)
{
	if (t.empty())
		throw
			underflowError("miniMultiSet erase(pos): multiset empty");

	// erase the range [first, last) in t
	t.erase(first, last);
}

template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::begin()
{
	return t.begin();
}

template <typename T>
miniMultiSet<T>::const_iterator miniMultiSet<T>::begin() const
{
	return t.begin();
}

template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::end()
{
	return t.end();
}

template <typename T>
miniMultiSet<T>::const_iterator miniMultiSet<T>::end() const
{
	return t.end();
}

#endif	// MINIMULTISET_CLASS_TREE_BASED
