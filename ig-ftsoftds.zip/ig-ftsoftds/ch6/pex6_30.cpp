#include <iostream>
#include <list>

#include "d_random.h"
#include "d_search.h"

using namespace std;

// return the number of occurrences of item in aList
template <typename T>
int count(list<T>& aList, const T& item);

int main()
{	
	list<int> intList;
	randomNumber rnd;
	int i, rndNumber;

	cout << "Generating 20 random integers in range from 0 to 4:"
		  << endl;
	// initialize intList with 20 random integers
	// in the range from 0 to 4
	for (i=0;i < 20;i++)
	{
		rndNumber = rnd.random(5);
		intList.push_back(rndNumber);
		cout << rndNumber << " ";
	}
	cout << endl << endl;

	// output the number of 0's, 1's, and so forth,
	// using count()
	cout << "Count totals:" << endl;
	for (i=0;i < 5;i++)
		cout << i << ": " << count(intList, i)
			  << endl;

	return 0;
}

template <typename T>
int count(list<T>& aList, const T& item)
{
	int numOccurrences = 0;
	list<T>::iterator iter;

	iter = aList.begin();
	while ((iter = seqSearch<T>(iter, aList.end(), item)) !=
			  aList.end())
	{
		numOccurrences++;
		iter++;
	}

	// return the number of occurrences of item
	return numOccurrences;
}

/*
Run:

Generating 20 random integers in range from 0 to 4:
0 1 0 0 4 3 4 0 1 3 2 3 0 1 4 0 4 3 0 4

Count totals:
0: 7
1: 3
2: 1
3: 4
4: 5
*/
