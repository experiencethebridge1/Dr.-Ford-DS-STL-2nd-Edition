#ifndef MOD_CLASS
#define MOD_CLASS

#include <iostream>

#include "d_except.h"	// for the rangeError exception

using namespace std;

class modClass
{
	public:
		modClass(int v = 0);
			// throw a rangeError exception if v < 0
		friend modClass operator+ (const modClass& x,
											const modClass& y);
		friend modClass operator* (const modClass& x,
											const modClass& y);
		friend bool operator== (const modClass& x,
										const modClass& y);
		friend bool operator< (const modClass& x,
									  const modClass& y);

		friend ostream& operator<< (ostream& ostr,
											 const modClass& obj);
	private:
		int dataVal;
};

modClass::modClass(int v): dataVal(v % 7)
{
	if (v < 0)
		throw rangeError("modClass constructor: argument is negative");
}

modClass operator+ (const modClass& x, const modClass& y)
{
	return modClass(x.dataVal + y.dataVal);
}

modClass operator* (const modClass& x, const modClass& y)
{
	return modClass(x.dataVal * y.dataVal);
}

bool operator== (const modClass& x, const modClass& y)
{
	return x.dataVal == y.dataVal;
}

bool operator< (const modClass& x, const modClass& y)
{
	return x.dataVal < y.dataVal;
}

ostream& operator<< (ostream& ostr, const modClass& obj)
{
	ostr << obj.dataVal;

	return ostr;
}

#endif	// MOD_CLASS
