#include <iostream>

#include "dynint.h"

using namespace std;

dynamicInt f(dynamicInt obj);

int main()
{	
	dynamicInt a(3), b;

   b = f(a);
   cout << b << endl;

	return 0;
}

dynamicInt f(dynamicInt obj)
{
	obj = dynamicInt(7);

   return obj;
}

/*
Run:

7
*/

