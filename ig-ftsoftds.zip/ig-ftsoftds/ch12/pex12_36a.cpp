#include <iostream>
#include <fstream>
#include <cstdlib>

#include "d_rbtree.h"	// rbtree class
#include "d_timer.h"		// timer class

using namespace std;

int main()
{
	// red-black tree of string objects
	rbtree<string> rbt;
	// use to read "sdict.dat" and "udict.dat"
	ifstream sdictStream, udictStream;
	string word;
	// time the red-black tree search
	timer t;

	// open "udict.dat"
	udictStream.open("udict.dat");
	if (!udictStream)
	{
		cerr << "Cannot open 'udict.dat'" << endl;
		exit(1);
	}

	while (true)
	{
		udictStream >> word;
		if (!udictStream)
			break;

		rbt.insert(word);
	}
	udictStream.close();

	// open "sdict.dat"
	sdictStream.open("sdict.dat");
	if (!sdictStream)
	{
		cerr << "Cannot open 'sdict.dat'" << endl;
		exit(1);
	}

	// start the timer and input words from "sdict.dat".
	// look each word up in the tree
	t.start();
	while (true)
	{
		sdictStream >> word;
		if (!sdictStream)
			break;

		rbt.find(word);
	}
	// stop the timer and output the search time
	t.stop();
	cout << "Time for the search: " << t.time() << " seconds"
		  << endl;

	sdictStream.close();

   return 0;
}

/*
Run:

Time for the search: 1.623 seconds
*/
