#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>

using namespace std;

// compensate for a bug in Microsoft VC++ 6 getline()
#ifdef _MSC_VER
#include "d_util.h"
#endif	// _MSC_VER

int main()
{
	// stream that inputs the lines of the form letter
	ifstream formLetter, replacements;
	// name of the file and the replacement strings
	string poundstr, ampstring;
	// each element of line is a line of the file, whose size is
	// assumed not to exceed 50 lines. a line is initially
	// read into aLine
	string line[50], aLine;
	// n counts the number of lines in the file
	int n;
	// loop control objects
	int i,j;

	// open the form file with error checking
	formLetter.open("formlet.txt");
	if (!formLetter)
	{
		cerr << "Cannot open 'formlet.txt'" << endl;
		exit(1);
	}

	// open the file containing the substitution strings
	replacements.open("replace.txt");
	if (!replacements)
	{
		cerr << "Cannot open 'replace.txt'" << endl;
		exit(1);
	}

	// initial index is 0 and 0 lines of formLetter have been read
	n = 0;
	// input lines until end-of-file or n == 50 lines
	while(formLetter && n < 50)
	{
		// input a line of the file
		getline(formLetter, aLine, '\n');

		// break if we encounter EOF or we have already
		// read 50 lines
		if (!formLetter || n >= 50)
			break;

		// assign aLine to the array and increment n.
		// n is the number of lines read from the file
		line[n] = aLine;
		n++;
	}

	// input the replacement strings line by line
	while (true)
	{
		// get the replacement strings
		getline(replacements,poundstr,'#');
		getline(replacements,ampstring,'\n');
		if (!replacements)
			break;

		// traverse line and perform the substitutions. output each
		// line after the substutitions
		for(i=0;i < n;i++)
		{
			// capture line[i] in aLine
			aLine = line[i];

			// search for '#' and '&' in aLine. perform the substitutions
			for(j=0;j < aLine.length();j++)
				if (aLine[j] == '#')
				{
					// found '#'. remove it and substitute poundstr
					aLine.erase(j,1);
					aLine.insert(j,poundstr);
				} else if (aLine[j] == '&')
				{
					// found '&'. remove it and substitute ampstring
					aLine.erase(j,1);
					aLine.insert(j,ampstring);
				}

			// output the expanded line
			cout << aLine << endl;
		}
		// output a form feed
		cout << '\f' << endl;
	}

	// close the stream
	formLetter.close();

	return 0;
}

/*
File "formlet.txt"

Dear #:

Your lucky gift is available at &. By going to
& and identifying your name, the attendant will
give you your prize. Thank you, #, for your interest
in our contest.

Sincerely,
The string Man

File "replace.txt"

Joe Bartlett#Martha's Toys
Allison Thompson#Martha's Toys

Run:

Dear Joe Bartlett:

Your lucky gift is available at Martha's Toys. By going to
Martha's Toys and identifying your name, the attendant will
give you your prize. Thank you, Joe Bartlett, for your interest
in our contest.

Sincerely,
The string Man
<form feed>
Dear Allison Thompson:

Your lucky gift is available at Martha's Toys. By going to
Martha's Toys and identifying your name, the attendant will
give you your prize. Thank you, Allison Thompson, for your interest
in our contest.

Sincerely,
The string Man
<form feed>
*/
