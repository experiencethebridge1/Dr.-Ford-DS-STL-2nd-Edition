#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <string>

// compensate for a bug in Microsoft VC++ 6 getline()
#ifdef _MSC_VER
#include "d_util.h"
#endif	// _MSC_VER

using namespace std;

// insert strB into strA at location pos
void strInsert(string& strA, const string& strB, int pos);

// find all occurrences of strB in strA and replace each one by strC
void strReplace (string& strA, const string& strB, const string& strC);

int main()
{
	string line, rep;

	cout << "Enter a line of text: ";
	getline(cin, line);
	cout << "Enter a replacement pattern: ";
	cin >> rep;

	// replace all occurrences of "<pat>" in line by rep
	strReplace(line, "<pat>", rep);
	strInsert(line, "+++", line.length()/2);

	cout << "Modified string:" << endl << line << endl;

	return 0;
}

void strInsert(string& strA, const string& strB, int pos)
{
	if (pos < strA.length())
		// chars at indices 0 .. pos-1 + strB + remainder of strA
		strA = strA.substr(0,pos) + strB + strA.substr(pos);
	else
		// concatenate strB onto strA
		strA = strA + strB;
}

void strReplace (string& strA, const string& strB, const string& strC)
{
	int pos = 0;

	// look for occurrences of strB in strA
	while ((pos = strA.find(strB,pos)) != -1)
	{
		// erase strB from strA at pos
		strA.erase(pos,strB.length());
		// insert strC in strA at pos
		strA.insert(pos,strC);
		// skip over the strC.length() characters just added
		// to strA
		pos += strC.length();
	}
}

/*
Run:

Enter a line of text: Alfred the snake h<pat>ed because he m<pat>ed his M<pat>y.

Enter a replacement pattern: iss
Modified string:
Alfred the snake hissed be+++cause he missed his Missy.
*/