#include <iostream>
#include <string>

#include "mstree.h"

using namespace std;

main()
{
	int arr[] = {5, 3, 4, 1, 5, 2, 3, 7, 2, 6, 2, 3, 10, 8, 12, 15,
					 9, 8, 2, 5, 3, 8, 1, 7, 0, 4, 9, 5};
	int arrSize = sizeof(arr)/sizeof(int);
	mstree<int> t(arr, arr+arrSize);
	// tree iterator we will use
	mstree<int>::iterator iter;
	// used as a return value for mstree function equal_range()
	pair<mstree<int>::iterator, mstree<int>::iterator> p;
	int n;

	cout << "Number of entries in the tree = " << t.size() << endl;

	// insert the value 8 into the tree
	t.insert(8);

	cout << "Enter an integer value: ";
	cin >> n;
	// use find() to see if n is in the tree
	if (t.find(n) != t.end())
		cout << n << " is in the tree" << endl;
	else
		cout << n << " is not in the tree" << endl;

	cout << "Enter an integer value: ";
	cin >> n;
	// use count() to output the number of times n occurs in the tree
	cout << n << " occurs " << t.count(n)
		  << " times in the tree" << endl;
	// output all occurrences of n in the tree
	cout << "All values of " << n << " in the tree: ";
	p = t.equal_range(n);
	for (iter = p.first; iter != p.second;iter++)
	  cout << (*iter)	<< "  ";
	cout << endl;

	// remove values of 2 from the tree
	t.erase(2);

	// output the final tree
	t.displayTree(2);

	return 0;
}

/*
Run:

Number of entries in the tree = 28
Enter an integer value: 3
3 is in the tree
Enter an integer value: 5
5 occurs 4 times in the tree
All values of 5 in the tree: 5  5  5  5
                             5
           3                    5
     1                 4                    7
  0     1     3           4              6                         10
                 3                 5              8                   12
                    3                 5        7              9          15
                                                     8           9
                                                        8
                                                           8
*/
