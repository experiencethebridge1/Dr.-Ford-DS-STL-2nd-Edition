#ifndef SQUARE_CLASS
#define SQUARE_CLASS

#include <cmath>

#include "d_rect.h"

class square
{
	public:
		square(double len);
			// constructor. sides of square have length len
        
		double getSide() const;
		void setSide(double len);
			// functions to retrieve and modify private data

		double perimeter() const;
		double area() const;
		double diagonal() const;
			// compute and return square measurements

	private: 
		rectangle sq;
			// rectangle object represents a square
};

square::square(double len): sq(len, len)
{}
 
double square::getSide() const
{
	return sq.getLength();
}

void square::setSide(double len)
{
	sq.setSides(len, len);
}

double square::perimeter() const
{ 
	return  sq.perimeter();
}

double square::area() const
{ 
	return  sq.area();
}

double square:: diagonal() const
{ 
	return  sqrt(2) * getSide();
}

#endif	// SQUARE_CLASS
