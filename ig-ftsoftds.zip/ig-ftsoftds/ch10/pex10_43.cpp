#include <iostream>
#include <cstdlib>	// for exit()
#include <stack>
#include <string>

#include "d_tnodel.h"
// infix2Postfix class for which operands are
// single letter identifiers in the range 'a' .. 'z'
#include "inf2pstf.h"

// compensates for a bug in VC++ 6.0 function getline() from <string>
#ifdef _MSC_VER
istream& getline(istream& is,string& sbuff, char term_char = '\n')
{
	char tc, eof = char_traits<char>::eof();
	string::size_type numchars = 0;
	sbuff.erase();


	while(true)
	{
		tc = is.get();
		if(tc == eof) // eof - set failbit and quit
		{
			is.setstate(ios::failbit);
			break;
		}
		else if(tc == term_char) // termination char extracted
			break;

		sbuff.append(1,tc);
		numchars++;

		if(numchars == sbuff.max_size()) // max chars extracted
				break;
	}

	return is;
}
#endif // _MSC_VER


// build an expression tree from a postfix expression.
// the operands are single letter identifiers in the range from
// 'a' .. 'z' and the operands are selected from the characters
// '+', '-', '*' and '/'
tnode<char> *buildExpTree (const string& pexp);

// output the prefix form of the expression represented
// by the tree
void prefixOutput(tnode<char> *exp);

int main()
{
	// root of the expression tree
	tnode<char> *exproot;
	// infix expression read into string
	string infixExp;
	
	// input the infix expression
	cout << "Enter the expression: ";
	getline(cin, infixExp);
	cout << endl;

	// prepare to convert infixExp to postfix
	infix2Postfix convert(infixExp);
	
	try
	{
		// build the postfix equivalent and pass it to
		// buildExpTree
		exproot = buildExpTree(convert.postfix());
	}
	
	// handle an error in the conversion from infix
	// to postfix
	catch(const expressionError& ee)
	{
		// output the error string and terminate the program
		cerr << ee.what() << endl;
		exit(1);
	}

	// output the prefix form of the expression
	cout << "Prefix form: ";
	prefixOutput(exproot);
	cout << endl;

	// output the postfix form of the expression
	cout << "Postfix form: ";
	postorderOutput(exproot);
	cout << endl;

	// output the expression tree
	cout << endl << "Expression tree:" << endl << endl;
	displayTree(exproot, 1);

	return 0;
	
}

tnode<char> *buildExpTree(const string& exp)
{
	// newnode is the address of the root of subtrees we build
	tnode<char> *newnode, *lptr, *rptr;
	char token;
	// subtrees go into and off the stack
	stack<tnode<char> *> s;
	int i = 0;

	// loop until i reaches the end of the string
	while(i != exp.length())
	{
		// skip blanks and tabs in the expression
		while (exp[i] == ' ' || exp[i] == '\t')
			i++;

		// if the expression has trailing whitespace, we could
		// be at the end of the string
		if (i == exp.length())
			break;

		// extract the current token and increment i
		token = exp[i];
		i++;

		// see if the token is an operator or an operand
		if (token == '+' || token == '-' || token == '*' || token == '/')
		{
			// current token is an operator. pop two subtrees off
			// the stack.
			rptr = s.top();
			s.pop();
			lptr = s.top();
			s.pop();
		
			// create a new subtree with token as root and subtees
			// lptr and rptr and push it onto the stack
			newnode = new tnode<char>(token,lptr,rptr);
			s.push(newnode);
		}
		else // must be an operand
		{
			// create a leaf node and push it onto the stack
			newnode = new tnode<char>(token);
			s.push(newnode);
		}
	}

	// if the expression was not empty, the root of the expression
	// tree is on the top of the stack
	if (!s.empty())
		return s.top();
	else
		return NULL;
}

void prefixOutput(tnode<char> *exp)
{
   // the recursive scan terminates on a empty subtree
   if (exp != NULL)
   {
      cout << exp->nodeValue << "  ";	// output the node
      prefixOutput(exp->left);			// descend left
      prefixOutput(exp->right);			// descend right
   }
}

/*
Run 1:

Enter the expression: (a+b)/c

Prefix form: /  +  a  b  c
Postfix form: a  b  +  c  /

Expression tree:

       /
   +     c
 a   b

Run 2:

Enter the expression: a + b*c/d + e/f*g

Prefix form: +  +  a  /  *  b  c  d  *  /  e  f  g
Postfix form: a  b  c  *  d  /  +  e  f  /  g  *  +

Expression tree:

               +
   +                   *
 a         /       /     g
       *     d   e   f
     b   c
*/
