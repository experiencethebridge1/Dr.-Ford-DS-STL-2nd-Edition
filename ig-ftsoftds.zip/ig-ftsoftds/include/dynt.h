#ifndef DYNAMICTYPE_CLASS
#define DYNAMICTYPE_CLASS

#include <iostream>

#include "d_except.h"

using namespace std;

template <typename T>
class dynamicType
{
	public:
		dynamicType(const T& value);
		dynamicType(const dynamicType<T>& obj);
			// constructor and copy constructor

		~dynamicType();
			// destructor

		dynamicType<T>& operator= (const dynamicType<T>& rhs);
			// assignment operator

		T getData() const;
			// data access

// GNU g++ requires a special syntax for the friend template
// operator
#ifdef __GNUC__
		friend ostream& operator<< <> (ostream& ostr,
											 const dynamicType<T>& obj);
#else
		friend ostream& operator<< (ostream& ostr,
											 const dynamicType<T>& obj);
#endif	// __GNUC__

			// stream output
	private:
		T *ptr;
};

template <typename T>
dynamicType<T>::dynamicType(const T& value)
{
	ptr = new T (value);

	if (ptr == NULL)
		throw memoryAllocationError(
					"dynamicType: memory allocation failure");
}

template <typename T>
dynamicType<T>::dynamicType(const dynamicType<T>& obj)
{
	ptr = new T (*obj.ptr);

	if (ptr == NULL)
		throw memoryAllocationError(
					"dynamicType: memory allocation failure");
}

template <typename T>
dynamicType<T>::~dynamicType()
{
	delete ptr;
}

template <typename T>
dynamicType<T>& dynamicType<T>::operator=
					(const dynamicType<T>& rhs)
{
	*ptr = *rhs.ptr;

	return *this;
}

template <typename T>
T dynamicType<T>::getData() const
{
	return *ptr;
}

template <typename T>
ostream& operator<< (ostream& ostr,
							const dynamicType<T>& obj)
{
	ostr << *obj.ptr;
	return ostr;
}

#endif	// DYNAMICTYPE_CLASS
