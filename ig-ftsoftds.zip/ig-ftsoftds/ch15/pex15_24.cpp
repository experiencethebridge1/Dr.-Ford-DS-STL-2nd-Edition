#ifdef __BORLANDC__
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#include <iostream>
#include <vector>

using namespace std;

// recursive version of the binary search
template <typename T>
int binSearch(const vector<T> v, int first, int last, T target);

int main()
{
	int arr[] = {13, 18, 22, 30, 37, 42, 50, 57, 68, 81, 88};
	int arrSize = sizeof(arr)/sizeof(int);
	vector<int> v(arr, arr+arrSize);
	int target;

	cout << "Enter a target value: ";
	cin >> target;

	if (binSearch(v, 0, arrSize, target) != -1)
		cout << target << " is in the vector" << endl;
	else
		cout << target << " is not in the vector" << endl;

	return 0;
}

template <typename T>
int binSearch(const vector<T> v, int first, int last, T target)
{
	// index of midpoint
	int mid;
	// vector value at the midpoint
	T midValue;

	// if the range [first,last) is empty, return -1
	if (first == last)
		return -1;

	mid = (first + last)/2;
	midValue = v[mid];

	// if tartet equals midValue, return index mid
	if (midValue == target)
		return mid;
	// if target less than midValue, call the binary search
	// for the range [first, mid)
	else if (target < midValue)
		return binSearch(v, first, mid, target);
	else
		// target greater than midValue. call the binary search
		// for the range [mid+1, last)
		return binSearch(v, mid+1, last, target);
}

/*
Run 1:

Enter a target value: 22
22 is in the vector

Run 2:

Enter a target value: 89
89 is not in the vector

Run 3:

Enter a target value: 13
13 is in the vector
*/
