#include <iostream>
#include <cstdlib>		// for exit()
#include <stack>
#include <string>

#include "d_rpn.h"		// postfixEval class
#include "d_inftop.h"	// infix2Postfix class
#include "d_except.h"	// for exception expressionError

#ifdef _MSC_VER
// compensates for VC++ 6.0 bug in getline() from <string>
#include "d_util.h"
#endif	// _MSC_VER

using namespace std;

int main()
{
	string infixExp, rpnExp;
	// declare an infix2Postfix object and a postfixEval object
	infix2Postfix infix;
	postfixEval postfix;

	cout << "Enter an infix expression: ";
	getline(cin, infixExp);
	cout << "Enter an equivalent postfix expression: ";
	getline(cin, rpnExp);

	// infix evaluates infixExp and postfix evaluates rpnExp
	infix.setInfixExp(infixExp);
	postfix.setPostfixExp(rpnExp);

	try
	{
		// evaluate the postifix expression
		cout << endl << "The postfix expression evaluates to "
			  << postfix.evaluate() << endl;
	}

	catch (const expressionError& ee)
	{
		// output the error string and terminate the program
		cerr << ee.what() << endl;
		exit(1);
	}

	try
	{
		// convert the infix expression to postfix and arrange
		// for object postfix to evaluate the result
		postfix.setPostfixExp(infix.postfix());
	}

	catch (const expressionError& ee)
	{
		// output the error string and terminate the program
		cerr << ee.what() << endl;
		exit(1);
	}

	// no need for a try block, since infix.postfix() is a
	// correct postfix expression
	cout << "After converting the infix expression to postfix,"
		  << endl << "the postix expression evaluates to "
		  << postfix.evaluate() << endl;

	return 0;
}

/*
Run 1:

Enter an infix expression: 2 + (3*5 + 7)/8
Enter an equivalent postfix expression: 2 3 5 * 7 + 8 / +

The postfix expression evaluates to 4
After converting the infix expression to postfix,
the postix expression evaluates to 4

Run 2:

Enter an infix expression: 6 + (3*8 - 9
Enter an equivalent postfix expression: 6 3 8 * 9 - +

The postfix expression evaluates to 21
infix2Postfix: Missing ')'

Run 3:

Enter an infix expression: 8 + 2 ^ 3 ^ 2
Enter an equivalent postfix expression: 8  2  3  2  ^  ^  +

The postfix expression evaluates to 520
After converting the infix expression to postfix,
the postix expression evaluates to 520
*/
