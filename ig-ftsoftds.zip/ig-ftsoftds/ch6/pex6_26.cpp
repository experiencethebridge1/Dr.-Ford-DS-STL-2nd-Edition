#include <iostream>
#include <list>

#include "d_util.h"		// for writeList()
#include "d_listl.h"		// for splice()

using namespace std;

int main()
{	
	int a[5] = {5, 8, 4, 1, 7}, b[7] = {12, 3, 15, 6, 23, 1, 2};
	int sizeA = sizeof(a)/sizeof(int), sizeB = sizeof(b)/sizeof(int);
	list<int> list1(a ,a+ sizeA), list2(b ,b+ sizeB);

	// splice list2 at the end of list1
	splice<int> (list1, list1.end(), list2);
	// output the modified list
	cout << "list1 = ";
	writeList(list1);

	return 0;
}

/*
Run:

list1 = 5  8  4  1  7  12  3  15  6  23  1  2
*/
