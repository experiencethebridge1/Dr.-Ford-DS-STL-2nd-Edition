#include <iostream>

#include "genvec.h"		// genVector class
#include "d_util.h"		// for manipulator setreal()

using namespace std;

int main()
{
	// declare two types of genVector objects
	genVector<char> ucLetter(65,90);
	genVector<double> tempVector(-10,25);
	int i, count;

	// ucLetter[65]='A', ..., ucLetter[90] = 'Z'
	for (i=65;i <= 90;i++)
		ucLetter[i] = char(i);

	// tempVector [i] is Fahrenheit equivalent of Celsius
	// temperature i. conversion is F = 9/5 C + 32
	for(i=-10;i <= 25;i++)
		tempVector[i] = 9.0/5.0*i + 32.0;

	// output all characters of ucLetter on one line
	cout << "Contents of ucLetter:" << endl << endl;
	for(i=65;i <= 90;i++)
		cout << ucLetter[i];
	cout << endl << endl;

	// output the temperature conversions, 8
	// values per line
	cout << "Contents of tempVector:" << endl << endl;
	count = 1;
	for(i=-10;i <= 25;i++)
	{	cout << setreal(7,2) << tempVector[i];
		if (count % 8 == 0)
			cout << endl;
		count++;
	}
	// make sure there is a newline after last line
	if (count % 8 != 0)
		cout << endl;

	return 0;
}

/*
Run:

Contents of ucLetter:

ABCDEFGHIJKLMNOPQRSTUVWXYZ

Contents of tempVector:

  14.00  15.80  17.60  19.40  21.20  23.00  24.80  26.60
  28.40  30.20  32.00  33.80  35.60  37.40  39.20  41.00
  42.80  44.60  46.40  48.20  50.00  51.80  53.60  55.40
  57.20  59.00  60.80  62.60  64.40  66.20  68.00  69.80
  71.60  73.40  75.20  77.00
*/
