#include <iostream>

#include "d_rbtree.h"		// rbtree class

using namespace std;

int main()
{
	int arr[] = {20, 35, 5, 18, 7, 15, 22, 6, 37, 3, 19,
					 55, 38, 8, 2, 16, 12, 17, 13};
	int arrSize = sizeof(arr)/sizeof(int);
	// binary search tree containing data from arr
	rbtree<int> t(arr, arr+arrSize);

	// output the tree
	t.displayTree(3);
	cout << endl;

   return 0;
}

/*
Run:
                                                      20
                  7*                                          35
           5                                  18          22          38
       3       6                 15*              19             37*     55*
  2*                      12          16
                      8*     13*         17*
*/
