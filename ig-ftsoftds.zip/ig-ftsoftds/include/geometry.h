#ifndef GEOMETRY_CLASS
#define GEOMETRY_CLASS

#include <cmath>		// for sqrt()

const double PI = 3.141592653589793;

class geometry
{
	public:
		// constructor. build a circle or rectangle
		geometry(double m1, double m2 = 0.0);

		double border();		// circumference (perimeter) of object
		double area();			// area of object
		double diagonal();	// diameter (diagonal) of object

	private:
		double measurement1;
		double measurement2;
};

// if m2 == 0.0, object is a circle; otherwise, it is a rectangle
geometry::geometry(double m1, double m2):measurement1(m1), measurement2(m2)
{}

// return the perimeter of the object
double geometry::border()
{
	if (measurement2 == 0.0)
		// object is a circle. return circumference
		return 2 * PI * measurement1;
	else
		// object is a rectangle
		return 2 * (measurement1 + measurement2);
}

// return the area of the object
double geometry::area()
{
	if (measurement2 == 0.0)
		// object is a circle
		return PI * measurement1 * measurement1;
	else
		// object is a rectangle
		return measurement1 * measurement2;
}

// return the diameter of a circle or diagonal of a rectangle
double geometry::diagonal()
{
	if (measurement2 == 0.0)
		// object is a circle. return diameter
		return 2 * measurement1;
	else
		// object is a rectangle
		return sqrt(measurement1*measurement1 + measurement2*measurement2);
}

#endif	// GEOMETRY_CLASS
