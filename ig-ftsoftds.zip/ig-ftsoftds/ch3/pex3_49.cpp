#include <iostream>

using namespace std;

// recursive fuction that sums the digits of the nonnegative
// integer n
int sumDigits(int n);

int main()
{
	int n;

	cout << "Enter a nonnegative integer: ";
	cin >> n;

	cout << "The sum of the digits of " << n
		  << " is " << sumDigits(n) << endl;

   return 0;
}

int sumDigits(int n)
{
	// if n/10 is 0, n has 1 digit. return it
	if (n/10 == 0)
		return n;
	else
		// return the sum of the 1's digit and the other
		// digits
		return sumDigits(n/10) + n%10;
}

/*
Run 1:

Enter a nonnegative integer: 23
The sum of the digits of 23 is 5

Run 2:

Enter a nonnegative integer: 1234
The sum of the digits of 1234 is 10

Run 3:

Enter a nonnegative integer: 90513
The sum of the digits of 90513 is 18

Run 4:

Enter a nonnegative integer: 2147483647
The sum of the digits of 2147483647 is 46
*/
