#ifndef GRADERECORD_CLASS
#define GRADERECORD_CLASS

#include <string>

using namespace std;

class gradeRecord
{
   public:
      // constructor initializes the attributes
      gradeRecord(string id = "", int gunits = 0, int gpts = 0);

      // compute and return the student gpa
      double gpa();

      // output student id and grade information
      void writeGradeInfo();

      // update record to account for new course work
      void updateGradeInfo(int newunits, int newgpts);

   private:
      string studentID;    // student identification number
		int units;           // total units earned
		int gradepts;        // total grade points accumulated
};

// constructor. initialize studentID, units, gradepts.
// compute initial gpa
gradeRecord::gradeRecord(string ID, int gunits, int gpts):
   studentID(ID), units(gunits), gradepts(gpts)
{}

double gradeRecord::gpa()
{
   if (units == 0)
      return 0.0;
   else
      return float(gradepts)/float(units);
}

void gradeRecord::writeGradeInfo()
{
   cout << "Student:  " << studentID << "  Units:  "
        << units << "  GradePts:  " << gradepts << "  GPA:  "
        << gpa() << endl;
}

// update record to account for new course work
void gradeRecord::updateGradeInfo(int newunits, int newgpts)
{
   // add in the new grade points and units
   units += newunits;
   gradepts += newgpts;
}

#endif	// GRADERECORD_CLASS
