#ifndef N_QUEENS_PROBLEM
#define N_QUEENS_PROBLEM

#include <iostream>
#include <iomanip>
#include <vector>

#include "d_matrix.h"

using namespace std;

// can a queen at (row,col) be attacked by any of the
// non-attacking queens in columns 0 to col-1 ?
bool safeLocation(int row, int col, const vector<int>& queenList);

// place a queen in columns col through n-1
bool placeQueens(vector<int>& queenList, int col, int n);

// try to find a solution to the n-Queens problem starting
// with a queen at (row,0)
bool queens(vector<int>& queenList, int row, int n);

bool safeLocation(int row, int col, const vector<int>& queenList)
{
	int qRow, qCol;
	
	for (qCol = 0; qCol < col; qCol++)	// check previous columns only
	{
		qRow = queenList[qCol];
		if (qRow == row)				// same row
			return false;
		else if (qCol == col)		// same col
			return false;
		// can they attack on a diagonal?
		else if(qCol-qRow == col-row || qCol+qRow == col+row)
			return false;
	}
	return true;
}

bool placeQueens(vector<int>& queenList, int col, int n)
{
	int row;
	bool foundLocation;

	if (col == n)	// stopping condition
		foundLocation = true;
	else
	{
		foundLocation = false; // start with row 0
		row = 0;
		while (row < n && !foundLocation)
		{
			// check whether cell (row, col) is safe; if so,
			// assign row to queenList and call placeQueens()
			// for next column; otherwise, go to the next row
			if (safeLocation(row,col,queenList) == true)
			{
				// found good location
				queenList[col] = row;

				// recursive step. try to place queens in columns col+1
				// through n-1
				foundLocation = placeQueens(queenList,col+1, n);
				if (!foundLocation)
					// use next row since current one does not lead
					// to a solution
					row++;
			}
			else
				// current row fails. go to the next row
				row++;

		}	// end while
	}

	// pass success or failure back to previous col
	return foundLocation;
}

bool queens(vector<int>& queenList, int row, int n)
{
	// place first queen at (row,0)
	queenList[0] = row;

	// locate remaining queens in columns 1 through n-1
	if (placeQueens(queenList, 1, n))
		return true;
	else
		return false;
}

class chessBoard
{
	public:
		chessBoard(int numQueens);
			// constructor. board is size numQueens x numQueens

		void setQueens(const vector<int>& queenList);
			// set queens on board at cells (queenList[col], col)
			// 0 <= col < n

		void clearBoard();
			// clear the board

		void drawBoard() const;	
			// draw the board using symbols 'Q' or '-'
	private:
		// number of queens
		int n;
		// simulates chess board
		matrix<bool> board;
};

// constructor. initialize board to blanks
chessBoard::chessBoard(int numQueens):
		n(numQueens), board(numQueens,numQueens)
{
	clearBoard();
}

// assign queens at locations (queenList[col],col),
// 0 <= col < n
void chessBoard::setQueens(const vector<int>& queenList)
{
	int col;

	clearBoard();

	for (col = 0; col < n; col++)
			board[queenList[col]][col] = true;
}

void chessBoard::clearBoard()
{
	int i,j;		

	for(i=0;i < n;i++)
		for(j=0;j < n;j++)
			board[i][j] = false;
}

void chessBoard::drawBoard() const
{
	int i,j;

	cout <<"   ";
	for (i=0;i < n;i++)
		cout << setw(3) << i;
	cout << endl;

	for (i = 0; i < n; i++)
	{
		cout << setw(2) << i << " ";
		// draw the squares in current row
		for (j = 0; j < n; j++)
		{
			if (board[i][j] == true)
				cout << "  Q";
			else
				cout << "  -";
		}
		cout << endl;
	}
}

#endif	// N_QUEENS_PROBLEM
