#include <iostream>

#include "grade.h"

using namespace std;

int main()
{	
	// current records for aDunn and bLange
	gradeRecord aDunn("455-27-9138", 14, 49),
					bLange("657-58-0331", 25, 50),
					saveRecord;
	int gradeptsPerUnit, i;


	// output GPA for both students
	cout << "aDunn GPA = " << aDunn.gpa() << endl;
	cout << "bLange GPA = " << bLange.gpa() << endl << endl;

	// add 15 units and 40 grade points
	aDunn.updateGradeInfo(4, 16);
	// output the new record for aDunn
	cout << "Update grade information for aDunn:" << endl;
	aDunn.writeGradeInfo();
	cout << endl;

	// initially, assume bLange averages C
	gradeptsPerUnit = 2;
	// loop 3 times
	for (i = 2; i >= 0;i--)
	{
		// save the record for bLange
		saveRecord = bLange;
		// update record assuming 15 units with 15*gradeptsPerUnit
		// grade points
		bLange.updateGradeInfo(15, 15*gradeptsPerUnit);
		// the average grade is char('A' + i), since
		//    'A'+2 = 'C', 'A'+1='B', and 'A'+0='A'
		cout << "bLang's GPA if average grade is " << char('A'+i)
			  << ": " << bLange.gpa() << endl;
		// restore the original record
		bLange = saveRecord;
		// move to next higher grade
		gradeptsPerUnit++;
	}

	return 0;
}

/*
Run:

aDunn GPA = 3.5
bLange GPA = 2

Update grade information for aDunn:
Student:  455-27-9138  Units:  18  GradePts:  65  GPA:  3.61111

bLang's GPA if average grade is C: 2
bLang's GPA if average grade is B: 2.375
bLang's GPA if average grade is A: 2.75
*/