#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstdlib>
#include <string>

#include "d_search.h"	// for binSearch()

using namespace std;

int main()
{
	// specify the number of reserved words as a constant
	const int NUM_RESERVED_WORDS = 5;
	// the reserved words in alphabetical order
	string reservedWords[NUM_RESERVED_WORDS] =
		{"bool", "break", "class", "if", "template"};	
	// reservedCount[i] is number of times reservedWords[i] occurs. 
	// initialize each array element to 0
	int reservedCount[NUM_RESERVED_WORDS] = {0};
	string word;
	int i;
	ifstream fin;

	fin.open("reswds.dat");
	if (!fin)
	{
		cerr << "Cannot open 'reswds.dat'" << endl;
		exit(1);
	}

	// input all the words in the file
	while (true)
	{
		fin >> word;
		if (!fin)
			break;

		// search for word in reservedWords
		i = binSearch(reservedWords, 0, NUM_RESERVED_WORDS, word);
		// if search successful, increment count for the word
		if (i != NUM_RESERVED_WORDS)
			reservedCount[i]++;
	}

	// turn on left justification
	cout.setf(ios::left, ios::adjustfield);

	// output results
	for (i=0;i < NUM_RESERVED_WORDS;i++)
		cout << setw(9) << reservedWords[i];
	cout << endl;

	for (i=0;i < NUM_RESERVED_WORDS;i++)
		cout << setw(9) << reservedCount[i];
	cout << endl;

   return 0;
}

/*
File "reswds.dat"

C++ has 74 reserved words including bool break class and if
The C++ class is a basis for object-oriented-programming
The reserved word bool is named in honor of the logician George
Bool template implements generic programming and break is used
in switch statements and for loop exit if is a reserved word in
many programming languages

Run:

bool     break    class    if       template
2        2        2        2        1
*/
