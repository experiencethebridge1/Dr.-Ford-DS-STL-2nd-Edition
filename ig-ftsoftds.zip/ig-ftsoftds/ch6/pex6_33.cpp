#include <iostream>
#include <list>

#include "d_util.h"

using namespace std;

int main()
{
	list<int> intList;
	list<int>::iterator iter;
	int i, n;

	cout << "Enter 5 integers: ";

	for (i=0;i < 5;i++)
	{
		// enter an integer and push it onto the front of intList
		cin >> n;
		intList.push_front(n);

		// position iter at the second list element
		iter = intList.begin();
		iter++;

		// erase all elements with value < n
		while (iter != intList.end())
			if (*iter < n)
				// erase iter and move forward
				intList.erase(iter++);
			else
				// move forward
				iter++;
	}

	cout << "The algorithm builds the list ";
	writeList(intList);

	return 0;
}

/*
Run 1:

Enter 5 integers: 1 2 3 4 5
The algorithm builds the list 5

Run 2:

Enter 5 integers: 5 4 3 2 1
The algorithm builds the list 1  2  3  4  5

Run 3:

Enter 5 integers: 3 5 1 2 4
The algorithm builds the list 4  5
*/
