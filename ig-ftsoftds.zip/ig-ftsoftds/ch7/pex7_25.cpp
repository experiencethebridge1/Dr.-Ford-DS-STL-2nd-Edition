#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <vector>
#include <stack>

#include "d_util.h"	// for writeVector()

using namespace std;

int main()
{
	int n, i, value;
	vector<int> v;
	stack<int> s;

	cout << "Enter an integer value n: ";
	cin >> n;

	cout << "Enter " << n << " integer values: ";
	for (i=0;i < n;i++)
	{
		cin >> value;
		v.push_back(value);
	}

	// push each element of v onto s
	for (i=0;i < v.size();i++)
		s.push(v[i]);

	cout << "Original vector: ";
	writeVector(v);

	cout << "Output of the stack: ";
	// output and pop elements until s is empty
	while (!s.empty())
	{
		cout << s.top() << "  ";
		s.pop();
	}
	cout << endl;

	return 0;
}

/*
Enter an integer value n: 8
Enter 8 integer values: 1 2 3 4 5 6 7 8
Original vector: 1  2  3  4  5  6  7  8
Output of the stack: 8  7  6  5  4  3  2  1
*/
