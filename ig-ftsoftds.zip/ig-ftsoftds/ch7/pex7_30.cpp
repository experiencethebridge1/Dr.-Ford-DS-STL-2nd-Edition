#include <iostream>
#include <stack>
#include <string>

#include "xrpn.h"

#ifdef _MSC_VER
// compensates for VC++ 6.0 bug in getline() from <string>
#include "d_util.h"
#endif	// _MSC_VER

using namespace std;

int main()
{
	// object used to evaluate postfix expressions
	postfixEval exp;
	// postfix expression input
	string rpnExp;

	cout << "Enter the postfix expression: ";
	getline(cin, rpnExp);

	// assign the expression to exp
	exp.setPostfixExp(rpnExp);

	// call evaluate() in a try block in case an error occurs
	try
	{
		cout << "The value of the expression = "
			  << exp.evaluate() << endl << endl;
	}

	// catch block outputs the error using what()
	catch (const expressionError& ee)
	{
		cout << ee.what() << endl << endl;
	}

	return 0;
}

/*
Run 1:

Enter the postfix expression: 7 @ 9 +
The value of the expression = 2

Run 2:

Enter the postfix expression: 7@ 4@ 9 + 2 * +
The value of the expression = 3

Run 3:

Enter the postfix expression: 9@@@@@@
The value of the expression = 9
*/
