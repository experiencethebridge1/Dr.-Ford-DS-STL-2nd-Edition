#ifndef QUEUE_PRIORITY_QUEUE
#define QUEUE_PRIORITY_QUEUE

#include <queue>

#include "d_except.h"

const int MAXPRIORITY = 10;

template <typename T>
class qpqueue
{
	public:
		qpqueue();

		void push(const T& item, int p);
			// insert item with priority p, 
			// 0 <= p <= MAXPRIORITY
			// Postcondition: the queue has one more element

		void pop();
			// find the non-empty queue with largest index and remove
			// its front element
			// Precondition: the queue is not empty. the function
			// throws the underflowError exception if the queue is empty

		T& top();
			// find the non-empty queue with largest index and return
			// its front element
			// Precondition: the queue is not empty. the function
			// throws the underflowError exception if the queue is empty

		const T& top() const;
			// constant version of top()

		bool empty() const;
			// is the queue empty?
		int size() const;
			// return the number of elements in the queue

	private:
		queue<T> priority[MAXPRIORITY+1];
			// priority[i] contains all elements with priority i
			// in the their order of insertion
		int pqsize;
			// number of elements in the priority queue
};


// create an empty priority queue
template <typename T>
qpqueue<T>::qpqueue(): pqsize(0)
{}

template <typename T>
void qpqueue<T>::push(const T& item, int p)
{
	// push item into queue priority[p]
	priority[p].push(item);

	// increment priority queue size
	pqsize++;
}

template <typename T>
void qpqueue<T>::pop()
{
	int i = MAXPRIORITY;

	// is the priority queue empty?
	if (pqsize == 0)
		throw underflowError("qpqueue pop(): priority queue empty");

	// find a nonempty queue in the range
	// priority[MAXPRIORITY] down to priority[0]
	while (i >= 0)
	{
		// break if priority[i] is not empty
		if (!priority[i].empty())
			break;
		i--;
	}

	// pop priority[i] and decrement priority queue size
	priority[i].pop();
	pqsize--;
}

template <typename T>
T& qpqueue<T>::top()
{
	int i = MAXPRIORITY;

	// is the priority queue empty?
	if (pqsize == 0)
		throw underflowError("qpqueue top(): priority queue empty");

	// find a nonempty queue in the range
	// priority[MAXPRIORITY] down to priority[0]
	while (i >= 0)
	{
		// break if priority[i] is not empty
		if (!priority[i].empty())
			break;
		i--;
	}

	// return the front of priority[i]
	return priority[i].front();
}

template <typename T>
const T& qpqueue<T>::top() const
{
	int i = MAXPRIORITY;

	// is the priority queue empty?
	if (pqsize == 0)
		throw underflowError("qpqueue top(): priority queue empty");

	// find a nonempty queue in the range
	// priority[MAXPRIORITY] down to priority[0]
	while (i >= 0)
	{
		// break if priority[i] is not empty
		if (!priority[i].empty())
			break;
		i--;
	}

	// return the front of priority[i]
	return priority[i].front();
}

template <typename T>
bool qpqueue<T>::empty() const
{
	return pqsize == 0;
}

template <typename T>
int qpqueue<T>::size() const
{
	return pqsize;
}

#endif	// QUEUE_PRIORITY_QUEUE
