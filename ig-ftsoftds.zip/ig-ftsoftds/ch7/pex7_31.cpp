#include <iostream>
#include <fstream>
#include <cstdlib>
#include <stack>
#include <string>

using namespace std;

int main()
{
	ifstream fin;
	// use s to check for symbol balance
	stack<char> s;
	char c;
	string fileName;
	// initially assume the file is balanced
	bool balanced = true;

	cout << "Enter the file name: ";
	cin >> fileName;

	fin.open(fileName.c_str());
	if (!fin)
	{
		cerr << "Cannot open " << fileName << endl;
		exit(1);
	}

	while (fin.get(c) && balanced)
	{
		// only consider "([{)]}"
		switch(c)
		{
			case '(':
			case '[':
			case '{':	// push the symbol on the stack
							s.push(c);
							break;

			case ')':
			case ']':
			case '}':	// change c to the matching left symbol
							if (c == ')')
								c = '(';
							else if (c == ']')
								c = '[';
							else
								c = '{';
							// verify that the stack is not empty and
							// c is on the top of the stack
							if (!s.empty())
								if (s.top() == c)
									s.pop();
								else
									balanced = false;
							else
									balanced = false;
							break;
		}
	}

	fin.close();

	// the stack should be empty
	if (!s.empty())
		balanced = false;

	// output the result
	if (balanced)
		cout << "The symbols in " << fileName
			  << " are balanced."  << endl;
	else
		cout << "The symbols in " << fileName
			  << " are not balanced."  << endl;

	return 0;
}

/*
Run 1:

File "balance1.dat"

((a+b))[{{c}}](){([])} * c[i]
(x)
{y}
[z]

Enter the file name: balance1.dat
The symbols in balance1.dat are balanced.

Run 2:

File "balance2.dat"

[a(b]c)

Enter the file name: balance2.dat
The symbols in balance2.dat are not balanced.

Run 3:

File "balance3.dat"

]

Enter the file name: balance3.dat
The symbols in balance3.dat are not balanced.
*/
