#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#include <iostream>
#include <vector>
#include <list>

#include "d_util.h"

using namespace std;

// scans the vector and loads each odd integer at the front
// of the list and each even integer element at the rear of
// the list
void loadOddEven(list<int>& aList, const vector<int>& v);

int main()
{
	// initialize the vector
	int arr[] = {6, 2, 9, 8, 3, 1};
	int arrSize = sizeof(arr)/sizeof(int);
	vector<int> v(arr, arr+arrSize);
	list<int> intList;

	loadOddEven(intList, v);

	cout << "The list is: ";
	writeList(intList);

	return 0;
}

void loadOddEven(list<int>& aList, const vector<int>& v)
{
	int i;

	// move through the vector
	for (i=0;i < v.size();i++)
		if (v[i] % 2 == 1)
			// v[i] is even. push it on the front of the list
			aList.push_front(v[i]);
		else
			// v[i] is odd. push it on the front of the list
			aList.push_back(v[i]);
}

/*
Run:

The list is: 1  3  9  6  2  8
*/
