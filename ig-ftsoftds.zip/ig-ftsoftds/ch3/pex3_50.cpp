#include <iostream>
#include <cmath>

#include "d_sort.h"
#include "d_random.h"

using namespace std;

// perform the binary search for target. for a successful search,
// return the number of comparisons required by the algorithm. for
// an unsuccessful search, return the negative of the number of
// comparisons
template <typename T>
int binSearch(const T arr[], int first, int last, const T& target);

int main()
{
	const int ARRSIZE = 50000,
				 RANDOMVALUES = 100000,
				 RANDOMLIMIT = 200000;
	int arr[ARRSIZE]; 
	int sumBinSearchSuccess = 0, sumBinSearchFail = 0;
	int success = 0;
	int i, binSearchResult;
	randomNumber rnd;

	// initialize arr with ARRSIZE random integers in the range from
	// 0 to RANDOMLIMIT-1
	for (i=0;i < ARRSIZE;i++)
		arr[i] = rnd.random(RANDOMLIMIT);

	// sort the array in preparation for the binary search
	selectionSort(arr, ARRSIZE);

	// generate RANDOMVALUES random integers in the range from
	// 0 to RANDOMLIMIT-1
	for (i=0;i < RANDOMVALUES;i++)
	{
		// search for a random integer
		binSearchResult = binSearch(arr, 0, ARRSIZE, (int)rnd.random(RANDOMLIMIT));

		// if found target, increment success and add the number of comparisons
		// required to sumBinSearchSuccess
		if (binSearchResult > 0)
		{
			success++;
			sumBinSearchSuccess += binSearchResult;
		}
		else
			// target not found. add the number of comparisons required to
			// sumBinSearchFail
			sumBinSearchFail += -binSearchResult;
	}

	// output the experimental results
	cout << "Empirical average case: "
		  << sumBinSearchSuccess/double(success) << endl;

	cout << "Empirical worst case: "
		  << sumBinSearchFail/double(RANDOMVALUES-success)
		  << "  Theoretical bound for worst case: "
		  << 2.0*(1.0 + int(log(double(ARRSIZE ))/log(2.0))) << endl;

   return 0;
}

template <typename T>
int binSearch(const T arr[], int first, int last, const T& target)
{
	int mid;
	T midvalue;					// object that is assigned arr[mid]
	int count = 0;
	
	while (first < last)		// test for nonempty sublist
	{
		mid = (first + last)/2;
		midvalue = arr[mid];
		if (target == midvalue)
		{
			count++;				// count == before return
			return count;		// have a match
		}
      // determine which sublist to search
		else if (target < midvalue)
			last = mid;		// search lower sublist. reset last
		else
			first = mid+1;	// search upper sublist. reset first
		count += 2;			// count == and <
	}

	return -count;	// target not found
}

/*
Run 1:

Empirical average case: 28.1132
Empirical worst case: 31.3809  Theoretical bound for worst case: 32

Run 2:

Empirical average case: 28.1536
Empirical worst case: 31.3721  Theoretical bound for worst case: 32

Run 3:

Empirical average case: 28.1452
Empirical worst case: 31.3739  Theoretical bound for worst case: 32
*/
