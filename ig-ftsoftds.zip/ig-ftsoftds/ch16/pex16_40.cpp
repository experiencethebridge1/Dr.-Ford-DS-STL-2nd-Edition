#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>

#include "d_graph.h"
#include "d_util.h"

using namespace std;

// return the set of leaf nodes in a directed
// graph that implements a tree
template<typename T>
set<T> leafNodes(graph<T>& gTree);

int main()
{	
	graph<char> g;
	ifstream fin;
	set<char> leaves;

	fin.open("wex16-26.dat");
	fin >> g;

	// compute the leaf set
	leaves = leafNodes(g);

	// output the leaf nodes
	cout << "Leaf nodes: ";
	writeContainer(leaves.begin(), leaves.end());
	cout << endl;

	return 0;
}

template<typename T>
set<T> leafNodes(graph<T>& gTree)
{
	// move giter through the graph vertices
	graph<T>::iterator giter;
	// construct returnSet to contain the leaf nodes
	set<T> returnSet;

	giter = gTree.begin();
	while (giter != gTree.end())
	{
		// *giter is a leaf node if it has out-degree 0
		if (gTree.outDegree(*giter) == 0)
			returnSet.insert(*giter);

		giter++;
	}

	return returnSet;
}

/*
Run:

Leaf nodes: D  G  H
*/
