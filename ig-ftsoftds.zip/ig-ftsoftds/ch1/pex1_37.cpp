#include <iostream>

#include "d_random.h"

using namespace std;

int main()
{
	// 10-integer array initialized to 0
	int count[10] = {0};
	randomNumber rnd;
	int i, value;

	// test to see if unit's digit of random numbers produced
	// by randomNumber are uniformly distributed
	for (i=0;i < 1000000;i++)
	{
		// generate a random integer in range 0 to 99,999
		value = rnd.random(100000);
		// extract unit's digit and increment corresponding
		// element of count
		count[value % 10]++;
	}

	// output the results. they should all be near 0.1
	for (i=0;i < 10;i++)
		cout << i << ": " << count[i]/1000000.0 << endl;

	return 0;
}

/*
Run 1:

0: 0.100508
1: 0.100332
2: 0.100481
3: 0.099408
4: 0.099743
5: 0.099868
6: 0.099627
7: 0.099932
8: 0.100036
9: 0.100065
*/
