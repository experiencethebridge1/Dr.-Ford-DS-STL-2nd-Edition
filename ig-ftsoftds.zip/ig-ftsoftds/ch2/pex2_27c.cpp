#include <iostream>

using namespace std;

#include "time12.h"		// tme12 class

int main()
{
	// objects specifying starting and ending time of the job
	time12 beginJob, endJob;

	// prompt for the starting time of the job
	cout << "Enter the time at which the job begins: ";
	beginJob.readTime();

	// set ending time 5 hours and 20 minutes later
	endJob = beginJob;
	endJob.addTime(5*60 + 20);

	// output the ending time of the job
	cout << "The job ends at ";
	endJob.writeTime();
	cout << endl;

   return 0;
}

/*
Run:

Enter the time at which the job begins: 7:30 AM
The job ends at 12:50 PM
*/
