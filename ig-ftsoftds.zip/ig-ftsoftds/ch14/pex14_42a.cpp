// File: hcompress.cpp
// the program demonstrates Huffman compression. the user
// enters the name of a file to compress and indicates
// whether the verbose option is desired. after compressing
// the file, the program outputs the compression ratio.
// if the Huffman tree has no more than 11 nodes, the tree
// is displayed

#include <iostream>
#include <string>

#include "d_hcomp.h"		// hCompress class
#include "d_util.h"		// for setreal()

using namespace std;

int main()
{
	string fileName;
	bool verbose;
	char response;

	// prompt for the source file name and whether
	// to use the verbose option for Huffman compression
	cout << "File name: ";
	cin >> fileName;
	cout << "Verbose (y or n): ";
	cin >> response;
	if (response == 'y')
		verbose = true;
	else
		verbose = false;

	cout << endl;

	// declare an hCompress object
	hCompress hc(fileName, verbose);

	// compress the file
	hc.compress();

	// output the compression ratio
	cout << "The compression ratio = "
		  << setreal(1,2) << hc.compressionRatio()
		  << endl << endl;

	if (hc.size() <= 11)
		// display the Huffman tree if the tree is small
		hc.displayTree();

	return 0;
}

/*
File name: huf.dat
Verbose (y or n): y

Frequency analysis ...
   File size: 103 characters
   Number of unique characters: 6

Building the Huffman tree ...
   Number of nodes in Huffman tree: 11

Generating the Huffman codes ...

Tree has 11 entries.  Root index = 10

Index  Sym      Freq    Parent  Left   Right  NBits    Bits
   0     a        17      8      -1     -1      3      110
   1     b         8      6      -1     -1      4      1010
   2     c        16      7      -1     -1      3      100
   3     d        18      8      -1     -1      3      111
   4     e        36     10      -1     -1      1      0
   5     f         8      6      -1     -1      4      1011
   6   Int        16      7       1      5
   7   Int        32      9       2      6
   8   Int        35      9       0      3
   9   Int        67     10       7      8
  10   Int       103      0       4      9

Generating the compressed file

The compression ratio = 0.99

        103

 e:36                                             67

                      32                                        35

               c:16                 16                   a:17          d:18

                             b:8           f:8
*/
