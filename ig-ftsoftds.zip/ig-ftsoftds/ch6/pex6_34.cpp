#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <string>
#include <list>

using namespace std;

int main()
{
	// initialize a list of strings
	string str[] = { "Joe", "Glenn", "Dave", "Bret",
							"Bryce", "Heather"};
	int strSize = sizeof(str)/sizeof(string);
	list<string> strList(str, str+strSize);
	// use iterator and start to move backward in strList
	list<string>::iterator iter, start;

	// position iter at the 3rd list element
	iter = strList.begin();
	iter++;
	iter++;
	// record the iterator value
	start = iter;

	// output list elements moving backward
	// until we arrive back at start
	do
	{
		cout << *iter << "  ";

		iter--;
		// if we are at strList.end(), move to the back
		// of the list
		if (iter == strList.end())
			iter--;
	} while (iter != start);
	cout << endl;

	return 0;
}

/*
Run:

Dave  Glenn  Joe  Heather  Bryce  Bret 
*/
