#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <map>

#include "d_util.h"

using namespace std;

int main()
{
	// simplify things with some typedefs
	typedef map<string,string> mapType;
	typedef map<string,string>::value_type entry;
	typedef map<string,string>::iterator iteratorType;

	// vals contains initial values for m
	entry vals[] = {entry("Arizona", "Phoenix"),
						 entry("Illinois", "Chicago"),
						 entry("California", "Sacramento") };
	mapType m(vals, vals+3);
	iteratorType iter;
	string state;

	cout << "Enter a state: ";
	getline(cin, state);

	// look for state in the set
	if ((iter = m.find(state)) != m.end())
		// iter points at a pair. output it
		cout << (*iter).second << ", " << (*iter).first << endl;
	else
		// the state is not in the map
		cout << state << " is not in the map" << endl;

	return 0;
}

/*
Run 1:

Enter a state: Arizona
Phoenix, Arizona

Run 2:

Enter a state: New York
New York is not in the map
*/
