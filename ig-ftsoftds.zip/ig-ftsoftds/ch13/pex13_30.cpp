#include <iostream>

#include "d_orderl.h"

using namespace std;

// the range [first, last) is an increasing ordered sequence.
// mode() finds the most frequently occurring element and 
// returns an iterator pointing to it. the reference argument
// numOccurrences is assigned the number of occurrences of the
// element
template <class Iterator>
Iterator mode(Iterator first, Iterator last,
				  int& numOccurrences);

// output each value in the list and its frequency of occurrence
// in the format "value(frequency)". the output order is from
// largest to smallest frequency
template <class T>
void freq(const orderedList<T>& aList);

int main()
{
	int arr[] = {4, 5, 7, 3, 7, 2, 3, 8, 7, 12, 3, 7, 4, 5, 3, 12, 7};
	int arrSize = sizeof(arr)/sizeof(int);
	// create an orderedList object from the array
	orderedList<int> aList(arr, arr+arrSize);

	// output the frequency for each element in aList which are the
	// frequencies for arr
	freq(aList);

	return 0;
}

#include "d_except.h"

template <class Iterator>
Iterator mode(Iterator first, Iterator last, int& numOccurrences)
{
	// as we traverse the ordered sequence, we must maintain iterators
	// pointing at the current value, the previous value and the value that
	// is most frequent
	Iterator currValueIter, prevValueIter, mostFrequentIter;
	// count for the current value, count for the most
	// frequently occurring element so far. start maxCount
	// with value 0 so it will be replaced at 1st comparison
	int currCount, maxCount = 0;

	// error if mode() called with an empty sequence
	if (first == last)
		throw underflowError("mode(): called with an empty sequence");

	// initially, the previous and current values
	// are the 1st element, whose frequency count
	// is 1
	prevValueIter = currValueIter = first;
	currCount = 1;
	// move to the 2nd element of the sequence
	currValueIter++;

	// traverse list and compute mode
	while (currValueIter != last)
	{	
		// are we still in a run of equal values, or
		// are we at the beginning of another?
		if (*currValueIter == *prevValueIter)
			// found 1 more occurrence of *prevValueIter
			currCount++;
		else
		{	// we have moved from one value to a new one.
			// does the count for the previous value exceed
			// the current largest frequency?
			if (currCount > maxCount)
			{	// the previous value is a new most-frequent
				// value. change maxCount and mostFrequentIter
				maxCount = currCount;
				mostFrequentIter = prevValueIter;
			}
			
			// the new value has initial frequency of 1
			currCount = 1;
			// about to get a new value. the previous value
			// becomes the current value
			prevValueIter = currValueIter;
		}

		// advance to the next element
		currValueIter++;
	}

	// just finished the last run. see if its value has
	// the greatest frequency. note that if the list has
	// only 1 element, maxCount = 1 and mostFrequent is
	// the list element
	if (currCount > maxCount)
	{
		maxCount = currCount;
		mostFrequentIter = prevValueIter;
	}

	// assign the frequency
	numOccurrences = maxCount;

	// return an iterator pointing to the most frequently
	// occuring element
	return mostFrequentIter;
}

template <class T>
void freq(const orderedList<T>& aList)
{
	// make a copy of aList. successively call
	// mode() to locate the most frequently occurring
	// element in tmpList. output the current mode
	// and frequency and then remove all occurrences
	// of the mode from tmpList
	orderedList<T> tmpList = aList;
	// use currModeIter to locate and remove all values of the
	// current mode from the list
	orderedList<T>::iterator currModeIter;
	// current frequency
	int currFreq;
	int i;

	// output mode and frequencies, removing elements until
	// the temporary list is empty
	while (!tmpList.empty())
	{
		// locate the current mode and its frequency.
		// output the result
		currModeIter = mode(tmpList.begin(), tmpList.end(), currFreq);

		cout << *currModeIter << '(' << currFreq << ')'
			  << "  ";

		// erase currFreq occurrences of currMode
		// from the list
		for (i=0;i < currFreq;i++)
			tmpList.erase(currModeIter++);
	}
	cout << endl;
}

/*
Run:

7(5)  3(4)  4(2)  5(2)  12(2)  2(1)  8(1)
*/
