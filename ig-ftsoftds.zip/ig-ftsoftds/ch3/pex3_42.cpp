#include <iostream>
#include <string>

using namespace std;

// return the index of the last occurrence of target in the
// range [first, last) or last if target is not in the range
template <typename T>
int find_last_of(T arr[], int first, int last, const T& target);

int main()
{
	int intArr[10] = {2, 5, 3, 5, 4, 7, 5, 1, 8, 9};
	char charArr[] = "mathematics";
	string strArr[5] = {"june", "joe", "glenn", "joe", "glenn"};

	cout << "Index for the last occurrence of 5 in intArr = "
		  << find_last_of(intArr, 0, 10, 5) << endl;

	cout << "Index for the last occurrence of 'a' in charArr = "
		  << find_last_of(charArr, 0, 11, 'a') << endl;

	cout << "Index for the last occurrence of \"glenn\" in strArr = "
		  << find_last_of(strArr, 0, 5, string("glenn")) << endl;

   return 0;
}

template <typename T>
int find_last_of(T arr[], int first, int last, const T& target)
{	
	int i,retValue = last;

	// scan indices in the range first <= i < last
	for(i=first; i < last; i++)
		if (arr[i] == target)	// assume T has the "==" operator
				retValue = i;			// save index of a match

	// return the index of the final match with target or last if
	// no match occurred
	return retValue;
}

/*
Run:

Index for the last occurrence of 5 in intArr = 6
Index for the last occurrence of 'a' in charArr = 6
Index for the last occurrence of "glenn" in strArr = 4
*/
