#include <iostream>

#include "complexx.h"

using namespace std;

int main()
{
	// complex number i = 0 +1i
	complex i(0,1), z1, z2;

	// input values
	cout << "Enter two complex numbers: ";
	cin >> z1 >> z2;

	cout << "Test the binary arithmetic operators:" << endl;
	cout << " z1 + z2 = " << (z1 + z2) << endl;
	cout << " z1 - z2 = " << (z1 - z2) << endl;
	cout << " z1 * z2 = " << z1 * z2 << endl;
	cout << " z1 / z2 = " << z1 / z2 << endl;

	// test relational equality
	if (z1 == z2)
		cout << z1 << " = " << z2 << endl;
	else
		cout << z1 << " != " << z2 << endl;

	// verify that i*i = -1 and that -i*i = 1
	cout << "i*i = " << i * i << endl;
	cout << "-i*i = " << -i * i << endl;

	return 0;
}

/*
Run:

Enter two complex numbers: (3,5) (8,6)
Test the binary arithmetic operators:
 z1 + z2 = (11,11)
 z1 - z2 = (-5,-1)
 z1 * z2 = (-6,58)
 z1 / z2 = (0.54,0.22)
(3,5) != (8,6)
i*i = (-1,0)
-i*i = (1,0)
*/
