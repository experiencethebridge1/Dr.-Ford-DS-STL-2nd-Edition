#include <iostream>
#include <cstdlib>

#include "d_rect.h"

using namespace std;

int main()
{
	// input the number of rooms in the house
	int n;
	// dynamically allocate an array of n rectangles
	rectangle *room;
	int i;
	// maintains the index of the room with largest perimeter.
	// the -1 is replaced by 0 immediately
	int maxPerimIndex = -1;
	// input dimensions of each room
	double length, width;
	// maintain total area and maximum room perimeter. the 
	// 0.0 value for maxPerimeter is immediately replaced by
	// perimeter of the first room
	double totalArea = 0.0, maxPerimeter = 0.0;

	// prompt for the number of rooms and allocate an array
	// of rectangle objects
	cout << "Enter the number of rooms in the house: ";
	cin >> n;

	room = new rectangle [n];
	if (room == NULL)
	{
		cerr << "Cannot allocate the array of rectangles" << endl;
		exit(1);
	}

	// input dimensions of each room, compute total area of
	// rooms, and locate room with the largest perimeter
	for (i=0;i < n;i++)
	{
		// input room dimensions and set the dimensions of the
		// corresponding rectangle
		cout << "Room dimension: ";
		cin >> length >> width;
		room[i].setSides(length, width);

		// change maxPerimeter if a larger perimeter is found
		if (room[i].perimeter() > maxPerimeter)
		{
			maxPerimeter = room[i].perimeter();
			maxPerimIndex = i;
		}
		
		// keep running total of room area
		totalArea += room[i].area();
	}

	// output the total area and the dimensions of the room
	// with the largest perimeter
	cout << endl << "Total area of the rooms = "
		  << totalArea << endl;
	cout << "The room with the largest perimeter is "
		  << room[maxPerimIndex].getLength() << " x "
		  << room[maxPerimIndex].getWidth() << endl;
	
	return 0;
}

/*
Run:

Enter the number of rooms in the house: 5
Room dimension: 15 20
Room dimension: 10 12
Room dimension: 10 10
Room dimension: 9 9
Room dimension: 18 15

Total area of the rooms = 871
The room with the largest perimeter is 15 x 20
*/
