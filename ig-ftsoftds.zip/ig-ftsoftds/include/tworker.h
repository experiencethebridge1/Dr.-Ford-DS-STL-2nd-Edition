#ifndef TEMPWORKER_CLASS
#define TEMPWORKER_CLASS

#include "d_time24.h"

class tempWorker
{
	public:
		tempWorker(const time24& start, const time24& end, double rate);
			// constructor has arguments to initialize both the time24
			// data and the rate per hour

		double pay() const;
			// return pay for the day

	private:
		time24 startWork, endWork;
		double ratePerHour;
};


tempWorker::tempWorker(const time24& start, const time24& end,
							  double rate):
	startWork(start), endWork(end), ratePerHour(rate)
{}

double tempWorker::pay() const
{
	// compute time worked by subtracting starting time from
	// ending time
	time24 timeWorked = endWork - startWork;

	// convert timeWorked to hours and multiply by rate per hour
	return
	(timeWorked.getHour() + timeWorked.getMinute()/60.0)*ratePerHour;
}

#endif	// TEMPWORKER_CLASS
