#include <iostream>

#include "stack_p.h"

using namespace std;

int main()
{
	int i, n;
	miniStack<int> q;

	cout << "Enter 5 integer values: ";

	for (i=0;i < 5;i++)
	{
		cin >> n;
		q.push(n);
	}

	cout << "Flushing the stack: ";
	while (!q.empty())
	{
		cout << q.top() << "  ";
		q.pop();
	}
	cout << endl;

	return 0;
}

/*
Run:

Enter 5 integer values: 1 2 3 4 5
Flushing the stack: 5  4  3  2  1
*/
