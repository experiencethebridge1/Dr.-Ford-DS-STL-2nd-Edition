#ifndef UNORDERED_MAP_CLASS
#define UNORDERED_MAP_CLASS

#include "d_pair.h"		// miniPair class
#include "d_hash.h"		// hash class

// implements a map containing key/value pairs.
// a map does not contain multiple copies of the same item.
// types Key and T must have a default constructor. HashFunc
// is the hash function object type
template <typename Key,typename T,typename HashFunc>
class umap
{
	public:
		// umap iterators are simply hash iterators. an iterator cannot
		// change the key, since the key attribute of a miniPair object is const.
		typedef hash<miniPair<const Key,T>, HashFunc>::iterator iterator;
		typedef hash<miniPair<const Key,T>, HashFunc>::const_iterator const_iterator;

		typedef miniPair<const Key, T> value_type;
			// for programmer convenience

		umap(int tableSize = 1237);
			// default constructor. create an empty map. default hash
			// table size is 1237

		umap(value_type *first, value_type *last, int tableSize = 1237);
			// build a map whose key/value pairs are determined by pointer
			// values [first, last). default hash table size is 1237

		bool empty() const;
			// is the map empty?

		int size() const;
			// return the number of elements in the map

		iterator find (const Key& key);
			// search for item in the map with the given key
			// and return an iterator pointing at it, or end()
			// if it is not found

		const_iterator find (const Key& key) const;
			// constant version of find()

		T& operator[] (const Key& key);
			// if no value is associated with key, create a new
			// map entry with the default value T() and return a
			// reference to the default value; otherwise,
			// return a reference to the value already associated
			// with the key

		int count(const Key& key) const;
			// returns 1 if an element with the key is in the map
			// and 0 otherwise

		miniPair<iterator,bool> insert(const value_type& kvpair);
			// if the map does not contain a key/value pair whose
			// key matches that of kvpair, insert a coy of kvpair
			// and return a miniPair object whose first element is an
			// iterator positioned at the new key/value pair and whose second
			// element is true. if the map already contains a key/value
			// pair whose key matches that of kvpair, return a miniPair
			// object whose first element is an iterator positioned at the
			// existing key/value pair and whose second element is false

		int erase(const Key& key);
			// erase the key/value pair with the specified key
			// from the map and return the number
			// of items erased (1 or 0)

		void erase(iterator pos);
			// erase the map key/value pair pointed by to pos

		void erase(iterator first, iterator last);
			// erase the key/value pairs in the range [first, last)

		iterator begin();
			// return an iterator pointing at the first member
			// in the map
		const_iterator begin() const;
			// constant version of begin()

		iterator end();
			// return an iterator pointing just past the last
			// member in the map
		const_iterator end() const;
			// constant version of end()

	private:
		// umap implemented using a hash table of key-value pairs
		hash<miniPair<const Key,T>, HashFunc> ht;
};

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::umap(int tableSize): ht(tableSize)
{}

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::umap(value_type *first, value_type *last, int tableSize):
		ht(tableSize,first,last)
{}

template <typename Key, typename T, typename HashFunc>
bool umap<Key,T,HashFunc>::empty() const
{
	return ht.empty();
}

template <typename Key, typename T, typename HashFunc>
int umap<Key,T,HashFunc>::size() const
{
	return ht.size();
}

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::iterator umap<Key,T,HashFunc>::find (const Key& key)
{
	return ht.find(key);
}

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::const_iterator umap<Key,T,HashFunc>::find (const Key& key) const
{
	return ht.find(key);
}

template <typename Key, typename T, typename HashFunc>
T& umap<Key,T,HashFunc>::operator[] (const Key& key)
{
	// build a miniPair object consisting of key
	// and the default value T()
	value_type tmp(key, T());

	// try to insert tmp into the map. the iterator
	// returned points at either the newly created
	// key/value pair or a pair already in the map.
	// return a reference to the value
	return (*(ht.insert(tmp).first)).second;
}

template <typename Key, typename T, typename HashFunc>
int umap<Key,T,HashFunc>::count(const Key& key) const
{
	return ht.count(key);
}

template <typename Key, typename T, typename HashFunc>
miniPair<umap<Key,T,HashFunc>::iterator, bool>
umap<Key,T,HashFunc>::insert(const value_type& kvpair)
{
	return ht.insert(kvpair);
}

template <typename Key, typename T, typename HashFunc>
int umap<Key,T,HashFunc>::erase(const Key& key)
{
	return ht.erase(key);
}

template <typename Key, typename T, typename HashFunc>
void umap<Key,T,HashFunc>::erase(iterator pos)
{
	ht.erase(pos);
}

template <typename Key, typename T, typename HashFunc>
void umap<Key,T,HashFunc>::erase(iterator first, iterator last)
{
	ht.erase(first, last);
}

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::iterator umap<Key,T,HashFunc>::begin()
{
	return ht.begin();
}

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::const_iterator umap<Key,T,HashFunc>::begin() const
{
	return ht.begin();
}

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::iterator umap<Key,T,HashFunc>::end()
{
	return ht.end();
}

template <typename Key, typename T, typename HashFunc>
umap<Key,T,HashFunc>::const_iterator umap<Key,T,HashFunc>::end() const
{
	return ht.end();
}

#endif	// UNORDERED_MAP_CLASS
