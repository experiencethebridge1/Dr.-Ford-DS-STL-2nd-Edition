#include <iostream>

#include "d_node.h"
#include "d_nodel.h"
#include "d_random.h"

using namespace std;

// count the number of times item occurs in a linked list
template <typename T>
int countValue(node<T> *front, const T& item);

int main()
{
	// list initially empty
	node<int> *front = NULL;
	int i;
	randomNumber rnd;

	for (i=0;i < 20;i++)
		// insert a random integer in the range 0..4 at the
		// front of the list
		front = new node<int> (rnd.random(5), front);

	// output the list of random integers
	writeLinkedList(front);
	cout << endl;

	// output the number of times each value from 0 to 4
	// occurs in the list
	for(i=0;i < 5;i++)
		cout << i << ": " << countValue(front,i) << endl;

	return 0;
}

template <typename T>
int countValue(node<T> *front, const T& item)
{
	// move curr through the list
	node<T> *curr = front;
	int count = 0;

	// count nodes until arrive at the end of the list
	while (curr != NULL)
	{
		if (curr->nodeValue == item)
			// count an occurrence of item
			count++;
		// move to the next node
		curr = curr->next;
	}

	// return the node count
	return count;
}

/*
Run:

2 3 4 0 1 0 2 4 2 3 3 4 3 3 3 0 0 2 0 2
0: 5
1: 1
2: 5
3: 6
4: 3
*/
