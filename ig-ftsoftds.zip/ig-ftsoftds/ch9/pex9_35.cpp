#include <iostream>

#include "d_list.h"
#include "d_random.h"

using namespace std;

// given an n item circular list, solve the Josephus problem
// by deleting every m th person until only one remains.
void josephus(int n, int m);

int main()
{
	// numContestants is number of contestants
	// removeM is the rotation selector
	randomNumber rnd;
	int numContestants, removeM;

	cout << "Enter the number of contestants: ";
	cin >> numContestants;
	
	// generate a random number between 1 and numContestants
	removeM = 1 + rnd.random(numContestants);
	cout << "Generated the random number " << removeM << endl;

	// solve the Josephus problem and output the cruise winner
	josephus(numContestants, removeM);

	return 0;
}

void josephus(int n, int m)
{
	// declare the list object jList and a list iterator
	miniList<int> jList;
	miniList<int>::iterator curr;
	int i, j;

	// initialize the list of contestants 1 2 3 ... n
	for (i = 1; i <= n; i++)
		jList.push_back(i);

	// curr moves around the list, starting at person 1
	curr = jList.begin();

	// delete all but one person from the list
	for(i=1; i < n; i++)
	{
		// counting current person at curr, visit m persons.
		// we must advance m-1 times.
		for(j=1; j <= m-1; j++)
		{
			// advance the iterator
			curr++;

			// if curr at the end of the list, move again
			if (curr == jList.end())
				 curr++;
		}

		cout << "Delete contestant " << *curr << endl;

		// advance curr and erase the node we just left
		jList.erase(curr++);

		// might have deleted the rear of the list, so
		// curr is now at the end of the list. move again
		if (curr == jList.end())
			curr++;
	}

	cout << endl << "Contestant " << *curr
		  << " wins the cruise" << endl;
}

/*
Run:

Enter the number of contestants: 10
Generated the random number 5
Delete contestant 5
Delete contestant 10
Delete contestant 6
Delete contestant 2
Delete contestant 9
Delete contestant 8
Delete contestant 1
Delete contestant 4
Delete contestant 7

Contestant 3 wins the cruise
*/
