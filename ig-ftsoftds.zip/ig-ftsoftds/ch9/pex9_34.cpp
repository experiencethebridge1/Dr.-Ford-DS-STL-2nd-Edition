#include <iostream>

#include "d_dnode.h"
#include "d_nodel.h"
#include "d_random.h"

using namespace std;

// insert item into an ordered list
template <typename T>
void insertOrder(dnode<T> *header, const T& item);

// erase all list elements in the range [first, last)
template <typename T>
void eraseRange(dnode<T> *first, dnode<T> *last);

int main()
{
	// doubly-linked list header
	dnode<int> *header = new dnode<int>, *curr;
	randomNumber rnd;
	int n, i, intValue;

	cout << "Enter an integer: ";
	cin >> n;

	cout << "Generating an ordered doubly linked list containing "
		  << endl << n << " random integer values in the range 0..99 " << endl;

	for (i=0;i < n;i++)
	{
		intValue = rnd.random(100);
		// insert intValue into the ordered doubly linked list
		insertOrder(header, intValue);
	}

	cout << "Original ordered list:    ";
	writeDLinkedList(header);
	cout << endl;

	// scan the list
	curr = header->next;
	while (curr != header)
	{
		// break out of the loop if we find a value > 50
		if (curr->nodeValue > 50)
			break;

		// move forward
		curr = curr->next;
	}

	// erase all nodes in the range [curr,header), which
	// is all the nodes between curr and the end of the list.
	// note that if there are no such values, curr = header and
	// eraseAll() will do nothing
	eraseRange(curr, header);

	cout << "List after erasing all values > 50:    ";
	writeDLinkedList(header);
	cout << endl;

	return 0;
}

template <typename T>
void insertOrder(dnode<T> *header, const T& item)
{
   // curr starts at first list element
  dnode<T> *curr = header->next;

   // find the insertion point, which may be at end of list
   while ((curr != header) && (curr->nodeValue < item))
      curr = curr->next;

   // do the insertion using insert()
   insert(curr, item);
}


template <typename T>
void eraseRange(dnode<T> *first, dnode<T> *last)
{
	// curr moves over the range [first, last)
	dnode<T> *curr = first, *d;

	// delete all nodes in the range
	while (curr != last)
	{
		// save the address curr
		d = curr;
		// move curr forward
		curr = curr->next;
		// erase node d
		erase(d);
	}
}

/*
Run:

Enter an integer: 10
Generating an ordered doubly linked list containing
10 random integer values in the range 0..99
Original ordered list:    14  33  35  41  43  52  58  70  79  85
List after erasing all values > 50:    14  33  35  41  43 
*/
