#include <iostream>

#include "d_util.h"	// for manipulator setreal()

using namespace std;

// use bisection to approximate the root of f() between
// a and b
double bisect(double f(double x),
				  double a, double b, double precision);

// computes and returns the balance after paying simple interest
// on the given principal with monthly interest for nmonths. 
double balance(double principal, double interest,
					int nmonths, double payment);

// use balance() to compute the amount owing on a
// $150000 loan at 10% per year for 25 years. the
// payment is x dollars per month
double speficBalance(double x);

int main()
{
	// find the root of specificBalance() between the payments of .01 and 150000.
	// use precision = 1.0e-4
	cout << "Payment on the loan is $"
		 << setreal(1,2) << bisect(speficBalance, .01,150000.0, 1.0e-4)
		 << endl;

	return 0;
}

double bisect(double f(double x),
				  double a, double b, double precision)
{
	double m;

	// m is the midpoint of a < x < b
	m = (a+b)/2.0;

	// if m is a root or the length of our interval has
	// become small enough, return m
	if (f(m) == 0.0 || (b-a) < precision)
		return m;
	else if (f(a) * f(m) < 0)
		// the root in the the interval a < x < m
		return bisect(f, a, m, precision);
	else
		// the root is in the interval m < x < b
		return bisect(f, m, b, precision);
}

double balance(double principal, double interest, int nmonths, double payment)
{	
	// subtract interest from the payment. use this amount to
	// reduce the principal. do this for nmonths
	for(int i=1;i <= nmonths;i++)
		principal -= payment - principal*interest;

	return principal;
}

double speficBalance(double x)
{
	// interest per month = .10/12,
	// number of payments = 25*12
	return balance(150000.0,.10/12.0,25*12,x);
}

/*
Run:

Payment on the loan is $1363.05
*/
