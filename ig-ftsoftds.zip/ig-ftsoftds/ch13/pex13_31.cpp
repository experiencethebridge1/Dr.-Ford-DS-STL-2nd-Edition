#ifdef __BORLANDC__
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <list>
#include <vector>

#include "d_orderl.h"
#include "d_util.h"

using namespace std;

// sort vector v by inserting into an ordered list
template <typename T>
void listSort(vector<T>& v);

int main()
{
	// integer and string arrays that supply the data for the vectors
	int intArr[] = {5, 8, 12, 25, 23, 1, 3, 3, 5, 15, 25, 5};
	string stringArr[] = {"Mississippi", "Alabama", "Massachusetts",
								 "Arizona", "Maine"};
	int intArrSize = sizeof(intArr)/sizeof(int),
		 stringArrSize = sizeof(stringArr)/sizeof(string);

	// declare the vectors
	vector<int> intVector(intArr, intArr+intArrSize);
	vector<string> stringVector(stringArr, stringArr+stringArrSize);

	// sort the integer vector and output it
	listSort(intVector);
	cout << "Sorted integer vector:" << endl;
	writeContainer(intVector.begin(), intVector.end());
	cout << endl << endl;

	// sort the string vector and output it
	listSort(stringVector);
	cout << "Sorted string vector:" << endl;
	writeContainer(stringVector.begin(), stringVector.end());
	cout << endl;

	return 0;
}

template <typename T>
void listSort(vector<T>& v)
{
	// use ol to order the elements of v
	orderedList<T> ol;
	// use to traverse ordered list
	orderedList<T>::iterator iter;
	// capture the size of v in n
	int i, n = v.size();

	// insert each element of v into ol
	for (i=0;i < n;i++)
		ol.insert(v[i]);

	// traverse ol and copy the elements to
	// v[0], v[1], ..., v[n-1]
	iter = ol.begin();
	for (i=0;i < n;i++)
	{
		v[i] = *iter;
		iter++;
	}
}

/*
Run:

Sorted integer vector:
1  3  3  5  5  5  8  12  15  23  25  25

Sorted string vector:
Alabama  Arizona  Maine  Massachusetts  Mississippi
*/
