#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>

#include "d_setops.h"
#include "d_util.h"		// for writeContainer()

using namespace std;

// return the set of all elements x that are contained in either
// setA or setB but not in both
template <typename T>
set<T> symDifference(const set<T>& setA, const set<T>& setB);

int main()
{
	// initialize sets from the characters in the strings
	string strA = "hogtied", strB = "dog", strC = "horn";
	set<char> setA(strA.c_str(), strA.c_str()+strA.length()),
				 setB(strB.c_str(), strB.c_str()+strB.length()),
				 setC(strC.c_str(), strC.c_str()+strC.length()),
				 symDiff;

	// compute the symmetric difference of setA and setB
	symDiff = symDifference(setA, setB);
	cout << "Characters that are not common to setA and setB: ";
	writeContainer(symDiff.begin(), symDiff.end());
	cout << endl;

	// compute the symmetric difference of setA and setC
	symDiff = symDifference(setA, setC);
	cout << "Characters that are not common to setA and setC: ";
	writeContainer(symDiff.begin(), symDiff.end());
	cout << endl;

	return 0;
}

template <typename T>
set<T> symDifference(const set<T>& setA, const set<T>& setB)
{
	// symmetric difference is all elements in both setA
	// and setB (union) that are not common to
	// setA and setB (intersection)
	return setA + setB - setA*setB;
}

/*
Run:

Characters that are not common to setA and setB: e  h  i  t
Characters that are not common to setA and setC: d  e  g  i  n  r  t
*/
