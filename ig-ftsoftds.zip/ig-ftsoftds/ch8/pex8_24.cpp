#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <queue>

#include "d_except.h"

using namespace std;

// move item n to the front of the queue. note that
// n = 1 is the front of the queue
template <typename T>
void n2front(queue<T>& q, int n);

int main()
{
	int n, i;
	queue<int> intQueue;

	// input 8 integers and insert them into the queue
	cout << "Enter 8 integer values: ";
	for (i=0;i < 8;i++)
	{
		cin >> n;
		intQueue.push(n);
	}

	cout << "Enter a position in the queue (1 <= n <= " << intQueue.size()
		  << "): ";
	cin >> n;

	// move the nth element to the top of q
	n2front(intQueue, n);

	// flush the queue and output its elements
	cout << "After moving element " << n
		  << " to the top, the queue is:" << endl;
	while (!intQueue.empty())
	{
		cout << intQueue.front() << "  ";
		intQueue.pop();
	}
	cout << endl;

	return 0;
}

template <typename T>
void n2front(queue<T>& q, int n)
{
	// algorithm uses a temporary queue
	queue<T> tmp;
	// use to save nth value
	T newFront;
	int i;

	// verify that n is in the correct range
	if (n < 1 || n > q.size())
		throw rangeError();

	// nothing to do if n is 1
	if (n == 1)
		return;

	// move top n-1 items from q to tmp. note that their order
	// on tmp is the same as their order on q
	for (i=1;i <= n-1;i++)
	{
		tmp.push(q.front());
		q.pop();
	}

	// save nth item and pop q
	newFront = q.front();
	q.pop();

	// move the remaining items from q to tmp
	while (!q.empty())
	{
		tmp.push(q.front());
		q.pop();
	}

	// insert newFront at the front of q (q empty)
	q.push(newFront);

	// move the elements from tmp to q
	while (!tmp.empty())
	{
		q.push(tmp.front());
		tmp.pop();
	}
}

/*
Run:

Enter 8 integer values: 1 2 3 4 5 6 7 8
Enter a position in the queue (1 <= n <= 8): 5
After moving element 5 to the top, the queue is:
5  1  2  3  4  6  7  8
*/
