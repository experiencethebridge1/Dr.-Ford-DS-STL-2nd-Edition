#include <iostream>
#include <string>

using namespace std;

// if strA < strB return strA + strB; otherwise, return
// strB + strA
string newString(const string& strA, const string& strB);

int main()
{
	string A = "String", B = "cat"; 

	cout << newString(A,B) << endl;
	cout << newString(A,"C++") << endl;

	return 0;
}

string newString(const string& strA, const string& strB)
{
	if (strA < strB)
		return strA + strB;
	else
		return strB + strA;
}

/*
Run:

Stringcat
C++String
*/