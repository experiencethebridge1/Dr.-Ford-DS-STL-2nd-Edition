#include <iostream>
#include <list>

#include "d_util.h"
#include "intentry.h"

using namespace std;

// insert intEntry object item into the ordered list. for each
// duplicate, increment the count
void insertOrder(list<intEntry>& orderedList, const intEntry& item);

int main()
{
	list<intEntry> intEntryList;
	int n, i;

	cout << "Enter 10 integer values: ";
	for (i=0;i < 10;i++)
	{
		cin >> n;
		// insert n into the ordered list intEntryList. if n is not
		// in the list, it enters the list with a default count of 1
		insertOrder(intEntryList, intEntry(n));
	}

	cout << "The list is" << endl;
	// output the list
	writeList(intEntryList);

	return 0;
}

void insertOrder(list<intEntry>& orderedList, const intEntry& item)
{
   // curr starts at first list element, stop marks end
   list<intEntry>::iterator curr = orderedList.begin(),
											  stop = orderedList.end();

   // find the insertion point, which may be at end of list
   while ((curr != stop) && (*curr < item))
      curr++;

	// if not at end of list and *curr has the same value as item,
	// increment the count of *curr and do not insert item into the list
	if (curr != stop && *curr == item)
			(*curr).increment();
	else
		// do the insertion using insert()
		orderedList.insert(curr, item);
}

/*
Run:

Enter 10 integer values: 2 3 3 5 2 3 6 8 2 5
The list is
2 2 2   3 3 3   5 5   6   8
*/
