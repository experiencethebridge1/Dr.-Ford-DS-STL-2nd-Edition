#include <iostream>

#include "openhash.h"	// openHash class
#include "d_hashf.h"		// hash function object types. use hFintID

using namespace std;
 
int main()
{
	// array that holds 10 integers with some duplicates
	int intArr[] = {20, 16, 9, 14, 8, 17, 3, 9, 16, 12};
	int arrSize = sizeof(intArr)/sizeof(int);
	
	// alias describing integer hash table using identity function
	// object
	typedef openHash<int, hFintID> hashTable;

	// hash table with 11 (prime number) buckets and hash iterator.
	// there will be some collisions
	hashTable ht(11);
	hashTable::iterator hIter;

	// <iterator,bool> pair for the insert operation
	pair<hashTable::iterator, bool> p;

	int item, i;

	// insert elements from intArr, noting duplicates
	for (i = 0; i < arrSize; i++)
	{
		p = ht.insert(intArr[i]);
		if (p.second == false)
			cout << "Duplicate value " << intArr[i] << endl;
	}

	// output the hash size which reflects duplicates
	cout << endl << "Hash table size " << ht.size() << endl;

	// output the elements using an iterator to scan the table
	cout << "Initial hash table contents" << endl;
	for (hIter = ht.begin(); hIter != ht.end(); hIter++)
		cout << *hIter << "  ";
	cout << endl << endl;

	// prompt for item to erase and indicate if not found
	for (i = 1; i <= 2; i++)
	{
		cout << "Enter a number to delete: ";
		cin >> item;

		if ((hIter = ht.find(item)) == ht.end())
			cout << "Item not found" << endl;
		else
			ht.erase(hIter);
	}

	// output the elements using an iterator to scan the table
	for (hIter = ht.begin(); hIter != ht.end(); hIter++)
		cout << *hIter << "  ";
	cout << endl;

	return 0;
}

/*
Run:

Duplicate value 9
Duplicate value 16

Hash table size 8
Initial hash table contents
12  14  3  16  17  8  20  9

Enter a number to delete: 10
Item not found
Enter a number to delete: 17
12  14  3  16  8  20  9
*/
