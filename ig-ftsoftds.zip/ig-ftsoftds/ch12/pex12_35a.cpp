#include <iostream>

#include "d_stree.h"		// stree class

using namespace std;

int main()
{
	int arr[] = {20, 35, 5, 18, 7, 15, 22, 6, 37, 3, 19,
					 55, 38, 8, 2, 16, 12, 17, 13};
	int arrSize = sizeof(arr)/sizeof(int);
	// binary search tree containing data from arr
	stree<int> t(arr, arr+arrSize);

	// output the tree
	t.displayTree(2);
	cout << endl;

   return 0;
}

/*
Run:

                                        20
        5                                     35
     3                            18       22    37
  2           7                      19                55
           6             15                         38
                 8          16
                   12          17
                      13
*/
