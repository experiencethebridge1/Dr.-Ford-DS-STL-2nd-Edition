#include <iostream>
#include <utility>	// for pair class

#include "d_stree.h"
#include "int.h"
#include "d_random.h"

using namespace std;

int main()
{
	// binary search tree of integer objects
	stree<integer> integerTree;
	// declare a tree iterator
	stree<integer>::iterator iter;
	pair<stree<integer>::iterator, bool> p;
	randomNumber rnd;
	int i;

	// generate 10,000 random integer values
	for (i=0;i < 10000;i++)
	{
		// attempt to insert a random integer in the range 0 to 6
		// with count 1 into the tree. if insert() indicates that the value
		// is already in the tree, increase its count using incCount()
		p = integerTree.insert(integer(rnd.random(7)));
		if (p.second == false)
			(*p.first).incCount();
	}

	// output the tree values inorder using iter
	cout << "Values in the tree:" << endl;
	iter = integerTree.begin();
	while (iter != integerTree.end())
	{
		cout << *iter << endl;
		iter++;
	}
	cout << endl;

	// use displayTree() to picture the tree
	cout << "The tree is " << endl << endl;
	integerTree.displayTree(8);

   return 0;
}

/*
Run:

Values in the tree:
0 (1441)
1 (1399)
2 (1487)
3 (1471)
4 (1432)
5 (1345)
6 (1425)

The tree is

                            3 (1471)
 0 (1441)                                     5 (1345)
          1 (1399)                   4 (1432)          6 (1425)
                   2 (1487)
*/
