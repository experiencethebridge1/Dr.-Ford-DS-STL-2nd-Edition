#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#include <iostream>
#include <queue>
#include <stack>

using namespace std;

int main()
{
	// declare an integer queue and stack
	queue<int> q;
	stack<int> s;
	// initialize a vector
	int arr[] = {1, 3, 5, 7}, i;
	int arrSize = sizeof(arr)/sizeof(int);
	vector<int> v(arr, arr+arrSize);

	// push each element of the vector onto the
	// queue and the stack
	for (i=0;i < v.size();i++)
	{
		q.push(v[i]);
		s.push(v[i]);
	}

	// flush the stack at push each element onto the queue.
	// the new elements are the initial values of the queue
	// in reverse order
	while (!s.empty())
	{
		q.push(s.top());
		s.pop();
	}

	// flush and output the queue elements
	while (!q.empty())
	{
		cout << q.front() << "  ";
		q.pop();
	}
	cout << endl;

	return 0;
}

/*
Run:

1  3  5  7  7  5  3  1
*/
