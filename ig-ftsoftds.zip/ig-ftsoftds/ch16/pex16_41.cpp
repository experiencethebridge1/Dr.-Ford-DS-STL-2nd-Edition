#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>
#include <stack>
#include <algorithm>

#include "d_graph.h"
#include "d_util.h"

using namespace std;

// perform a depth-first search of g from sVertex. construct
// dfsList by inserting the current vertex at the back of
// dfsList and then visiting the neighbors of v
template <typename T>
void dfsIterVisit(graph<T>& g, const T& sVertex, list<T>& dfsList);

int main()
{	
	graph<char> g;
	// use giter to traverse the vertices of g
	graph<char>::iterator giter;
	// holds each dfs list
	list<char> dfsList;
	ifstream fin;

	fin.open("graphB.dat");
	fin >> g;

	// move through the vertices
	giter = g.begin();
	while (giter != g.end())
	{
		// do a depth-first search from *giter
		dfsIterVisit(g, *giter, dfsList);
		// output the starting vertex and the visit list
		cout << "From " << *giter << ": ";
		writeContainer(dfsList.begin(), dfsList.end());
		cout << endl;

		giter++;
	}

	return 0;
}

template <typename T>
void dfsIterVisit(graph<T>& g, const T& sVertex, list<T>& dfsList)
{
	// set for the neighbors of a vertex
	set<T> neighbors;
	set<T>::iterator siter;
	// use a stack to implement the depth-first search
	stack<T> s;
	T currVertex;

	// clear dfsList and push sVertex onto the stack
	dfsList.erase(dfsList.begin(), dfsList.end());
	s.push(sVertex);

	// continue until the stack is empty
	while (!s.empty())
	{
		// record the top of the stack as the current vertex
		// and pop the stack
		currVertex = s.top();
		s.pop();

		// insert currVertex onto the back of dfsList
		dfsList.push_back(currVertex);

		// obtain the neighbors of currVertex
		neighbors = g.getNeighbors(currVertex);

		// traverse the neighboring vertices
		siter = neighbors.begin();
		while (siter != neighbors.end())
		{
			// if *siter is not in visited (we haven't encountered
			// it yet), push it on the stack
			if (find(dfsList.begin(), dfsList.end(), *siter) ==
											  dfsList.end())
				s.push(*siter);

			siter++;
		}
	}
}

/*
Run:

From A: A  F  E  D  B  C
From B: B  C  D  F  E  A
From C: C  D  F  E  B  A
From D: D  F  E
From E: E  F
From F: F  E
*/
