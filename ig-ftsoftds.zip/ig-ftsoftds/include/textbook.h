#ifndef BOOK_TEXTBOOK_CLASSES
#define BOOK_TEXTBOOK_CLASSES

#include <iostream>
#include <string>

using namespace std;

enum coverType {HardCover, SoftCover};

class book
{
	public:
		book(coverType ct, int pglen): cover(ct), pageLength(pglen)
		{}
      
		virtual void describe()
		{
			cout << "A " << pageLength << " page";
			if (cover == HardCover)
				cout << " hard covered book" << endl;
			else
				cout << " soft covered book" << endl;
		}
	protected:
		coverType cover;
		int pageLength;
};

class textbook: public book
{
	public:
		// constructor
		textbook(coverType ct, int pglen, const string& subject):
					book(ct, pglen), subjectMatter(subject)
  		{}
	
		virtual void describe()
		{
			book::describe();	// describe book attributes 	
			cout << "Used for courses in " << subjectMatter << endl;
		}
	private:
		string subjectMatter;
};

#endif	// BOOK_TEXTBOOK_CLASSES
