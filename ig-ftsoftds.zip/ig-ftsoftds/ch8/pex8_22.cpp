#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <queue>
#include <stack>
#include <string>

#ifdef _MSC_VER
// compensates for VC++ 6.0 bug in getline() from <string>
#include "d_util.h"
#endif	// _MSC_VER

using namespace std;

int main()
{
	string text;
	char ch;
	// q records characters in order of occurrence
	queue<char> q;
	// s records characters in reverse order of occurrence
	stack<char> s;
	int i;

	cout << "Enter a line of text in lowercase:" << endl;
	getline(cin, text);

	// cycle through the text
	for (i=0;i < text.length();i++)
	{
		ch = text[i];

		// if ch is a letter, push it on the queue and the stack
		if (ch >= 'a' && ch <= 'z')
		{
			q.push(ch);
			s.push(ch);
		}
	}

	// compare the front of the queue with the top
	// of the stack until both are empty or we find
	// two characters that are not equal
	while (!q.empty())
	{
		if (q.front() != s.top())
			break;
		q.pop();
		s.pop();
	}

	// if the queue is empty, we have a palindrome
	if (q.empty())
		cout << text << " is a palindrome" << endl;
	else
		cout << text << " is not a palindrome" << endl;

	return 0;
}

/*
Run 1:

Enter a line of text in lowercase:
go hang a salami i'm a lasagna hog
go hang a salami i'm a lasagna hog is a palindrome

Run 2:

Enter a line of text in lowercase:
abcdefdcba
abcdefdcba is not a palindrome
*/
