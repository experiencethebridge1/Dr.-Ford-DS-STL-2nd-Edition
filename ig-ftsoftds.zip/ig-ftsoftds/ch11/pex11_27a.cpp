#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>

#include "d_state.h"
#include "d_util.h"

using namespace std;

int main()
{
	// vals contains initial values for s
	stateCity vals[] = {stateCity("Arizona", "Phoenix"),
							  stateCity("Illinois", "Chicago"),
							  stateCity("California", "Sacramento") };
	set<stateCity> s(vals, vals+3);
	set<stateCity>::iterator iter;
	string state;

	cout << "Enter a state: ";
	getline(cin, state);

	// look for state in the set
	if ((iter = s.find(stateCity(state))) != s.end())
		// iter points at a stateCity object. output it
		cout << *iter << endl;
	else
		// the state is not in the set
		cout << state << " is not in the set" << endl;

	return 0;
}

/*
Run 1:

Enter a state: Arizona
Phoenix, Arizona

Run 2:

Enter a state: New York
New York is not in the set
*/
