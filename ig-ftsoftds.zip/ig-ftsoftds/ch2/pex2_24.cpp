#include <iostream>

#include "d_time24.h"

using namespace std;

int main()
{
	// time fo arrival for customers at the restaurant
	time24 cust[5] = {time24(17,15), time24(19,30), time24(17,45),
							time24(18,10), time24(20,0)};
	// early bird special ends at 6:00 PM
	time24 earlyBirdLimit(18,0);
	int i;

	// cycle through the customer arrival times
	for (i=0;i < 5;i++)
	{
		// output time of arrival
		cout << "Time of arrival " << cust[i] << ": ";
		// output whether the customer is eligible for the early
		// bird special (arrival time before 6:00 PM)
		if (cust[i] < earlyBirdLimit)
			cout << "eligible for the special" << endl;
		else
			cout << "not eligible for the special" << endl;
	}

   return 0;
}

/*
Run:

Time of arrival 17:15: eligible for the special
Time of arrival 19:30: not eligible for the special
Time of arrival 17:45: eligible for the special
Time of arrival 18:10: not eligible for the special
Time of arrival 20:00: not eligible for the special 
*/
