#ifndef BINARY_SEARCH_TREE_CLASS
#define BINARY_SEARCH_TREE_CLASS

#ifndef NULL
#include <cstddef>
#endif  // NULL

#include <iomanip>		// for setw()
#include <strstream>		// for format conversion
#include <string>			// node data formatted as a string
#include <queue>
#include <utility>		// pair class

#include "d_except.h"	// exception classes

using namespace std;

// declares a binary search tree node object
template <typename T>
class stnode
{
   public:
		// stnode is used to implement the binary search tree class
		// making the data public simplifies building the class functions

		T nodeValue;
			// node data
		stnode<T> *left, *right, *parent;
		// child pointers and pointer to the node's parent

      // constructor
		stnode (const T& item, stnode<T> *lptr = NULL, 
              stnode<T> *rptr = NULL, stnode<T> *pptr = NULL):
				nodeValue(item), left(lptr), right(rptr), parent(pptr)
		{}
};

// objects hold a formatted label string and the level,column
// coordinates for a shadow tree node
class tnodeShadow
{
	public:
		string nodeValueStr;	// formatted node value
		int level,column;
		tnodeShadow *left, *right;

		tnodeShadow ()
		{}
};

template <typename T>
class mstree
{
	public:

// include the iterator nested classes
#include "mtiter.h"

		mstree();
			// constructor. initialize root to NULL and size to 0
		mstree(T *first, T *last);
			// constructor. insert the elements from the pointer
			// range [first, last) into the tree
		mstree(const mstree<T>& tree);
			// copy constructor
		~mstree();
			// destructor
		mstree<T>& operator= (const mstree<T>& rhs);
			// assignment operator

		iterator find(const T& item);
			// search for the first occurrence of item in the tree.
			// if found, return an iterator pointing at it in the tree;
			// otherwise, return end()
		const_iterator find(const T& item) const;
			// constant version

		int empty() const;
			// indicate whether the tree is empty
		int size() const;
			// return the number of data items in the tree

		iterator lower_bound(const T& item);
			// returns an iterator pointing to the first element inorder
			// whose value is >= item. if all elements in the tree are
			// less than item, the function returns end(). as a consequence,
			// if item is in the tree, this function returns an iterator
			// pointing at the first occurrence, inorder, of item
		const_iterator lower_bound(const T& item) const;
			// constant version

		iterator upper_bound(const T& item);
			// returns an iterator pointing to the first element inorder
			// whose value is > item. if all elements in the tree are
			// less than item, the function returns end(). as a consequence,
			// if item is in the tree, this function returns an iterator
			// pointing just after the last occurrence, inorder, of item
		const_iterator upper_bound(const T& item) const;
			// constant version

		pair<iterator, iterator>
		equal_range(const T& item);
			// return a pair of iterators such that all occurrences of item
			// in the tree are in the range specified by the pair's first and
			// second element
		pair<const_iterator, const_iterator>
		equal_range(const T& item) const;
			// constant version

		int count(const T& item) const;
			// return the number of occurrences of item in the tree

		iterator insert(const T& item);
			// insert item into the tree and return an iterator
			// positioned at the new element
			// Postcondition: the tree size increases by 1

		int erase(const T& item);
			// erase all elements from the tree that match item and
			// return the number of elements that were erased
			// Postcondition: the tree size decreases by the number
			// of elements erased

		void erase(iterator pos);
			// erase the item pointed to by pos.
			// Preconditions: the tree is not empty and pos points
			// to an item in the tree. if the tree is empty, the
			// function throws the underflowError exception. if the
			// iterator is invalid, the function throws the referenceError
			// exception.
			// Postcondition: the tree size decreases by 1

		void erase(iterator first, iterator last);
			// erase all items in the range [first, last).
			// Precondition: the tree is not empty. if the tree
			// is empty, the function throws the underflowError
			// exception.
			// Postcondition: the size of the tree decreases by
			// the number of elements in the range [first, last)

		iterator begin();
			// return an iterator pointing to the first item
			// inorder
		const_iterator begin() const;
			// constant version
		iterator end();
			// return an iterator pointing just past the end of
			// the tree data
		const_iterator end() const;
			// constant version

		void displayTree(int maxCharacters);
			// tree display function. maxCharacters is the
			// largest number of characters required to draw
			// the value of a node

	private:
		stnode<T> *root;
			// pointer to tree root
		int treeSize;
			// number of elements in the tree

		stnode<T> *getSTNode(const T& item,
									stnode<T> *lptr,stnode<T> *rptr, stnode<T> *pptr);
			// allocate a new tree node and return a pointer to it.
			// if memory allocation fails, the function throws
			// the mamoryAllocationError exception

		stnode<T> *copyTree(stnode<T> *t);
			// recursive function used by copy constructor and assignment
			// operator to assign the current tree as a copy of another tree

		void deleteTree(stnode<T> *t);
			// recursive function used by destructor and assignment
			// operator to delete all the nodes in the tree

		int distance (iterator first, iterator last);
			// counts the number of items in the range [first, last)
		int distance (const_iterator first, const_iterator last) const;
			// constant version

		tnodeShadow *buildShadowTree(stnode<T> *t, int level, int& column);
			// recursive function that builds a subtree of the shadow tree
			// corresponding to node t of the tree we are drawing. level is the
			// level-coordinate for the root of the subtree, and column is the
			// changing column-coordinate of the tree nodes

		void deleteShadowTree(tnodeShadow *t);
			// remove the shadow tree from memory after displayTree()
			// displays the binary search tree
};

template <typename T>
stnode<T> *mstree<T>::getSTNode(const T& item,
			stnode<T> *lptr,stnode<T> *rptr, stnode<T> *pptr)
{
	stnode<T> *newNode;

	// initialize the data and all pointers
	newNode = new stnode<T> (item, lptr, rptr, pptr);
	if (newNode == NULL)
		throw memoryAllocationError("mstree: memory allocation failure");

	return newNode;
}

template <typename T>
stnode<T> *mstree<T>::copyTree(stnode<T> *t)
{
	stnode<T> *newlptr, *newrptr, *newNode;

	// if tree branch NULL, return NULL
	if (t == NULL)
		return NULL;
  
	// copy the left branch of root t and assign its root to newlptr
	if (t->left != NULL)
		newlptr = copyTree(t->left);
	else
		newlptr = NULL;

	// copy the right branch of tree t and assign its root to newrptr
	if (t->right != NULL)
		newrptr = copyTree(t->right);
	else
		newrptr = NULL;

	// allocate storage for the current root node, assign
	// its value and pointers to its left and right subtrees.
	// the parent pointer of newNode is assigned when
	// newNode's parent is created. if newNode is root,
	// NULL is the correct value for its parent pointer
	newNode = getSTNode(t->nodeValue, newlptr, newrptr, NULL);

	// the current node is the parent of any subtree that
	// is not empty
	if (newlptr != NULL)
		newlptr->parent = newNode;
	if (newlptr != NULL)
		newrptr->parent = newNode;

	return newNode;
}

// delete the tree stored by the current object
template <typename T>
void mstree<T>::deleteTree(stnode<T> *t)
{
	// if current root node is not NULL, delete its left subtree,
	// its right subtree and then the node itself
	if (t != NULL)
	{
		deleteTree(t->left);
		deleteTree(t->right);
		delete t;
	}
}

template <typename T>
int mstree<T>::distance(iterator first, iterator last)
{
	// use to count the number of elements in the range
	int number = 0;

	// traverse the range and count
	while (first != last)
	{
		number++;
		first++;
	}

	return number;
}

template <typename T>
int mstree<T>::distance(const_iterator first, const_iterator last) const
{
	// use to count the number of elements in the range
	int number = 0;

	// traverse the range and count
	while (first != last)
	{
		number++;
		first++;
	}

	return number;
}

template <typename T>
mstree<T>::mstree(): root(NULL),treeSize(0)
{}

template <typename T>
mstree<T>::mstree(T *first, T *last): root(NULL),treeSize(0)
{
	T *p = first;

	// insert each item in [first, last) into the tree
	while (p != last)
	{
		insert(*p);
		p++;
	}
}

template <typename T>
mstree<T>::mstree(const mstree<T>& tree): treeSize(tree.treeSize)
{
	// copy tree to the current object
	root = copyTree(tree.root);
}

template <typename T>
mstree<T>::~mstree()
{
	// erase the tree nodes from memory
	deleteTree(root);

	// tree is emtpy
	root = NULL;
	treeSize = 0;
}

template <typename T>
mstree<T>& mstree<T>::operator= (const mstree<T>& rhs)
{
	// can't copy a tree to itself
	if (this == &rhs)
		return *this;

	// erase the existing tree nodes from memory
	deleteTree(root);

	// copy tree rhs into current object
	root = copyTree(rhs.root);

	// set the tree size
	treeSize = rhs.treeSize;

	// return reference to current object
	return *this;
}

template <typename T>
mstree<T>::iterator mstree<T>::find(const T& item)
{
	iterator i;

	// find first item in order whose value is >= item or end()
	// if all items are < item
	i = lower_bound(item);

	// item is not in the tree if i == end() or i
	// points at a value larger than item
	if (i == end() || item < *i)
		return end();
	else
		// i points at item
		return i;
}

template <typename T>
mstree<T>::const_iterator mstree<T>::find(const T& item) const
{
	const_iterator i;

	// find first item in order whose value is >= item or end()
	// if all items are < item
	i = lower_bound(item);

	// item is not in the tree if i == end() or i
	// points at a value larger than item
	if (i == end() || item < *i)
		return end();
	else
		// i points at item
		return i;
}

template <typename T>
int mstree<T>::empty() const
{
	return root == NULL;
}

template <typename T>
int mstree<T>::size() const
{
	return treeSize;
}

template <typename T>
mstree<T >::iterator mstree<T>::lower_bound(const T& item)
{
	// parent will point to the lower bound
	stnode<T> *parent = NULL;
	stnode<T> *curr = root;

	// cycle until we find an empty subtree
	while (curr != NULL)
		if (!(curr->nodeValue < item))
		{
			// item <= curr->nodeValue. record curr
			// as a possible lower bound and move
			// to the left to look for an even
			// smaller one
			parent = curr;
			curr = curr->left;
		}
		else
			// keep the current parent and move right
			curr = curr->right;

	return iterator(parent, this);
}

template <typename T>
mstree<T >::const_iterator mstree<T>::lower_bound(const T& item) const
{
	// parent will point to the lower bound
	stnode<T> *parent = NULL;
	stnode<T> *curr = root;

	// cycle until we find an empty subtree
	while (curr != NULL)
		if (!(curr->nodeValue < item))
		{
			// item <= curr->nodeValue. record curr
			// as a possible lower bound and move
			// to the left to look for an even
			// smaller one
			parent = curr;
			curr = curr->left;
		}
		else
			// keep the current parent and move right
			curr = curr->right;

	return const_iterator(parent, this);
}

template <typename T>
mstree<T >::iterator mstree<T>::upper_bound(const T& item)
{
	// parent will contain the upper bound when the function
	// returns
	stnode<T> *parent = NULL;
	stnode<T> *curr = root;

	// cycle until we find an empty subtree
	while (curr != NULL)
		if (item < curr->nodeValue)
		{
			// record curr as a possible upper bound and
			// move to the left to look for an even
			// smaller one
			parent = curr;
			curr = curr->left;
		}
		else
			// keep the current parent and move right
			curr = curr->right;

	return iterator(parent, this);
}

template <typename T>
mstree<T >::const_iterator mstree<T>::upper_bound(const T& item) const
{
	// parent will contain the upper bound when the function
	// returns
	stnode<T> *parent = NULL;
	stnode<T> *curr = root;

	// cycle until we find an empty subtree
	while (curr != NULL)
		if (item < curr->nodeValue)
		{
			// record curr as a possible upper bound and
			// move to the left to look for an even
			// smaller one
			parent = curr;
			curr = curr->left;
		}
		else
			// keep the current parent and move right
			curr = curr->right;

	return const_iterator(parent, this);
}

template <typename T>
pair<mstree<T>::iterator, mstree<T>::iterator>
mstree<T>::equal_range(const T& item)
{
	return pair<iterator,iterator>
		(lower_bound(item), upper_bound(item));
}

template <typename T>
pair<mstree<T>::const_iterator, mstree<T>::const_iterator>
mstree<T>::equal_range(const T& item) const
{
	return pair<const_iterator,const_iterator>
		(lower_bound(item), upper_bound(item));
}

template <typename T>
int mstree<T>::count(const T& item) const
{
	pair<const_iterator, const_iterator> p;

	p = equal_range(item);
	return distance(p.first, p.second);
}

template <typename T>
mstree<T>::iterator mstree<T>::insert(const T& item)
{
	// t is current node in traversal, parent the previous node
	stnode<T> *t = root, *parent = NULL, *newNode;

	// terminate on on empty subtree
	while(t != NULL)
	{
		// update the parent pointer. then go left or right
		parent = t;
		if (item < t->nodeValue)
			t = t->left;
		else 
			t = t->right;
	}
    
	// create the new leaf node
	newNode = getSTNode(item,NULL,NULL,parent);

	// if parent is NULL, insert as root node
	if (parent == NULL)
		root = newNode;
	else if (item < parent->nodeValue)                   
		// insert as left child        
		parent->left = newNode;  
	else
		// insert as right child     
		parent->right = newNode;
  
	// increment size
	treeSize++;

	// return an iterator that points at the new node
	return iterator(newNode, this);
}

template <typename T>
int mstree<T>::erase(const T& item)
{
	pair<iterator,iterator> p;
	int number;

	// find the range for occurrences of item
	p = equal_range(item);
	// find the number of occurrences of item
	number = distance(p.first, p.second);

	// erase all values in the range
	erase(p.first, p.second);

	// return the number erased
	return number;
}

template <typename T>
void mstree<T>::erase(iterator pos)
{
	// dNodePtr = pointer to node D that is deleted
	// pNodePtr = pointer to parent P of node D
	// rNodePtr = pointer to node R that replaces D
	stnode<T> *dNodePtr = pos.nodePtr, *pNodePtr, *rNodePtr;

	if (dNodePtr == NULL)
 		throw
			underflowError("mstree erase(): tree is empty");

	// assign pNodePtr the address of P
	pNodePtr = dNodePtr->parent;

	// If D has a NULL pointer, the
	// replacement node is the other child
	if (dNodePtr->right == NULL)
	{
		rNodePtr = dNodePtr->left;
		if (rNodePtr != NULL)
			// the parent of R is now the parent of D
			rNodePtr->parent = pNodePtr;
	}
	else if (dNodePtr->left == NULL)
	{
		rNodePtr = dNodePtr->right;
		if (rNodePtr != NULL)
			// the parent of R is now the parent of D
			rNodePtr->parent = pNodePtr;
	}  
	// both pointers of dNodePtr are non-NULL.
	else
	{
		// find and unlink replacement node for D.
		// starting at the right child of node D,
		// find the node whose value is the smallest of all
		// nodes whose values are greater than the value in D.
		// unlink the node from the tree.
  
		// pOfRNodePtr = pointer to parent of replacement node
		stnode<T> *pOfRNodePtr = dNodePtr;

		// first possible replacement is right child of D
		rNodePtr = dNodePtr->right;

		// descend down left subtree of the right child of D,
		// keeping a record of current node and its parent.
		// when we stop, we have found the replacement
		while(rNodePtr->left != NULL)
		{
			pOfRNodePtr = rNodePtr;
			rNodePtr = rNodePtr->left;
		}
  
		if (pOfRNodePtr == dNodePtr)
		{
			// right child of deleted node is the replacement.
			// assign left subtree of D to left subtree of R
			rNodePtr->left = dNodePtr->left;
			// assign the parent of D as the parent of R
			rNodePtr->parent = pNodePtr;
			// assign the left child of D to have parent R
			dNodePtr->left->parent = rNodePtr;
		}
		else
		{
			// we moved at least one node down a left branch
			// of the right child of D. unlink R from tree by
			// assigning its right subtree as the left child of
			// the parent of R
			pOfRNodePtr->left = rNodePtr->right;

			// the parent of the right child of R is the
			// parent of R
			if (rNodePtr->right != NULL)
				rNodePtr->right->parent = pOfRNodePtr;

			// put replacement node in place of dNodePtr
			// assign children of R to be those of D
			rNodePtr->left = dNodePtr->left;
			rNodePtr->right = dNodePtr->right;
			// assign the parent of R to be the parent of D
			rNodePtr->parent = pNodePtr;
			// assign the parent pointer in the children
			// of R to point at R
			rNodePtr->left->parent = rNodePtr;
			rNodePtr->right->parent = rNodePtr;
		}
	}

	// complete the link to the parent node.

	// deleting the root node. assign new root
	if (pNodePtr == NULL)
		root = rNodePtr;
	// attach R to the correct branch of P
	else if (dNodePtr->nodeValue < pNodePtr->nodeValue)
		pNodePtr->left = rNodePtr;
	else
		pNodePtr->right = rNodePtr;
  
	// delete the node from memory and decrement list size
	delete dNodePtr;
	treeSize--;
}

template <typename T>
void mstree<T>::erase(iterator first, iterator last)
{
	iterator p = first;

	if (first == begin() && last == end())
	{
		// we are asked to erase the entire tree.
		// erase the tree nodes from memory
		deleteTree(root);

		// tree is emtpy
		root = NULL;
		treeSize = 0;
	}
	else
		// erase each item in a subrange of the tree
		while (p != last)
			erase(p++);
}

template <typename T>
mstree<T>::iterator mstree<T>::begin()
{
	stnode<T> *curr = root;

	// if the tree is not empty, the first node
	// inorder is the farthest node left from root
	if (curr != NULL)
		while (curr->left != NULL)
			curr = curr->left;

	// build return value using private constructor
	return iterator(curr, this);
}

template <typename T>
mstree<T>::const_iterator mstree<T>::begin() const
{
	const stnode<T> *curr = root;

	// if the tree is not empty, the first node
	// inorder is the farthest node left from root
	if (curr != NULL)
		while (curr->left != NULL)
			curr = curr->left;

	// build return value using private constructor
	return const_iterator(curr, this);
}

template <typename T>
mstree<T>::iterator mstree<T>::end()
{
	// end indicated by an iterator with NULL stnode pointer
	return iterator(NULL, this);
}

template <typename T>
mstree<T>::const_iterator mstree<T>::end() const
{
	// end indicated by an iterator with NULL stnode pointer
	return const_iterator(NULL, this);
}

// recursive inorder scan used to build the shadow tree
template <typename T>
tnodeShadow *mstree<T>::buildShadowTree(stnode<T> *t, int level, int& column)
{
	// pointer to new shadow tree node
	tnodeShadow *newNode = NULL;
	// text and ostr used to perform format conversion
	char text[80];
	ostrstream ostr(text,80);

	if (t != NULL)
	{
		// create the new shadow tree node
		newNode = new tnodeShadow;

		// allocate node for left child at next level in tree; attach node
		tnodeShadow *newLeft = buildShadowTree(t->left, level+1, column);
		newNode->left = newLeft;

		// initialize data members of the new node
		ostr << t->nodeValue << ends;	// format conversion
		newNode->nodeValueStr = text;
		newNode->level = level;
		newNode->column = column;

		// update column to next cell in the table
		column++;

		// allocate node for right child at next level in tree; attach node
		tnodeShadow *newRight = buildShadowTree(t->right, level+1, column);
		newNode->right = newRight;
	}

	return newNode;
}

template <typename T>
void mstree<T>::displayTree(int maxCharacters)
{
	string label;
	int level = 0, column = 0;
	int colWidth = maxCharacters + 1;
	// 
	int currLevel = 0, currCol = 0;

	if (treeSize == 0)
		return;

	// build the shadow tree
	tnodeShadow *shadowRoot = buildShadowTree(root, level, column);

	// use during the level order scan of the shadow tree
	tnodeShadow *currNode;

   // store siblings of each tnodeShadow object in a queue so that
	// they are visited in order at the next level of the tree
   queue<tnodeShadow *> q;

   // insert the root in the queue and set current level to 0
   q.push(shadowRoot);
   
   // continue the iterative process until the queue is empty
   while(!q.empty())
   {
      // delete front node from queue and make it the current node
      currNode = q.front();
		q.pop();

		// if level changes, output a newline
		if (currNode->level > currLevel)
		{
			currLevel = currNode->level;
			currCol = 0;
			cout << endl;
		}

		// if a left child exists, insert the child in the queue
      if(currNode->left != NULL)
			q.push(currNode->left);

		// if a right child exists, insert the child in the queue
      if(currNode->right != NULL)
			q.push(currNode->right);

		// output formatted node label
		if (currNode->column > currCol)
		{
			cout << setw((currNode->column-currCol)*colWidth) << " ";
			currCol = currNode->column;
		}
		cout << setw(colWidth) << currNode->nodeValueStr;
		currCol++;
   }
	cout << endl;

	// delete the shadow tree
	deleteShadowTree(shadowRoot);
}

template <typename T>
void mstree<T>::deleteShadowTree(tnodeShadow *t)
{
	// if current root node is not NULL, delete its left subtree,
	// its right subtree and then the node itself
	if (t != NULL)
	{
		deleteShadowTree(t->left);
		deleteShadowTree(t->right);
		delete t;
	}
}

#endif  // BINARY_SEARCH_TREE_CLASS
