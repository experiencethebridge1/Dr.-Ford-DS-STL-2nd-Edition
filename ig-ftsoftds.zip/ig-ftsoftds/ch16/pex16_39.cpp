#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>

#include "d_graph.h"
#include "d_util.h"	// for writeContainer()

using namespace std;

int main()
{
	// vertices are characters
	graph<char> g;
	vector<set<char> > component;
	ifstream graphIn;
	int i;

	graphIn.open("wex16-22.dat");

	graphIn >> g;

	// see if the graph is acyclic
	if (acyclic(g))
	{
		// graph has no cycles. reverse the direction of two edges and
		// see if the new graph is strongly connected
		cout << "The graph does not have a cycle." << endl
			  << "Reversing the direction of edges D-C and F-D"
			  << endl;

		// delete edges D-C and D-F
		g.eraseEdge('D', 'C');
		g.eraseEdge('D', 'F');
		// insert edges C-D and F-D
		g.insertEdge('C', 'D', 1);
		g.insertEdge('F', 'D', 1);

		// compute and output the strong components
		strongComponents(g, component);

		cout << "The strong components are: ";
		for (i=0;i < component.size();i++)
		{
			writeContainer(component[i].begin(), component[i].end());
			cout << endl;
		}

		// the graph is strongly connected if it has only 1 strong component
		if (component.size() == 1)
			cout << "The graph is strongly connected" << endl;
	}
	else
		// the original graph has a cycle
		cout << "The graph has a cycle" << endl;


	return 0;
}


/*
Run:

The graph does not have a cycle.
Reversing the direction of edges D-C and F-D
The strong components are: A  B  C  D  E  F  G
The graph is strongly connected
*/
