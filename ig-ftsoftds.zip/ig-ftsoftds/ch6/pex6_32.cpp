#include <iostream>
#include <list>

#include "d_util.h"
#include "d_random.h"

using namespace std;

// assume mList.size() >= lList.size(). merge pair-wise to produce
// the new list nList
void mergePairWise(const list<int>& lList, const list<int>& mList,
						 list<int>& nList);

int main()
{
	list<int> lList, mList, nList;
	int i, j, k;
	randomNumber rnd;

	cout << "Enter numbers 1 <= i <= 5 and 1 <= j <= 10"
		  << endl << "Be certain that j >= i: ";
	cin >> i >> j;

	// initialize lList with i random integers in the range
	// from 0 to 99
	for (k=0;k < i;k++)
		lList.push_back(rnd.random(100));

	// initialize mList with j random integers in the range
	// from 100 to 199
	for (k=0;k < j;k++)
		mList.push_back(100 + rnd.random(100));

	cout << "The initial lists are:" << endl;
	writeList(lList);
	writeList(mList);

	// merge the lists and output the resulting list
	mergePairWise(lList, mList, nList);
	cout << endl << "The merged list is: ";
	writeList(nList, " ");

	return 0;
}

void mergePairWise(const list<int>& lList, const list<int>& mList,
						 list<int>& nList)
{
	// iterators that step through lList and mList
	list<int>::const_iterator lListIter = lList.begin(),
									  mListIter = mList.begin();

	// move through lList until arriving at its end
	while (lListIter != lList.end())
	{
		// push an element from lList and then mList onto the
		// back of nList
		nList.push_back(*lListIter++);
		nList.push_back(*mListIter++);
	}

	// copy any remaining elements in mList out to nList
	while (mListIter != mList.end())
		nList.push_back(*mListIter++);
}

/*
Run:

Enter numbers 1 <= i <= 5 and 1 <= j <= 10
Be certain that j >= i: 5 10
The initial lists are:
63  28  78  65  12
175  181  133  170  150  157  149  135  193  174

The merged list is: 63 175 28 181 78 133 65 170 12 150 157 149 135 193 174
*/
