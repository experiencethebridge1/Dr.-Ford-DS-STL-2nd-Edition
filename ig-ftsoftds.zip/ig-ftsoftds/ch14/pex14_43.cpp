#include <iostream>
#include <ctype.h>

#include "textfile.h"

using namespace std;

// for the n characters in s, translate each
// lowercase character to uppercase.
void upperCase(char *s, int n);

int main()
{
	// tfin for input and tfout for output
	textfile  tfin, tfout;
	// read up to 128 characters at a time
	char buffer[128];
	int nchars;

	// read from file "textfile.h"
	tfin.assign("textfile.h");
	tfin.reset();
	
	// write to file "textfile.uc"
	tfout.assign("textfile.uc");
	tfout.rewrite();

	// read "textfile.h", translate each lowercase
	// character to upper case and write the modified
	// characters to file "textfile.uc" 
	while(!tfin.endFile())
	{
		// read up to 128 characters from tfin. assign the number
		// actually read to nchars
		nchars = tfin.read(buffer,128);

		// translate each lowercase character in buffer
		// to upper case
		upperCase(buffer,nchars);

		// write nchars characters to tfout
		tfout.write(buffer,nchars);
	}
	
	// close the two files
	tfin.close();
	tfout.close();

	return 0;
}

void upperCase(char *s, int n)
{
	while(n--)
	{
		*s = toupper(*s);
		s++;
	}
}

/*
Run:

Listing of the output file "textfile.uc"

#IFNDEF TEXTFILE_CLASS
#DEFINE TEXTFILE_CLASS

#INCLUDE <IOSTREAM>
#INCLUDE <FSTREAM>
#INCLUDE <STRING>

#INCLUDE "D_EXCEPT.H"

USING NAMESPACE STD;

CLASS TEXTFILE
{
	PUBLIC:
		TEXTFILE();
			// CONSTRUCTOR
	...

VOID TEXTFILE::WRITE(CHAR ARR[], INT N)
{   
	IF (ACCESSTYPE == IN)
		THROW
			FILEERROR("TEXTFILE WRITE(): FILE IS OPEN FOR INPUT");
	ELSE IF (N < 0) 
		THROW
			FILEERROR("TEXTFILE WRITE(): INVALID CHARACTER COUNT");
   ELSE IF(!ISOPEN)
		THROW
			FILEERROR("TEXTFILE WRITE(): FILE IS CLOSED");

	// WRITE N BYTES TO F
	F.WRITE(ARR,N);
}

#ENDIF	// TEXTFILE_CLASS

*/
