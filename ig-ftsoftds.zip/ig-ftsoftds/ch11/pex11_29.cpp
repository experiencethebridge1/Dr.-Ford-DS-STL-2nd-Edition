#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <map>

#include "d_util.h"
#include "d_random.h"

using namespace std;

// construct a map whose key is an integer in the range from
// 0 to 9 and whose value is the number of times the integer
// occurs when numbers in the range are randomly generated n
// times
map<int,int> randMap(int n);

int main()
{
	// m is assigned the result of calling randMap()
	map<int,int> m;
	// use iterator to output the map
	map<int,int>::iterator iter;
	int n;

	cout << "Enter a number n: ";
	cin >> n;
	cout << endl;

	// form the map
	m = randMap(n);

	// output the results
	cout << "Results:" << endl;
	iter = m.begin();

	while (iter != m.end())
	{
		cout << (*iter).first << "  " << setw(8)
			  << (*iter).second << endl;
		iter++;
	}

	return 0;
}

map<int,int> randMap(int n)
{
	// map the function returns
	map<int,int> m;
	// use rnd to generate random integers
	randomNumber rnd;
	int i, rndInt;

	// generate n random integers in the range from 0 to 9
	for (i=0; i < n; i++)
	{
		rndInt = rnd.random(10);
		// either insert key rndInt into the map and increment
		// its default value from 0 to 1 or increment the existing
		// value of the key rndInt
		m[rndInt]++;
	}

	// return the map object
	return m;
}

/*
Run:

Enter a number n: 1000000

Results:
0    100117
1    100478
2     99348
3    100449
4     99839
5     99565
6    100578
7    100156
8     99933
9     99537
*/
