#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>

#include "d_setops.h"
#include "d_random.h"
#include "d_util.h"

using namespace std;

int main()
{
	set<int> setA, setB, setC;
	randomNumber rnd;
	int i;

	// assign setA the integer values 0 to 24, and assign
	// setB random integer values in the same range
	for (i=0;i < 25;i++)
	{
		setA.insert(i);
		setB.insert(rnd.random(25));
	}

	cout << "The size of setB = " << setB.size() << endl;

	// setC contains the numbers from 1 to 24 that were not randomly
	// generated
	setC = setA - setB;

	// output the results
	cout << "The integers from 0 to 24 that were not randomly generated:"
		  << endl;
	writeContainer(setC.begin(), setC.end());
	cout << endl;

	return 0;
}

/*
Run:

The size of setB = 16
The integers from 0 to 24 that were not randomly generated:
0  1  6  14  17  18  19  22  24
*/
