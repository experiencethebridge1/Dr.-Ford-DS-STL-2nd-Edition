#include <iostream>
#include <utility>		// for pair class
#include <vector>

#include "d_hash.h"		// hash class
#include "intv.h"			// integer class and hFinteger
#include "d_random.h"	// randomNumber class
#include "d_sort.h"		// insertionSort() algorithm

using namespace std;

// use rnd to simulate tossing n dice
int toss(int n, randomNumber& rnd);

int main()
{
	const int NUMBER_TOSSES = 1000000;
	// hash table of integer objects
	hash<integer, hFinteger> diceHash(17);
	// declare a hash table iterator
	hash<integer,hFinteger>::iterator iter;
	// use p to capture the return value of the hash class insert()
	pair<hash<integer,hFinteger>::iterator, bool> p;
	vector<integer> v;
	randomNumber rnd;
	int i;

	// toss 5 dice NUMBER_TOSSES times
	for (i=0;i < NUMBER_TOSSES;i++)
	{
		// attempt to insert a dice toss with count 1 into the hash table.
		// if insert() indicates that the toss is already in the table,
		// increase its count using ++
		p = diceHash.insert(integer(toss(5, rnd)));
		if (p.second == false)
			(*p.first)++;
	}

	// copy the hash table values to the vector v
	iter = diceHash.begin();
	while (iter != diceHash.end())
	{
		v.push_back(*iter);
		iter++;
	}

	// sort by toss total
	insertionSort(v);

	// ouput the dice toss results, 5 tosses per line
	for (i=0;i < v.size();i++)
		cout << v[i] << "  " << double(v[i].getCount())/NUMBER_TOSSES
			  << endl;
	cout << endl;

   return 0;
}

int toss(int n, randomNumber& rnd)
{
	int i, total = 0;

	for (i=0;i < n;i++)
		// 1 <= 1 + rnd.random(6) <= 6 is the total on the face
		// of a die
		total += 1 + rnd.random(6);

	return total;
}

/*
Run:

5(128)  0.000128
6(657)  0.000657
7(1906)  0.001906
8(4432)  0.004432
9(8992)  0.008992
10(16437)  0.016437
11(26257)  0.026257
12(38980)  0.03898
13(53883)  0.053883
14(69336)  0.069336
15(84088)  0.084088
16(94825)  0.094825
17(100466)  0.100466
18(100209)  0.100209
19(94574)  0.094574
20(83358)  0.083358
21(69919)  0.069919
22(54000)  0.054
23(39261)  0.039261
24(26284)  0.026284
25(15937)  0.015937
26(8947)  0.008947
27(4424)  0.004424
28(1947)  0.001947
29(634)  0.000634
30(119)  0.000119
*/
