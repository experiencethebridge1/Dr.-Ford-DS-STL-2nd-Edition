#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <string>

using namespace std;

// return the number vowels in the string
int numberVowels(const string& s);

int main()
{
	string word[] = {"Arizona", "walk", "government", "C++", "beach"};
	int wordSize = sizeof(word)/sizeof(string), i;

	for (i=0;i < wordSize;i++)
		cout << word[i] << ": " << numberVowels(word[i])
			  << " vowels" << endl;

	return 0;
}

int numberVowels(const string& s)
{
	int i, nvowels = 0;
	// put all the vowels in a string
	string vowels = "aAeEiIoOuU";

	// cycle through the characters of s
	for (i=0;i < s.length();i++)
		// see if s[i] is in vowels. if so, increment nvowels
		if (vowels.find_first_of(s[i],0) != -1)
			nvowels++;

	return nvowels;
}

/*
Run:

Arizona: 4 vowels
walk: 1 vowels
government: 3 vowels
C++: 0 vowels
beach: 2 vowels
*/
