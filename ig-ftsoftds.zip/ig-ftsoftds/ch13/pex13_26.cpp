#include <iostream>

#include "textbook.h"

using namespace std;

int main()
{
	book bk1(HardCover, 250), *bk2 = new textbook(SoftCover, 360, "History");
	textbook econ101(HardCover, 725, "Economics");

	// call the base class function descibe() for bk1, *bk2, and econ101
	bk1.describe();
	bk2->book::describe();
	econ101.book::describe();
	cout << endl;

	// call the derived class function describe() for *bk2 and econ101
	bk2->describe();
	econ101.describe();

	return 0;
}

/*
Run:

A 250 page hard covered book
A 360 page soft covered book
A 725 page hard covered book

A 360 page soft covered book
Used for courses in History
A 725 page hard covered book
Used for courses in Economics
*/
