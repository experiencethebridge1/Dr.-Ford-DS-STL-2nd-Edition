#include <iostream>

#include "d_node.h"
#include "d_nodel.h"

using namespace std;

// copy a linked list and return a pointer to the front of the new list
template <typename T>
node<T> *copy(node<T> *front);

int main()
{
	double arr[] = {5.5,  6.7,  15.3,  3.14,  2.718,  15.3,  3.5};
	int arrSize = sizeof(arr)/sizeof(double);
	// list initially empty
	node<double> *frontOrig = NULL, *frontCopy;
	int i;

	// insert each value arr[arrSize-1], ..., arr[1], arr[0] at the
	// front of the linked list
	for (i=arrSize-1;i >= 0;i--)
		frontOrig = new node<double> (arr[i],frontOrig);

	// copy frontOrig and assign its front pointer to frontCopy
	frontCopy = copy(frontOrig);

	// output the lists
	cout << "Original list:" << endl;
	writeLinkedList(frontOrig);
	cout << endl << endl;
	cout << "Copy:" << endl;
	writeLinkedList(frontCopy);
	cout << endl;

	return 0;
}

template <typename T>
node<T> *copy(node<T> *front)
{
	// sourceCurr moves through the source list (front), copyFront
	// is the pointer to the front of the copy, and copyCurr is
	// used to build the copy
	node<T> *sourceCurr, *copyFront, *copyCurr;

	// if source list is empty, return NULL
	if (front == NULL)
		return NULL;

	// create the node at the front of the copy, and set copyFront
	// to its address
	copyFront = new node<T> (front->nodeValue,NULL);
	// start copyCurr at copyFront
	copyCurr = copyFront;
	// move sourceCurr to 2nd node of the source list
	sourceCurr = front->next;

	// copy until sourceCurr arrives at the end of the source list
	while (sourceCurr != NULL)
	{
		// build the next node and link it into copyCurr
		copyCurr->next = new node<T> (sourceCurr->nodeValue, NULL);
		// move copyCurr to the new node
		copyCurr = copyCurr->next;
		// advance the source pointer
		sourceCurr = sourceCurr->next;
	}

	return copyFront;
}

/*
Run:

Original list:
5.5 6.7 15.3 3.14 2.718 15.3 3.5

Copy:
5.5 6.7 15.3 3.14 2.718 15.3 3.5
*/
