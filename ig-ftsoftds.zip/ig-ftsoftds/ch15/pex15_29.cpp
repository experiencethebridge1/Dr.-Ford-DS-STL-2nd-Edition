#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <string>

using namespace std;

// output all interleavings of the characters in s and t.
// i is the current position in s, and j is the current
// position in t. ci is the interleaving
void interleavings(const string& s, int i,
						 const string& t, int j, string& ci);

int main()
{
	string s, t, ci = "";

	cout << "Enter the string s: ";
	cin >> s;

	cout << "Enter the string t: ";
	cin >> t;
	cout << endl;

	cout << "The interleavings are:" << endl << endl;

	interleavings(s,0,t,0,ci);

	return 0;
}


void interleavings(const string& s, int i,
						 const string& t, int j, string& ci)
{
	int tmp;

	if (i == s.length()) // have we arrived at the end of s?
	{
		ci += t.substr(j);
		cout << ci << endl;
	}
	else if (j == t.length()) // have we arrived at the end of t?
	{
		ci += s.substr(i);
		cout << ci << endl;
	}
	else
	// recursive step
	{
		// record the current length of ci
		tmp = ci.length();

		// concatenate s[i] onto the end of interleaving ci
		ci += s[i];
		interleavings(s,i+1,t,j,ci); // interleave

		// concatenate t[j] onto the end of interleaving ci in its
		// state before the recursive call
		ci.erase(tmp);
		ci += t[j];
		interleavings(s,i,t,j+1,ci); // interleave
	}
}
/*
Run:

Enter the string s: abc
Enter the string t: 12

The interleavings are:

abc12
ab1c2
ab12c
a1bc2
a1b2c
a12bc
1abc2
1ab2c
1a2bc
12abc
*/
