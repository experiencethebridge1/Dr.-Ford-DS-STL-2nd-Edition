#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

// find a subset of the positive integers v[index], v[index+1], ...,
// v[v.size()-1] that sums to total > 0. if subset[i] == true,
// v[i] is in the sum, 0 <= i < v.size()
bool subsetsum(const vector<int>& v, vector<bool>& subset,
					int total, int index);

int main()
{
	int arr[] = {6,26,3,15,12,8,5,18,6,25};
	int arrSize = sizeof(arr)/sizeof(int);
	vector<int> v(arr,arr+arrSize);
	vector<bool> subset(arrSize);
	int i, j;

	// try to form all sums 1 to 50 from arr
	for (i=1;i <= 50;i++)
	{
		// output the number we are trying to obtain
		cout << "i = " << setw(2) << i << ": ";

		// make all entries of subset false
		for(j=0;j < arrSize;j++)
			subset[j] = false;

		// does a subset of arr[0] to arr[9] sum to i?
		if (subsetsum(v,subset,i,0))
		{
			// yes! output the subset
			for(j=0;j < 10;j++)
				if (subset[j])
					cout << setw(4) << v[j];
			cout << endl;
		}
		else
			cout << "(none)" << endl;
	}

	return 0;
}

bool subsetsum(const vector<int>& v, vector<bool>& subset,
					int total, int index)
{
	bool result;

	if (total == 0)
		result = true;		// success

	else if (index >= v.size() || total < 0)
		return false;		// failure

	else
	{
		// try using the current number, v[index]
		subset[index] = true;
		if (subsetsum(v, subset, total-v[index], index+1) == false)
		{
			// do not use the current number after all
			subset[index] = false;
			result = subsetsum(v, subset, total, index+1);
		}
		else
			result = true;
	}

	return result;
}

/*
Run:

i =  1: (none)
i =  2: (none)
i =  3:    3
i =  4: (none)
i =  5:    5
i =  6:    6
i =  7: (none)
i =  8:    3   5
i =  9:    6   3
i = 10: (none)
i = 11:    6   5
i = 12:    6   6
i = 13:    8   5
i = 14:    6   3   5
i = 15:    6   3   6
i = 16:    3   8   5
i = 17:    6   3   8
i = 18:    6  12
i = 19:    6   8   5
i = 20:    6   3   5   6
i = 21:    6   3  12
i = 22:    6   3   8   5
i = 23:    6   3   8   6
i = 24:    6   3  15
i = 25:    6   8   5   6
i = 26:    6   3  12   5
i = 27:    6   3  12   6
i = 28:    6   3   8   5   6
i = 29:    6   3  15   5
i = 30:    6   3  15   6
i = 31:    6  12   8   5
i = 32:    6  26
i = 33:    6   3  18   6
i = 34:    6   3  12   8   5
i = 35:    6  26   3
i = 36:    6   3  15  12
i = 37:    6  26   5
i = 38:    6  26   6
i = 39:    6   3  12  18
i = 40:    6  26   3   5
i = 41:    6  26   3   6
i = 42:    6   3  15  12   6
i = 43:    6  26   3   8
i = 44:    6  26  12
i = 45:    6  26   8   5
i = 46:    6  26   3   5   6
i = 47:    6  26   3  12
i = 48:    6  26   3   8   5
i = 49:    6  26   3   8   6
i = 50:    6  26   3  15
*/
