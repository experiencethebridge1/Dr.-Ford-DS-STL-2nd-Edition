#include <iostream>

#include "mat.h"

using namespace std;

// input mat by rows from the keyboard
template <typename T>
void inputMatrix(matrix<T>& mat);

// output mat by rows
template <typename T>
void outputMatrix(const matrix<T>& mat);

int main()
{
	// declare the matrices
	matrix<int> matrixA(3,3), matrixB(3,3), sum(3,3), diff(3,3);

	cout << "Enter the " << matrixA.rows() << " x "
		  << matrixA.cols() << " matrixA by rows:" << endl;

	inputMatrix(matrixA);
	cout << endl;

	cout << "Enter the " << matrixB.rows() << " x "
		  << matrixB.cols() << " matrixB by rows:" << endl;

	inputMatrix(matrixB);
	cout << endl;

	// compute the sum and difference of matrixA and matrixB
	sum = matrixA + matrixB;
	diff = matrixA - matrixB;

	// display the results
	cout << "matrixA + matrixB = " << endl;
	outputMatrix(sum);
	cout << endl;

	cout << "matrixA - matrixB = " << endl;
	outputMatrix(diff);

	return 0;
}

template <typename T>
void inputMatrix(matrix<T>& mat)
{
	int i,j;

	// input row 0, row 1, ..., row mat.rows()-1
	for (i=0;i < mat.rows();i++)
		// input an element from each column of row i
		for (j=0;j < mat.cols();j++)
			cin >> mat[i][j];
}

template <typename T>
void outputMatrix(const matrix<T>& mat)
{
	int i,j;

	// output row 0, row 1, ..., row mat.rows()-1
	for (i=0;i < mat.rows();i++)
	{
		// output an element from each column of row i
		for (j=0;j < mat.cols();j++)
			cout << mat[i][j] << "  ";
		// output newline between rows
		cout << endl;
	}
}

/*
Run:

Enter the 3 x 3 matrixA by rows:
1 2 3
4 5 6
7 8 9

Enter the 3 x 3 matrixB by rows:
0 0 0
1 1 1
2 2 2

matrixA + matrixB =
1  2  3
5  6  7
9  10  11

matrixA - matrixB =
1  2  3
3  4  5
5  6  7
*/
