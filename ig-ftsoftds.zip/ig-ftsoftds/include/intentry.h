#ifdef __BORLANDC__
// suppress the warning message that functions containing for
// are not expanded inline
#pragma warn -8027
#endif	// __BORLANDC__

#ifndef INTENTRY_CLASS
#define INTENTRY_CLASS

#include <iostream>

using namespace std;

class intEntry
{
	public:
		// initialize the integer value and its count
		intEntry(int v, int c = 1): value(v), count(c)
		{}

		// return value
		int getValue() const
		{ return value; }

		// return count
		int getCount() const
		{ return count; }

		// increment count
		void increment()
		{ count++; }

		// compare lhs and rhs using value
		friend bool operator< (const intEntry& lhs,
									  const intEntry& rhs)
		{	return lhs.value < rhs.value; }

		friend bool operator== (const intEntry& lhs,
									 	const intEntry& rhs)
		{	return lhs.value == rhs.value; }

		// output obj in format "value value ... value" (count times)
		friend ostream& operator<< (ostream& ostr, const intEntry& obj)
		{
			int i;

			for (i=0;i < obj.count;i++)
				ostr << obj.value << " ";

			return ostr;
		}

	private:
		int value;
			// integer value
		int count;
			// number of occurrences of value
};

#endif	// INTENTRY_CLASS
