#ifndef SQUARE_CLASS
#define SQUARE_CLASS

#include "d_rect.h"	// rectangle base class

class square: public rectangle
{
	public:
		// constructor. initialize the base class
		square(double side = 0.0): rectangle(side,side)
		{}

		// return the side of the square
		double getSide()
		{
			// base class function getLength() returns the length
			// of each side
			return getLength();
		}

		void setSide(double side)
		{
			// base class function setSides() sets the sides of
			// the square
			setSides(side,side);
		}
};

#endif	// SQUARE_CLASS
