#include <iostream>

#include "xrect.h"

using namespace std;

int main()
{
	double s;

	cout << "Enter the length of a side for the clear glass: ";
	cin >> s;

	// clear glass is s x s square
	rectangle innerSq(s,s);
	// compute the diagonal of the square, which is the length
	// of the frame sides
	double lengthFrame = innerSq.diagonal();
	// declare the frame
	rectangle frame(lengthFrame,lengthFrame);
	double clearGlassCost, stainedGlassCost;

	// clear glass cost = area of inner square * $.40
	clearGlassCost = innerSq.area() * .40;
	// clear glass cost = area outside inner square and inside frame * $.75
	stainedGlassCost = (frame.area() - innerSq.area()) * .75;
	cout << "The cost of the window is $"
		  << clearGlassCost + stainedGlassCost << endl;

	return 0;
}

/*
Run:

Enter the length of a side for the clear glass: 5
The cost of the window is $28.75
*/
