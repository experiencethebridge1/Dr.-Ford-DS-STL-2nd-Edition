#ifndef GENVECTOR_CLASS
#define GENVECTOR_CLASS

#include <vector>

#include "d_except.h"

using namespace std;

template <typename T>
class genVector: public vector<T>
{
	public:
		genVector(int low, int high);	
			// vector has high-low+1 elements in range [low,high]
	
	T& operator[] (int i);
		// operator verifies that lower <= i <= upper.
		// if not, it throws the indexRangeError exception

	void resize(int lowIndex, int highIndex);
		// resize vector and set range to [lowIndex, highIndex]

	private:
		int lower;
		int upper;
};


// constructor. initialize base class vector
// to have high-low+1 elements. initialize
// lower and upper.
template <class T>
genVector<T>::genVector(int low, int high):
	vector<T>(high-low+1), lower(low), upper(high)
{}

template <class T>
T& genVector<T>::operator[] (int i)
{
	// verify that i is in range
	//    lower <= i <= upper
	if ( i < lower || i > upper)
		throw indexRangeError("genVector: index range error", i, size());

	// call the base class index operator
	// using this syntax
	return vector<T>::operator[] (i-lower);
}

template <class T>
void genVector<T>::resize(int lowIndex, int highIndex)
{
	// use base class function resize()
	vector<T>::resize(highIndex-lowIndex+1);

	// set new upper index
	lower = lowIndex;
	upper = highIndex;
}

#endif	// GENVECTOR_CLASS
