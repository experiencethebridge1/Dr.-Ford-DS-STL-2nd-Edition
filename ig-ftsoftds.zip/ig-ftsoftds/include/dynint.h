#ifndef DYNAMICINT_CLASS
#define DYNAMICINT_CLASS

#include <iostream>

#include "d_except.h"

using namespace std;

class dynamicInt
{
	public:
		dynamicInt(int m = 0);
			// constructor

      ~dynamicInt();
			// destructor

		dynamicInt(const dynamicInt& obj);
			// copy constructor

		dynamicInt& operator= (const dynamicInt& rhs);
			// assignment operator

		int getData()const;
			// return value of dynamic member

		friend ostream& operator<< (ostream& ostr, 
												const dynamicInt& obj);
			// output stream operator << as a friend function

	private:
		int *ptr;
			// dynamic data member

};

dynamicInt::dynamicInt(int m)
{
	ptr = new int(m);

	if (ptr == NULL)
		throw memoryAllocationError("dynamicInt: out of memory");
}

dynamicInt::~dynamicInt()
{
	delete ptr;
}

dynamicInt::dynamicInt(const dynamicInt& obj)
{	
	ptr = new int(*obj.ptr);

	if (ptr == NULL)
		throw memoryAllocationError("dynamicInt: out of memory");
}

dynamicInt& dynamicInt::operator= (const dynamicInt& rhs)
{
	*ptr = *rhs.ptr;

	return *this;
}

int dynamicInt::getData()const
{
	return *ptr;
}

ostream& operator<< (ostream& ostr, const dynamicInt& obj)
{
	ostr << *obj.ptr;
	return ostr;
}

#endif	// DYNAMICINT_CLASS
