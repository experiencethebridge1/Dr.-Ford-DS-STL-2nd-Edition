#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <vector>

#include "d_random.h"
#include "d_util.h"

using namespace std;

// use the sequential search to locate target in the index range
// [first, last). return the index of the first occurrence of
// target or last if target is not found
template <typename T>
int seqSearch(const vector<T>& v, int first, int last, const T& target);

// remove the duplicate values from v
template <typename T>
void removeDup(vector<T>& v);

// remove the duplicate values from v. uses seqSearch()
template <typename T>
void removeDup2(vector<T>& v);

int main()
{
	vector<int> v, savev;
	int n, i, j;
	// random number generator
	randomNumber rnd;

	// prompt for n
	cout << "Enter n: ";
	cin >> n;

	// initialize v with n random integers in the range from 0 to 9
	for (i=0;i < n;i++)
		v.push_back(rnd.random(10));

	// output the vector
	cout << "Vector values: ";
	writeVector(v);
	cout << endl;

	// make a copy of v
	savev = v;

	// replace duplicate values by -1
	for (i=0;i < v.size();i++)
		// replace each duplicate of v[i] in [i+1,v.size()) by -1
		for (j=i+1;j < v.size();j++)
			// skip v[j] if it has value -1 and mark v[j] by -1 if
			// it is a duplicate of v[i]
			if (v[j] != -1 && v[j] == v[i])
				v[j] = -1;

	// output all the elements of v not equal to -1
	cout << "Nonduplicate values (method 1): ";
	for (i=0;i < v.size();i++)
		if (v[i] != -1)
			cout << v[i] << "  ";
	cout << endl;

	// restore v
	v = savev;
	// remove duplicates and output the revised vector
	removeDup(v);
	cout << "Nonduplicate values (method 2): ";
	writeVector(v);

	// restore v
	v = savev;
	// remove duplicates and output the revised vector
	removeDup2(v);
	cout << "Nonduplicate values (method 3): ";
	writeVector(v);

   return 0;
}

template <typename T>
int seqSearch(const vector<T>& v, int first, int last, const T& target)
{
	int i;

   // scan indices in the range first <= i < last
	for(i=first; i < last; i++)
		if (v[i] == target)		// assume T has the "==" operator
			return i;				// immediately return on a match

	return last;					// otherwise return last
}

template <typename T>
void removeDup(vector<T>& v)
{
	int i, j, k, n = v.size() ;

	// just return if v is empty
	if (n == 0)
		return;

	// i moves from indices 1 through n-1.
	// j is the index for the next unique value
	i = j = 1;

	while (i < n)
	{
		// search the range [0, j) for v[i]
		k = 0;
		while (k <j)
		{
			// break if locate v[i] in the range. we have a
			// duplicate value
			if (v[k] == v[i])
				break;
			k++;
		}
		// k == j means we did not break, so v[i] is not
		// in [0,j). copy v[i] to v[j] and increment j
		if (k == j)
		{
			v[j] = v[i];
			j++;
		}

		i++;
	}

	v.resize(j);
}

template <typename T>
void removeDup2(vector<T>& v)
{
	int i, j, n = v.size() ;

	// just return if v is empty
	if (n == 0)
		return;

	// i moves from indices 1 through n-1.
	// j is the index for the next unique value
	i = j = 1;

	while (i < n)
	{
		// search the range [0, j) for v[i]. if v[i] is not
		// in [0,j), copy v[i] to v[j] and increment j
		if (seqSearch(v,0,j,v[i]) == j)
		{
			v[j] = v[i];
			j++;
		}

		i++;
	}

	v.resize(j);
}

/*
Run:

Enter n: 10
Vector values: 3  1  1  8  5  1  4  3  3  2

Nonduplicate values (method 1): 3  1  8  5  4  2
Nonduplicate values (method 2): 3  1  8  5  4  2
Nonduplicate values (method 3): 3  1  8  5  4  2
*/
