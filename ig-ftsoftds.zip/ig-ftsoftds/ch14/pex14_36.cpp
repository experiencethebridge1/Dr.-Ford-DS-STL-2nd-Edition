#include <iostream>
#include <functional>

#include "d_util.h"
#include "d_random.h"

using namespace std;

// recursive function that filters v[first] down the heap
// with index range [first, last)
template <typename T, typename Compare>
void adjustHeapRec(vector<T>& v, int first, int last, Compare comp);

// the vector elements in the range [0, last) are a heap.
// swap the first and last elements of the heap and then
// apply adjustHeapRec() to make the elements in the index
// range [0, last-1) a heap.
template <typename T, typename Compare>
void popHeapRec(vector<T>& v, int last, Compare comp);

// arrange the vector elements into a heap. use the function
// adjustHeapRec() for the filter down operations
template <typename T, typename Compare>
void makeHeapRec(vector<T>& v, Compare comp);

int main ()
{
	vector<int> v;
	int i, last;
	randomNumber rnd;

	// initialize v with 10 random integers in the
	// range from 0 to 99
	for (i=0;i < 10;i++)
		v.push_back(rnd.random(100));

	cout << "Initial vector: ";
	writeVector(v);
	cout << endl;

	// heapify v
	makeHeapRec(v, greater<int>());

	cout << "Vector after heapification: ";
	writeVector(v);
	cout << endl;

	// pop the heap until it is empty
	last = v.size();
	while (last >= 1)
	{
		popHeapRec(v, last, greater<int>());
		last--;
	}

	cout << "Vector after popping "
		  << v.size() << " times: ";
	writeVector(v);

	return 0;
}

template <typename T, typename Compare>
void adjustHeapRec(vector<T>& v, int first, int last, Compare comp)
{
	int currentPos, childPos;
	T target;
   
	// start at first and filter target down the heap    
	currentPos = first;
	target = v[first];
  
	// compute the left child index
	childPos = 2 * currentPos + 1;
	// is there a child. if not, we are done
	if (childPos <= last-1)
	{
		// index of right child is childPos+1. compare the
		// two children. change childPos if
		// comp(v[childPos+1], v[childPos]) is true
		if ((childPos+1 <= last-1) && 
            comp(v[childPos+1], v[childPos]))
			childPos = childPos + 1;

		// compare selected child to target. if comp() is
		// false, then v[childPos] <= target (maximum heap) or
		// v[childPos] >= target (minimum heap) and we are done;
		// otherwise, we move down the tree
		if (comp(v[childPos],target))
		{
			// comp(selected child, target) is true.
			// copy selected child to the parent.
			v[currentPos] = v[childPos];
			// copy target to the child and adjust the
			// subtree with root at index childPos
			v[childPos] = target;
			adjustHeapRec(v, childPos, last, comp);
		} 
	}
}

template <typename T, typename Compare>
void popHeapRec(vector<T>& v, int last, Compare comp)
{
	T temp;
   
	// exchange the first and last element in the heap
	temp = v[0];
	v[0] = v[last-1];
	v[last-1] = temp;
	
	// filter down the root over the range [0, last-1)
	adjustHeapRec(v, 0, last-1, comp);  
}

template <typename T, typename Compare>
void makeHeapRec(vector<T>& v, Compare comp)
{
	int heapPos, lastPos; 
	
	// compute the size of teh heap and the index
	// of the last parent
	lastPos = v.size();
	heapPos = (lastPos - 2)/2;

	// filter down every parent in order from last parent
	// down to root
	while (heapPos >= 0)
	{
		adjustHeapRec(v,heapPos, lastPos, comp);
		heapPos--;
	}
}

/*
Run:

Initial vector: 31  95  57  69  28  57  23  33  22  75

Vector after heapification: 95  75  57  69  31  57  23  33  22  28

Vector after popping 10 times: 22  23  28  31  33  57  57  69  75  95
*/