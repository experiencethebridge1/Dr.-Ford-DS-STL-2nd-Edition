#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>
#include <string>

#include "umap.h"			// umap class
#include "d_hashf.h"		// for hFstring hash function object type
#include "d_time24.h"	// time24 class
#include "umaphash.h"	// umapHashKey function object type

using namespace std;

// output the map, one key-value pair per line
template <typename Key, typename T, typename HashFunc>
void writeUMap(const umap<Key,T, HashFunc>& m);

int main()
{	// a map<string, time24, hFstring> object whose entries are student
	// names and total hours worked during a week. the hash table uses the
	// function object type hFstring and 101 buckets
	umap<string, time24, umapHashKey<string, time24, hFstring> >
		studentWorker(101);
	// map iterator
	umap<string, time24, umapHashKey<string, time24, hFstring> >::iterator
		iter;

	// object used to input the data from file "studwk.dat"
	ifstream fin;
	string studName;
	time24 workTime;

	// open the file "studwk.dat"
	fin.open("studwk.dat");

	// input successive lines in the file consisting of the
	// student name and the scheduled work time
	while (true)
	{
		fin >> studName;
		if (!fin)
			break;
		fin >> workTime;

		// add a new student with workTime as time worked or update the
		// accumulated work time if the student is already in the map
		studentWorker[studName] += workTime;

	}

	// output the map, one key-value pair per line
	writeUMap(studentWorker);

	return 0;
}

template <typename Key, typename T, typename HashFunc>
void writeUMap(const umap<Key,T, HashFunc>& m)
{
	umap<Key, T, HashFunc>::const_iterator iter = m.begin();

	while(iter != m.end())
	{
		cout << (*iter).first << "  " << (*iter).second << endl;
		iter++;
	}
}

/*
File: "studwk.dat"

Tolan	4:15
Dong	3:00
Tolan	3:15
Weber	5:30
Tolan	2:45
Brock	4:20
Dong	4:00
Dong	3:30
Tolan	3:15
Weber	2:30

Run:

Weber   8:00
Tolan  13:30
Brock   4:20
Dong  10:30
*/
