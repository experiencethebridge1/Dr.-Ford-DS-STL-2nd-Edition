#include <iostream>

#include "modclass.h"

using namespace std;

int main()
{
	modClass a(10), b(20), c(30);

	// verify that a(b+c) = a*b + a*c
	cout << "a*(b+c) = " << a*(b+c) << endl;
	cout << "a*b + a*c = " << a*b + a*c << endl;

   return 0;
}

/*
Run:

a*(b+c) = 3
a*b + a*c = 3
*/
