#include <iostream>
#include <list>

#include "d_random.h"
#include "d_util.h"

using namespace std;

// return an iterator pointing to the largest element
// in the list
template <typename T>
list<T>::iterator maxIter(list<T>::iterator first,
								 list<T>::iterator last);

// use selection sort to order aList
template <typename T>
void selectionSort(list<T>& aList);

int main()
{	
	list<int> intList;
	randomNumber rnd;
	int i;

	// initialize intList with 10 random integers
	// in the range from 0 to 24
	for (i=0;i < 10;i++)
		intList.push_back(rnd.random(25));

	// output the initial (unsorted) list
	cout << "Unsorted list: ";
	writeList(intList);

	// sort the random integers
	selectionSort(intList);

	cout << "Sorted list: ";
	writeList(intList);

	return 0;
}

template <typename T>
list<T>::iterator maxIter(list<T>::iterator first,
								 list<T>::iterator last)
{
	// if the list is empty, return last
	if (first == last)
		return last;

	// advance iter through the list, recording the largest
	// value using maxValIter
	list<T>::iterator iter = first, maxValIter = first;

	// move to the second list element
	iter++;
	// cycle through the list from 2nd to 3rd, etc.
	while (iter != last)
	{
		// if we find a larger value, change maxValIter
		if (*maxValIter < *iter)
			maxValIter = iter;

		iter++;
	}

	return maxValIter;

}
								 
template <typename T>
void selectionSort(list<T>& aList)
{
	// move passIter through the list, assigning currMaxIter
	// the location of maximum in the range [passIter, aList.end())
	list<T>::iterator passIter = aList.begin(), currMaxIter;
	int i, n = aList.size();

	// sort the list
	for (i=0;i < n;i++)
	{
		// find the maximum element in the range
		// [passIter, aList.end())
		currMaxIter = maxIter<T> (passIter, aList.end());

		// push the maximum value on the front of the list
		aList.push_front(*currMaxIter);

		// see if the maximum occurs at passIter
		if (currMaxIter == passIter)
			// max is at passIter. erase() and move forward
			aList.erase(passIter++);
		else
			// keep passIter where it is and erase()
			aList.erase(currMaxIter);
	}
}


/*
Run:

Unsorted list: 12  1  6  8  5  9  22  9  13  17
Sorted list: 1  5  6  8  9  9  12  13  17  22
*/
