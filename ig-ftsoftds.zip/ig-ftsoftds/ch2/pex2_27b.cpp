#include <iostream>

#include "time12.h"		// time12 class

using namespace std;

int main()
{
	// midnight in New York City
	time12 nyc(12, 0, AM);
	// time in Frankfurt, Germany
	time12 frankfurt;

	// set Frankfurt time to New York City time
	frankfurt = nyc;
	// add 6 hours
	frankfurt.addTime(6*60);

	// output time in Frankfurt
	cout << "The time in Frankfurt is ";
	frankfurt.writeTime();
	cout << endl;

   return 0;
}

/*
Run:

The time in Frankfurt is 6:00 AM
*/
