#include <iostream>

#include "accum.h"

using namespace std;

int main()
{
	// accumulate negative and positive totals
	accumulator	negTotal, posTotal;
	// data comes from arr
	double arr[8] = {4, -8, 6, 9, -2, 10, -14, 5};
	int i;

	for (i=0;i < 8;i++)
		if(arr[i] < 0)
			// accumulate the negative value
			negTotal.addValue(arr[i]);
		else
			// accumulate the positive value
			posTotal.addValue(arr[i]);

	// output the results
	cout << "Total of the negative numbers = "
		  << negTotal.getTotal() << endl;
	cout << "Total of the positive numbers = "
		  << posTotal.getTotal() << endl;

	return 0;
}

/*
Run:

Total of the negative numbers = -24
Total of the positive numbers = 34
*/
