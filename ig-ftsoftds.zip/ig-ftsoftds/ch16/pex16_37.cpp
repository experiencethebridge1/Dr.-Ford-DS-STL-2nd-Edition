#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>
#include <string>

#include "d_graph.h"

using namespace std;

// determine whether g has an Euler tour
template <typename T>
bool eulerTour(graph<T>& g);

int main()
{
	// vertices are characters
	graph<char> g, MST;
	ifstream graphIn;
	string fileName;

	cout << "Enter the graph file name: ";
	cin >> fileName;

	graphIn.open(fileName.c_str());

	graphIn >> g;

	if (eulerTour(g))
		cout << "The graph has an Euler Tour." << endl;
	else
		cout << "The graph does not have an Euler Tour." << endl;

	return 0;
}

template <typename T>
bool eulerTour(graph<T>& g)
{
	graph<T>::iterator i;
	vector<set<T> > component;

	// compute the strong components of g
	strongComponents(g, component);
	// if there is more than one strong component,
	// the graph is not strongly connected and there is
	// no Euler Tour
	if (component.size() != 1)
		return false;

	// verify that the in- and out-degree of each vertex
	// in g are equal
	i = g.begin();
	while (i != g.end())
	{
		if (g.inDegree(*i) != g.outDegree(*i))
			// no Euler Tour
			return false;
		i++;
	}

	// the graph has an Euler Tour
	return true;
}

/*
Run 1:

Enter the graph file name: graphA.dat
The graph has an Euler Tour.

Run 2:

Enter the graph file name: graphB.dat
The graph does not have an Euler Tour.
*/
