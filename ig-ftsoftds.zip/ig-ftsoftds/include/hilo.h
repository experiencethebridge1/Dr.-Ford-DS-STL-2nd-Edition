#ifndef HILO_GAME
#define HILO_GAME

#include <iostream>

#include "d_random.h"		// use randomNumber class

using namespace std;

class playHiLow 
{
	public:
		playHiLow()
		{	// use to generate the target
			randomNumber rnd;

			// 1 <= target <= 1000
			target = 1 + rnd.random(1000);
		}

		// compare guess with the target
		int makeGuess(int guess)
		{
			// compare guess with target and return
			//    -1, target < guess
			//     0, target == guess
			//     1, target > guess
			if (target < guess)
				return -1;
			else if (target == guess)
				return 0;
			else
				return 1;
		}

		// output the target
		void writeTarget()
		{ cout << "Target = " << target << endl; }

	private:
		int target;
};

/*
*/

#endif	// HILO_GAME
