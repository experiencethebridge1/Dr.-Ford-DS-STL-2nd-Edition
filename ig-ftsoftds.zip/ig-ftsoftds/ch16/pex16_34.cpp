#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>

#include "d_graph.h"
#include "d_util.h"	// for writeContainer()

using namespace std;

int main()
{	
	graph<char> g;
	ifstream fin;
	char vertex;
	set<char> bfsSet;
	list<char> dfsList;

	fin.open("graphB.dat");
	fin >> g;

	// prompt for a vertex
	cout << "Enter a vertex: ";
	cin >> vertex;

	// perform a breadth-first search from vertex and output
	// the set
	bfsSet = bfs(g, vertex);
	cout << "Breadth-first search from " << vertex << ": ";
	writeContainer(bfsSet.begin(), bfsSet.end());
	cout << endl;

	// perform a depth-first search of the entire graph and
	// output the vertices in the reverse order of their
	// finish times
	dfs(g, dfsList);
	cout << "Depth-first search of entire graph: ";
	writeContainer(dfsList.begin(), dfsList.end());
	cout << endl;

	return 0;
}

/*
Run:

Enter a vertex: C
Breadth-first search from C: A  B  C  D  E  F
Depth-first search of entire graph: A  B  C  D  F  E
*/
