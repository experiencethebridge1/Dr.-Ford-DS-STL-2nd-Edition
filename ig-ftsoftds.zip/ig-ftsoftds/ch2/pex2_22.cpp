#include <iostream>

#include "tworker.h"
#include "d_time24.h"

using namespace std;

int main()
{
	// worker's pay rate, starting and ending time
	double payRate;
	time24 start, end;

	// prompt for the data
	cout << "Enter the pay per hour: ";
	cin >> payRate;

	cout << "Enter the starting and ending times: ";
	cin >> start >> end;

	// declare a tempWorker object with the data that was input
	tempWorker w(start, end, payRate);

	// output the worker's pay
	cout << "The worker's pay for the day = $"
		  << w.pay() << endl;

   return 0;
}

/*
Run:

Enter the pay per hour: 8.50
Enter the starting and ending times: 8:30 16:00
The worker's pay for the day = $63.75
*/
