#include <iostream>

using namespace std;

// recursive fuction that computes the sum of the integers 1..n
int sumToN(int n);

int main()
{
	// declare N as a constant. change N and recompile to demonstrate
	// the formula for other values
	const int N = 50;
	int arr[N];
	int i;

	for (i=1;i <= N;i++)
		arr[i] = i;

	cout << "Formula for 1+2+3+...+" << N << ": "
		  << N*(N+1)/2 << endl;
	cout << "Result of calling sumToN(): " << sumToN(N) << endl;

   return 0;
}

int sumToN(int n)
{
	if (n == 1)
		return 1;
	else
		return sumToN(n-1) + n;
}

/*
Run:

Formula for 1+2+3+...+50: 1275
Result of calling sumToN(): 1275
*/
