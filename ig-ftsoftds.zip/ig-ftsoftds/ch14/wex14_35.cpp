#include <iostream>

using namespace std;

// compute the n th Fibonacci number
double fib(int n);

// compute the cost of a Huffman tree whose characters
// have frequencies determined by the first n Fibonacci
// numbers
double fibCost(int n);

int main()
{
	// call fibCost() to find the cost of a Huffman
	// tree whose bit codes are 0 10 110 1110 ... 11...11
	//                                            <-255->
	cout << fibCost(256) << endl;

	return 0;
}

double fib(int n)
{
	double oneback, twoback, fn;
	int i;

	if (n == 1 || n == 2)
		return 1;

	oneback = twoback = 1;

	for (i=0;i < n-2;i++)
	{
		fn = twoback + oneback;
		twoback = oneback;
		oneback = fn;
	}

	return fn;
}

double fibCost(int n)
{
	double total;
	int i, j;

	// fib(1) and fib(2) are at depth n-1
	total = (n-1)*(fib(1) + fib(2));

	// remaining frequencies fib(3) ... fib(n) are
	// at depth i = n-2, n-3, ..., 1
	for(i=n-2, j=3;i >= 1;i--, j++)
		total += i * fib(j);

	return total;
}

/*
Run:

9.71184e+053
*/
