#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <iomanip>
#include <vector>

using namespace std;

// recursive computation of the nth generalized Fibonacci number
// of order k
int fibg(int n, int k);

// computation of the nth generalized Fibonacci number of
// order k using bottom-up dynamic programming
int fibgDyn(int n, int k);

int main()
{
	int n, k, i;

	cout << "Enter an upper bound and order: ";
	cin >> n >> k;
	cout << endl;

	cout << "Order for the generalized Fibonacci sequence = "
		  << k << endl << endl;
	cout << " n " << setw(12) << "fibg()" << setw(12)
		  << "fibgDyn()" << endl << endl;
	// output the generalized Fibonacci numbers of order k from
	// i = 0 through i = n using the recursive and the dynamic
	// programming implementation
	for (i=0;i <= n;i++)
		cout << setw(2) << i << ':' << setw(10) << fibg(i,k)
			  << setw(10) << fibgDyn(i,k) << endl;

	return 0;
}

int fibg(int n, int k)
{
	int fibgValue, i;

	if (n < k-1)
		// f(n,k) = 0, 0 <= n < k-1
		fibgValue = 0;
	else if (n == k-1)
		// f(n,k) = 1, n = k-1
		fibgValue = 1;
	else
	{
		fibgValue = 0;

		// f(n,k) = f(n-1,k)+f(n-2,k)+...+f(n-k,k), n >= k
		for (i=1;i <= k;i++)
			fibgValue += fibg(n-i,k);
	}

	return fibgValue;
}

int fibgDyn(int n, int k)
{
	int fibgDynValue;

	if (n < k-1)
		// fibgDyn(n,k) = 0, 0 <= n < k-1
		fibgDynValue = 0;
	else if (n == k-1)
		// fibgDyn(n,k) = 1, n = k-1
		fibgDynValue = 1;
	else
	{
		int i, j, sum;
		// v holds previously computed values. v[n] will be the
		// value of fibgDyn(n,k)
		vector<int> v(n+1);

		// initialize the first k values 0,0,0,...,0,1
		for (i=0;i < k-1;i++)
			v[i] = 0;
		v[k-1] = 1;

		// compute and store fibgDyn(i,k), k <= i <= n

		// fibgDyn(i,k) =
		//		fibgDyn(i-1,k)+fibgDyn(i-2,k)+...+fibgDyn(i-k,k)
		for (i=k;i <= n;i++)
		{
			sum = 0;
			for (j=1;j <= k;j++)
				sum += v[i-j];

			v[i] = sum;
		}

		fibgDynValue = v[n];
	}

	return fibgDynValue;
}

/*
Run:
Enter an upper bound and order: 15 3

Order for the generalized Fibonacci sequence = 3

 n       fibg()   fibgDyn()

 0:         0         0
 1:         0         0
 2:         1         1
 3:         1         1
 4:         2         2
 5:         4         4
 6:         7         7
 7:        13        13
 8:        24        24
 9:        44        44
10:        81        81
11:       149       149
12:       274       274
13:       504       504
14:       927       927
15:      1705      1705
*/
