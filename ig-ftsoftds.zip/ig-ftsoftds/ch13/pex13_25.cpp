#include <iostream>

#include "square_i.h"

using namespace std;

int main()
{
	double side;

	cout << "Enter the side of a square: ";
	cin >> side;

	square sq(side);

	cout << "Area and perimeter of the original square: "
		  << sq.area() << "  " << sq.perimeter() << endl;

	sq.setSide(2*side);

	cout << "Area and perimeter after doubling the sides of the square: "
		  << sq.area() << "  " << sq.perimeter() << endl;

	return 0;
}

/*
Run:

Enter the side of a square: 3
Area and perimeter of the original square: 9  12
Area and perimeter after doubling the sides of the square: 36  24
*/
