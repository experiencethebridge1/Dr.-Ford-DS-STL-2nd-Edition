#include <iostream>

#include "d_random.h"

using namespace std;

// toss n coins and return the number of heads. use
// the random number generator rnd for the simulation
int countHeads(int n, randomNumber& rnd);

const int NUMBERTOSSES = 5000000;

// toss n coins NUMBERTOSSES times and determine the
// empirical probability of tossing m heads
double empiricalHeadToss (int m, int n);

int main()
{
	int n, m;

	cout << "Enter the number of coins: ";
	cin  >> n;
	cout << "Enter the number of heads: ";
	cin >> m;

	cout << "The empirical probability is "
		  << empiricalHeadToss(m, n) << endl;

	return 0;
}

int countHeads(int n, randomNumber& rnd)
{
	int heads = 0, i;

	for (i=0;i < n;i++)
		// 1 = heads; 0 = tails
		heads += rnd.random(2);

	return heads;
}


double empiricalHeadToss(int m, int n)
{
	int i, mHeadCount = 0;
	randomNumber rnd;

	for (i=0;i < NUMBERTOSSES;i++)
		// increment hHeadCount if tossing n coins
		// returns m heads
		if (countHeads(n,rnd) == m)
			mHeadCount++;

	return double(mHeadCount)/NUMBERTOSSES;
}

/*
Run 1:

Enter the number of coins: 5
Enter the number of heads: 3
The empirical probability is 0.312767

Run 2:

Enter the number of coins: 5
Enter the number of heads: 1
The empirical probability is 0.156282
*/
