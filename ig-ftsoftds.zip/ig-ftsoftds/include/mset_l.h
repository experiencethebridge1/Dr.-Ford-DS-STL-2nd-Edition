#ifndef MINIMULTISET_CLASS_LIST_BASED
#define MINIMULTISET_CLASS_LIST_BASED

#include <list>

#include "d_except.h"

using namespace std;

template <typename T>
class miniMultiSet
{
	public:

		typedef typename list<T>::iterator iterator;
		typedef typename list<T>::const_iterator const_iterator;
			// miniMultiSet iterators are simply list iterators

		miniMultiSet();
			// default constructor

		miniMultiSet(T *first, T *last);
			// build a multiset whose data are determined by
			// the pointer range [first, last)

		bool empty() const;
			// is the multiset empty?

		int size() const;
			// return the number of elements in the multiset

		int count (const T& item) const;
			// return the number of duplicate occurrences of item
			// in the multiset

		iterator find(const T& item);
			// search for item in the multiset and return an iterator
			// pointing at the first occurrence matching item or end()
			// if it is not found
		const_iterator find(const T& item) const;
			// constant version

		pair<iterator, iterator> equal_range(const T& item);
			// return a pair of iterators such that all occurrences
			// of item are in the iterator range
			// [first member of pair, second member of pair)
		pair<const_iterator, const_iterator>
		  equal_range(const T& item) const;
			// constant version
			
		iterator insert(const T& item);
			// insert item into the multiset and return an
			// iterator pointing at the new element.
			// Postcondition: the element item is added to the multiset

		int erase(const T& item);
			// erase all occurrences of item from the multiset
			// and return the number of items erased.
			// Postcondition: the size of the multiset is reduced
			// by the number of occurrences of item in the multiset

		void erase(iterator pos);
			// erase the item pointed to by pos.
			// Preconditions: the multiset is not empty and pos points
			// to an item in the multiset. if the multiset is empty,
			// the function throws the underflowError exception. if the
			// iterator is invalid, the function throws the
			// referenceError exception.
			// Postcondition: the multiset size decreases by 1

		void erase(iterator first, iterator last);
			// erase the elements in the range [first, last)
			// Precondition: the multiset is not empty. if the
			// multiset is empty, the function throws the
			// underflowError exception.
			// Postcondition: the multiset size decreases by the number
			// elements in the range

		iterator begin();
			// return an iterator pointing at the first member
			// in the multiset
		const_iterator begin() const;
			// constant version of begin()

		iterator end();
			// return an iterator pointing just past the last
			// member in the multiset
		const_iterator end() const;
			// constant version of end()

	private:
		list<T> multisetList;
			// multiset implemented using a list

		int distance(iterator first, iterator last);
			// return the number of items in the range [first, last)
		int distance(const_iterator first, const_iterator last) const;
			// constant version
};

template <typename T>
int miniMultiSet<T>::distance(iterator first, iterator last)
{
	int itemCount = 0;

	// count the number of elements in the range
	while(first != last)
	{
		itemCount++;
		first++;
	}

	// return the count
	return itemCount;
}

template <typename T>
int miniMultiSet<T>::distance(const_iterator first, const_iterator last) const
{
	int itemCount = 0;

	// count the number of elements in the range
	while(first != last)
	{
		itemCount++;
		first++;
	}

	// return the count
	return itemCount;
}

template <typename T>
miniMultiSet<T>::miniMultiSet()
{}

// insert the items into the underlying list
template <typename T>
miniMultiSet<T>::miniMultiSet(T *first, T *last)
{
	// insert each element of the range [first, last)
	// into the multiset
	while (first != last)
	{
		insert(*first);
		first++;
	}
}

// is the underlying list empty?
template <typename T>
bool miniMultiSet<T>::empty() const
{
	return multisetList.empty();
}

// return the size of the underlying list
template <typename T>
int miniMultiSet<T>::size() const
{
	return multisetList.size();
}

template <typename T>
int miniMultiSet<T>::count (const T& item) const
{
	// use p to capture return value from equal_range()
	pair<const_iterator, const_iterator> p;

	// find the range for item in the multiset
	p = equal_range(item);

	// return the number of elements in the range [p.first,p.second)
	return distance(p.first, p.second);
}

template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::find(const T& item)
{
	// use iter to do a sequential search of multisetList
	iterator iter = multisetList.begin();

	// look for item and break out of the loop if found
	while (iter != multisetList.end())
	{
		if (*iter == item)
			break;

		iter++;
	}

	// iter either points at item or is end() if item is not
	// in the multiset
	return iter;
}

template <typename T>
miniMultiSet<T>::const_iterator miniMultiSet<T>::find(const T& item) const
{
	// use iter to do a sequential search of multisetList
	const_iterator iter = multisetList.begin();

	// look for item and break out of the loop if found
	while (iter != multisetList.end())
	{
		if (*iter == item)
			break;

		iter++;
	}

	// iter either points at item or is end() if item is not
	// in the multiset
	return iter;
}

template <typename T>
pair<miniMultiSet<T>::iterator, miniMultiSet<T>::iterator>
miniMultiSet<T>::equal_range(const T& item)
{
	// locate all occurrences of item in [first, last)
	iterator first, last;

	// find the first occurrence of item
	first = find(item);

	// is item in the multiset?
	if (first != end())
	{
		// item is in the multiset. use last
		// to look for for the remaining
		// occurrences of item and position last
		// just after the last one
		last = first;
		last++;
		while (last != end() && *last == item)
			last++;
	}
	else
		// item not in the multiset. last is also end()
		last = end();

	return pair<iterator, iterator>(first, last);
}

template <typename T>
pair<miniMultiSet<T>::const_iterator, miniMultiSet<T>::const_iterator>
miniMultiSet<T>::equal_range(const T& item) const
{
	// locate all occurrences of item in [first, last)
	const_iterator first, last;

	// find the first occurrence of item
	first = find(item);

	// is item in the multiset?
	if (first != end())
	{
		// item is in the multiset. use last
		// to look for for the remaining
		// occurrences of item and position last
		// just after the last one
		last = first;
		last++;
		while (last != end() && *last == item)
			last++;
	}
	else
		// item not in the multiset. last is also end()
		last = end();

	return pair<const_iterator, const_iterator>(first, last);
}
	
template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::insert(const T& item)
{
	// search for the first occurrence of item
	iterator iter = find(item);

	// insert item into the list at position iter and return an
	// iterator pointing to the new list item. note that if
	// iter == end(), item is put at the back of the list
	return multisetList.insert(iter, item);
}

template <typename T>
int miniMultiSet<T>::erase(const T& item)
{
	// use to hold return value from equal_range()
	pair<iterator,iterator> p;
	int numberErased;

	// find the range [p.first,p.second) for item
	p = equal_range(item);
	// compute the number of elements in the range
	numberErased = distance(p.first,p.second);

	// erase the range
	multisetList.erase(p.first,p.second);

	// return the number of elements erased
	return numberErased;
}

template <typename T>
void miniMultiSet<T>::erase(iterator pos)
{
	if (multisetList.empty())
		throw
			underflowError("miniMultiSet erase(pos): multiset empty");
	else if (pos == multisetList.end())
		throw
		  referenceError("miniMultiSet erase(pos): invalid iterator");

	// erase element at location pos in multisetList
	multisetList.erase(pos);
}

template <typename T>
void miniMultiSet<T>::erase(iterator first, iterator last)
{
	if (multisetList.empty())
		throw
			underflowError("miniMultiSet erase(pos): multiset empty");

	// erase the range [first, last) in multisetList
	multisetList.erase(first, last);
}

template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::begin()
{
	// beginning of multiset is beginning of multisetList
	return multisetList.begin();
}

template <typename T>
miniMultiSet<T>::const_iterator miniMultiSet<T>::begin() const
{
	// beginning of multiset is beginning of multisetList
	return multisetList.begin();
}

template <typename T>
miniMultiSet<T>::iterator miniMultiSet<T>::end()
{
	// end of multiset is end of multisetList
	return multisetList.end();
}

template <typename T>
miniMultiSet<T>::const_iterator miniMultiSet<T>::end() const
{
	// end of multiset is end of multisetList
	return multisetList.end();
}

#endif	// MINIMULTISET_CLASS_LIST_BASED
