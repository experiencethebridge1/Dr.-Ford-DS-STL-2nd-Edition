#include <iostream>

#include "d_util.h"

using namespace std;

// return a pointer to a dynamic array of size double values.
// each element of the array has value initValue
double *createArray(int size, double initValue);

int main()
{	
	double *arr;
	int i;

	// create a dynamic array of 5 double values. each has the
	// initial value 1.0. output the array
	arr = createArray(5, 1.0);
	cout << "Original array: ";
	writeArray(arr, 5);

	// change the values in arr to 1.0, 2.0, 3.0, 4.0, 5.0 and
	// output the modified array
	for (i=0;i < 5;i++)
		arr[i] = i + 1.0;
	cout << "Final array: ";
	writeArray(arr, 5);

	return 0;
}

double *createArray(int size, double initValue)
{
	// allocate a double array with size entries
	double *arr = new double [size];
	int i;

	// give each entry of arr the value initValue
	for (i=0;i < size;i++)
		arr[i] = initValue;

	// return the dynamic array address
	return arr;
}

/*
Run:

Original array: 1  1  1  1  1
Final array: 1  2  3  4  5
*/

