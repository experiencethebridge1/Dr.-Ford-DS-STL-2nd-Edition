#include <iostream>
#include <stack>

#include "d_except.h"	// for underflowError exception

using namespace std;

// return the second element on the stack. the
// function throws the underflowError exception
// if the stack has less than 2 elements
template <typename T>
T second(const stack<T>& s);

int main()
{
	int i, value;
	stack<int> s;

	// enter 5 integer values and push them onto s
	cout << "Enter 5 integer values: ";
	for (i=0;i < 5;i++)
	{
		cin >> value;
		s.push(value);
	}

	cout << "The top of stack = " << s.top() << endl
		  << "The second element on the stack = "
		  << second(s) << endl;

	cout << "Contents of the stack: ";
	// output and pop elements until s is empty
	while (!s.empty())
	{
		cout << s.top() << "  ";
		s.pop();
	}
	cout << endl;

	return 0;
}

template <typename T>
T second(const stack<T>& s)
{
	if (s.size() < 2)
		throw underflowError("second(): stack size must be at least 2");

	// create a copy of s
	stack<T> tmp = s;

	// pop tmp
	tmp.pop();
	// return the top of tmp (2nd element of s)
	return tmp.top();
}

/*
Run:

Enter 5 integer values: 2 3 5 6 7
The top of stack = 7
The second element on the stack = 6
Contents of the stack: 7  6  5  3  2
*/
