#ifndef VECTOR_BASED_VPRIORITY_QUEUE_CLASS
#define VECTOR_BASED_VPRIORITY_QUEUE_CLASS

#include <vector>

#include "d_except.h"

using namespace std;

template <typename T>
class vpriority_queue
{
    public:
		vpriority_queue();
			// default constructor. create an empty priority queue
      
		void push(const T& item);
			// insert item into the priority queue.
			// Postcondition: the priority queue has one more element

		void pop();
			// remove the highest priority (maximum) item from the
			// priority queue.
			// Precondition: the priority queue is not empty. if it is
			// empty, the function throws the underflowError exception

		T& top();
			// return the highest priority (maximum) item in the
			// priority queue
			// Precondition: the priority queue is not empty. if it is
			// empty, the function throws the underflowError exception

		const T& top() const;
			// constant version

		bool empty() const;
			// is the priority queue empty?

		int size() const;
			// return the size of the priority queue

	private:
		vector<T> pqVector;
			// vector that implements the priority queue

		int findMaxIndex() const;
			// find the index of the maximum value in pqVector

		int maxIndex;
			// index of the maximum value

		bool recomputeMaxIndex;
			// do we need to compute the index of the maximum element?
};

template <typename T>
int vpriority_queue<T>::findMaxIndex() const
{
	// start with pqVector[0] as the maximum and 0 as its index
	T maxval = pqVector[0];
	int mindex = 0;
	// capture the vector size in n
	int i, n = pqVector.size();

	// visit the remaining elements, updating maxval and mindex
	for (i = 1; i < n; i++)
		if (maxval < pqVector[i])
		{
			// new maximum is pqVector[i]. new mindex is i
			maxval = pqVector[i];
			mindex = i;
		}

	return mindex;
}

template <typename T>
vpriority_queue<T>::vpriority_queue(): recomputeMaxIndex(false)
{}

template <typename T>
void vpriority_queue<T>::push(const T& item)
{
	// insert item at the rear of the vector
	pqVector.push_back(item);

	// must recompute the maximum on another call to
	// top() or pop()
	recomputeMaxIndex = true;
}

template <typename T>
void vpriority_queue<T>::pop()
{
	if (pqVector.size() == 0)
		throw underflowError("vpriority_queue pop(): priority queue empty");

	// recompute the maximum, if necessary
	if (recomputeMaxIndex)
		maxIndex = findMaxIndex();

	// copy rear element to the location of the maximum
	// element and remove the rear element
	pqVector[maxIndex] = pqVector.back();
	pqVector.pop_back();

	// must recompute the maximum on another call to
	// top() or pop()
	recomputeMaxIndex = true;
}

template <typename T>
T& vpriority_queue<T>::top()
{
	if (pqVector.size() == 0)
		throw underflowError("vpriority_queue top(): priority queue empty");

	// if maximum is not current, compute it
	if (recomputeMaxIndex)
	{
		maxIndex = findMaxIndex();
		recomputeMaxIndex = false;
	}

	// return the maximum value
	return pqVector[maxIndex];
}

template <typename T>
const T& vpriority_queue<T>::top() const
{
	if (pqVector.size() == 0)
		throw underflowError("vpriority_queue top(): priority queue empty");

	// if maximum is not current, compute it
	if (recomputeMaxIndex)
	{
		maxIndex = findMaxIndex();
		recomputeMaxIndex = false;
	}

	// return the maximum value
	return pqVector[maxIndex];
}

template <typename T>
bool vpriority_queue<T>::empty() const
{
	return pqVector.size() == 0;
}

template <typename T>
int vpriority_queue<T>::size() const
{
	return pqVector.size();
}

#endif	// VECTOR_BASED_VPRIORITY_QUEUE_CLASS
