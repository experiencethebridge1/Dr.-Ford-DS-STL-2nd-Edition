#include <iostream>
#include <vector>

using namespace std;

// sort an array using the exchange sort algorithm
template <class T>
void exchangeSort(vector<T>& v);

int main()
{
	int n, i, val;
	vector<int> v;

	// prompt for n
	cout << "Enter n: ";
	cin >> n;

	// it is unlikely, but the user could enter n = 0
	if (n == 0)
		return 0;

	// input n integers and insert each at the back
	// of v
	cout << "Enter " << n << " integer values: ";
	for (i=0;i < n;i++)
	{
		cin >> val;
		v.push_back(val);
	}

	// use insertion sort to order v
	exchangeSort(v);

	cout << "Median = " << v[n/2] << endl;

   return 0;
}

template <class T>
void exchangeSort(vector<T>& v)
{
   int pass, i, n = v.size();
	T temp;
   
	// make n-1 passes through the data
	for (pass = 0; pass < n-1; pass++)
   	// locate least of v[pass] ... v[n-1] at v[pass]
      for (i = pass+1; i < n; i++)
         if (v[i] < v[pass])
			{
				temp = v[pass];
				v[pass] = v[i];
				v[i] = temp;
			}
}

/*
Run 1:

Enter n: 7
Enter 7 integer values: 9 16 3 8 2 12 6
Median = 8

Run 2:

Enter n: 6
Enter 6 integer values: 15 34 18 6 55 78
Median = 34
*/
