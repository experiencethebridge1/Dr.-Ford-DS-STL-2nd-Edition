#include <iostream>

#include "d_sort.h"
#include "d_random.h"
#include "d_util.h"

using namespace std;

// order arr using the double-ended selection sort
template <typename T>
void deSelSort(T arr[], int n);

int main()
{
	// declare an integer array and a random number generator
	int arr[15];
	int i;
	randomNumber rnd;
		
	// initialize and output the unsorted array
	cout << "Original array" << endl;

	// fill the array with random integers in the range 0 to 99
	for (i = 0; i < 15; i++)
	{
		arr[i] = rnd.random(100);
		cout << arr[i] << "  ";
	}
	cout << endl << endl;

	// call deSelSort() to order the array and then output it
	deSelSort(arr,15);

	cout << "Sorted array" << endl;
	for (i=0;i < 15; i++)
		cout << arr[i] << "  ";
	cout << endl;

   return 0;
}

template <typename T>
void deSelSort(T arr[], int n)
{
	// index of smallest and largest elements in a sublist
   int smallIndex, largeIndex;
   int i, j, k;
	T temp;

	// starting indices
	i = 0;
	j = n-1;
	// contine as long as i < j
   while (i < j)
   {
		// scan the sublist {arr[i], ..., arr[j]}
		smallIndex = i;
		largeIndex = i;

		// k traverses the sublist {arr[i+1], ..., arr[j]}
		for (k = i+1; k <= j; k++)
         // update if smaller element found 
			if (arr[k] < arr[smallIndex])
				smallIndex = k;
         // update if larger element found 
			else if (arr[largeIndex] < arr[k])
				largeIndex = k;

		// if smallIndex and i are not the same location,
		// exchange the smallest item in the sublist with arr[i]
		if (smallIndex != i)
		{
			temp = arr[i];
			arr[i] = arr[smallIndex];
			arr[smallIndex] = temp;

			// arr[i] could be the index of the largest element.
			// if so, the exchange moves the largest value to
			// index smallIndex
			if (largeIndex == i)
				largeIndex = smallIndex;
		}

		// if largeIndex and j are not the same location,
		// exchange the largest item in the sublist with arr[j]
		if (largeIndex != j)
		{
			temp = arr[j];
			arr[j] = arr[largeIndex];
			arr[largeIndex] = temp;
		}

		// move i forward and j backward
		i++;
		j--;
	}
}

/*
Run:

Original array
85  88  2  54  99  25  86  55  62  66  76  55  82  45  97

Sorted array
2  25  45  54  55  55  62  66  76  82  85  86  88  97  99
*/
