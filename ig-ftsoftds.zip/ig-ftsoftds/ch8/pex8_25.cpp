#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <queue>

#include "d_except.h"

using namespace std;

// insert item into the the queue at position n. note that
// n = 1 is the front of the queue. if n = q.size()+1, item
// is inserted at the back of the queue
template <typename T>
void cut(queue<T>& q, int n, const T& item);

int main()
{
	int n, i, value;
	queue<int> intQueue;

	// input 8 integers and insert them into the queue
	cout << "Enter 8 integer values: ";
	for (i=0;i < 8;i++)
	{
		cin >> n;
		intQueue.push(n);
	}

	cout << "Enter a position in the queue (1 <= n <= " << intQueue.size()+1
		  << "): ";
	cin >> n;
	cout << "Enter an integer value: ";
	cin >> value;

	// move the nth element to the top of q
	cut(intQueue, n, value);

	// flush the queue and output its elements
	cout << "After moving element " << value
		  << " into the queue at position " << n
		  << ", the queue is:" << endl;
	while (!intQueue.empty())
	{
		cout << intQueue.front() << "  ";
		intQueue.pop();
	}
	cout << endl;

	return 0;
}

template <typename T>
void cut(queue<T>& q, int n, const T& item)
{
	int i, qsize = q.size();

	// verify that n is in the correct range
	if (n < 1 || n > q.size()+1)
		throw rangeError();

	// push item if n is q.size()+1
	if (n == q.size()+1)
	{
		q.push(item);
		return;
	}

	// move top n-1 items to the back of the queue. note that their order
	// at the back is the same as their order at the front
	//  a b x x ... x c y ... y
	//  <----------->
	//    n-1 items
	//  <--------------------->
	//        qsize items
	//  c y ... y a b x x ... x
	for (i=1;i <= n-1;i++)
	{
		q.push(q.front());
		q.pop();
	}

	// push item at the back of the queue
	//  c y ... y a b x x ... x item
	q.push(item);

	// move the remaining items to the back of q
	//  a b x x ... x item c y ... y
	for (i=0;i < qsize-n+1;i++)
	{
		q.push(q.front());
		q.pop();
	}
}

/*
Run:

Enter 8 integer values: 1 2 3 4 5 6 7 8
Enter a position in the queue (1 <= n <= 9): 3
Enter an integer value: 25
After moving element 25 into the queue at position 3, the queue is:
1  2  25  3  4  5  6  7  8
*/
