#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <vector>

#include "d_random.h"
#include "d_util.h"

using namespace std;

// use the sequential search to locate target in the index range
// [first, last). return the index of the first occurrence of
// target or last if target is not found
template <typename T>
int seqSearch(const vector<T>& v, int first, int last, const T& target);

int main()
{
	int n, target, count = 0;
	// random number generator
	randomNumber rnd;
	int i;

	// prompt for n and declare a vector of n integers
	cout << "Enter n: ";
	cin >> n;

	vector<int> v(n);

	// initialize v with random integers in the range from 0 to 9
	for (i=0;i < v.size();i++)
		v[i] = rnd.random(10);

	// output the vector
	cout << "Vector values: ";
	writeVector(v);
	cout << endl;

	// target for search is the last element of v
	target = v.back();

	// start searching for target from index 0
	i = 0;
	// keep going as long as the sequential search for target in the range
	// [i, v.size()) is successful
	while ((i = seqSearch(v,i,v.size(),target)) != v.size())
	{
		// increment count and move i forward
		count++;
		i++;
	}

	// output the number of occurrences of target
	cout << "The value " << target << " occurs " << count
		  << " times in the vector." << endl;

   return 0;
}

template <typename T>
int seqSearch(const vector<T>& v, int first, int last, const T& target)
{
	int i;

   // scan indices in the range first <= i < last
	for(i=first; i < last; i++)
		if (v[i] == target)		// assume T has the "==" operator
			return i;				// immediately return on a match

	return last;					// otherwise return last
}

/*
Run:

Enter n: 15
Vector values: 7  5  0  1  5  3  7  7  9  0  1  1  9  7  5

The value 5 occurs 3 times in the vector.
*/
