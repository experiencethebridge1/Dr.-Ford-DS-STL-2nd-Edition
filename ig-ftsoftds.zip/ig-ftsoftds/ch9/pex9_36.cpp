#include <iostream>

#include "d_dnode.h"
#include "d_nodel.h"
#include "d_random.h"

using namespace std;

// merge the ordered list, list2, into the
// ordered list, list1. list2 is empty at
// the conclusion of the merge
template <typename T>
void merge(dnode<T> *list1, dnode<T> *list2);

int main()
{
	int arrA[8] = {2,8,12,25,33,48,55,75};
	int arrB[12] =  {1,3,6,9,12,23,33,45,55,68,88,95};
	int arrASize = sizeof(arrA)/sizeof(int),
		 arrBSize = sizeof(arrB)/sizeof(int);
	dnode<int> *listA = new dnode<int>, *listB = new dnode<int>;
	int i;

	for(i=0;i < arrASize;i++)
		insert(listA, arrA[i]);

	for(i=0;i < arrBSize;i++)
		insert(listB, arrB[i]);

	cout << "listA: ";
	writeDLinkedList(listA, " ");
	cout << endl;

	cout << "listB: ";
	writeDLinkedList(listB, " ");
	cout << endl;

	// merge listB into listA
	merge(listA, listB);

	cout << "Merged list: ";
	writeDLinkedList(listA, " ");
	cout << endl;

	return 0;
}

template <typename T>
void merge(dnode<T> *list1, dnode<T> *list2)
{
	// plist1 and plist2 move through list1 and list2, respectively
	dnode<T> *plist1 = list1->next, *plist2 = list2->next, *p;

	// copy until we hit the end of list1 or list2
	while (plist1 != list1 && plist2 != list2)
	{
		// if data value in list1 smaller, advance plist1 to the next
		// element of list1
		if(plist1->nodeValue < plist2->nodeValue)
			plist1 = plist1->next;
		// data value in list1 >= value in list2, advance plist2
		// to the next element of list2. unlink the value to be merged
		// and insert it before plist1
		else
		{
			// save plist2 in p and move plist2 forward in list2
			p = plist2;
			plist2 = plist2->next;
			// unlink node p from list2
			p->prev->next = p->next;
			p->next->prev = p->prev;

			// insert the node p into list1 before node plist1
			// by performing pointer assignments
			p->prev = plist1->prev;
			p->next = plist1;
			plist1->prev->next = p;
			plist1->prev = p;
		}
	}

	// if list2 still has elements attach them to the end of list1
	if (plist2 != list2)
	{
		// attach list2 by making pointer changes

		// Step 1: link the last node of list1 and the first node
		// of list2.
		// successor of last node in list1 is 1st node of list2
		list1->prev->next = list2->next;
		// predecessor of 1st node in list2 is last node of list1
		list2->next->prev = list1->prev;

		// Step 2: link the last node of list2 with the header of list1.
		// successor of last node in list2 is the header list1
		list2->prev->next = list1;
		// predecessor of the header list1 is the last node of list2
		list1->prev = list2->prev;
	}

	// assure that list2 is empty
	list2->next = list2->prev = list2;
}

/*
Run:

listA: 2 8 12 25 33 48 55 75
listB: 1 3 6 9 12 23 33 45 55 68 88 95
Merged list: 1 2 3 6 8 9 12 12 23 25 33 33 45 48 55 55 68 75 88 95
*/
