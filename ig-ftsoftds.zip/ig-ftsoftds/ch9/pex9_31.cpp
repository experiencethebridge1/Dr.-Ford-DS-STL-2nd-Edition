#include <iostream>

#include "d_node.h"
#include "d_nodel.h"

using namespace std;

// insert item at the front of the list. scan the remainder of the list,
// deleting all nodes which are less than item
template <typename T>
void buildList(node<T> * & front, const T& item);

int main()
{
	// list initially empty
	node<int> *front = NULL;
	int i, n;

	cout << "Enter 5 integers: ";
	for (i=0;i < 5;i++)
	{
		cin >> n;
		buildList(front, n);
	}

	// output the list
	cout << "The list built from the integers is: ";
	writeLinkedList(front);
	cout << endl;

	return 0;
}

template <typename T>
void buildList(node<T> * & front, const T& item)
{
	// prev/curr move in tandem through the list
	node<T> *curr, *prev;

	// insert item at the front of the list
	front = new node<T> (item, front);

	// have curr point to the original front of the list
	curr = front->next;
	// prev is the new front
	prev = front;

	// cycle through the list and delete all nodes whose value
	// is < item
	while (curr != NULL)
	{
		if (curr->nodeValue < item)
		{
			// link prev to the successor of curr
			prev->next = curr->next;
			// delete curr
			delete curr;
			// reset curr to sucessor of prev
			curr = prev->next;
		} 
		else
		{
			// move pointers forward
			prev = curr;
			curr = curr->next;
		}
	}
}

/*
Run 1:

Enter 5 integers: 1 2 3 4 5
The list built from the integers is: 5

Run 2:

Enter 5 integers: 5 4 3 2 1
The list built from the integers is: 1 2 3 4 5

Run 3:

Enter 5 integers: 3 5 1 2 4
The list built from the integers is: 4 5
*/
