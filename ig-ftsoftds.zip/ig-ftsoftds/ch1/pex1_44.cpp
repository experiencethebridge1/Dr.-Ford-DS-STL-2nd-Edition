#include <iostream>
#include <string>

using namespace std;

int main()
{
	string word;
	char c;

	// input from cin until end-of-file
	while (true)
	{
		// input a word
		cin >> word;

		// if EOF, break
		if (!cin)
			break;

		// get word's first character
		c = word[0];
		// see if the 1st character is a vowel
		if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
			// yes. append "ay" to word
			word += "ay";
		else
		{
			// 1st character is a consonant. remove 1st character,
			// append it to the word, and then append "ay"
			word.erase(0,1);
			word += c;
			word += "ay";
		}
		cout << "Pig Latin: " << word << endl;
	}

	return 0;
}

/*
Run:

this is simple
Pig Latin: histay
Pig Latin: isay
Pig Latin: implesay
*/