#include <iostream.h>

#include "geometry.h"	// use geometry class

int main()
{
	// radius of a circle
	double r;

	cout << "Enter a radius: ";
	cin >> r;

	// declare a geometry object that represents a circle of radius r
	geometry innerCircle(r);
	// declare a square that circumscribes the circle
	geometry square(2*r, 2*r);
	// declare a circle that circumscribes the square
	geometry outerCircle(square.diagonal() / 2);

	// output the required data
	cout << "Area/perimeter of inner circle: "
		  << innerCircle.area() << " / " << innerCircle.border() << endl;
	cout << "Area/perimeter of square: "
		  << square.area() << " / " << square.border() << endl;
	cout << "Area/perimeter of outer circle: "
		  << outerCircle.area() << " / " << outerCircle.border() << endl;

	return 0;
}

/*
Run:

Enter a radius: 5
Area/perimeter of inner circle: 78.5398 / 31.4159
Area/perimeter of square: 100 / 40
Area/perimeter of outer circle: 157.08 / 44.4288
*/
