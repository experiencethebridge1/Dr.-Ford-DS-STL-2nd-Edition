#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>
#include <string>

using namespace std;

// determine whether lhs is a subset of rhs
template <typename T>
bool subset(const set<T>& lhs, const set<T>& rhs);

main()
{
	// initialize sets from the characters in the strings
	string strA = "hogtied", strB = "dog", strC = "horn";
	set<char> setA(strA.c_str(), strA.c_str()+strA.length()),
				 setB(strB.c_str(), strB.c_str()+strB.length()),
				 setC(strC.c_str(), strC.c_str()+strC.length());

	// is setB a subset of setA
	if (subset(setB, setA))
		cout << "setB is a subset of setA" << endl;
	else
		cout << "setB is not a subset of setA" << endl;

	// is setC a subset of setA
	if (subset(setC, setA))
		cout << "setC is a subset of setA" << endl;
	else
		cout << "setC is not a subset of setA" << endl;
	return 0;
}

template <typename T>
bool subset(const set<T>& lhs, const set<T>& rhs)
{
	// use const_iterators to traverse lhs/rhs because each
	// set is passed by constant reference
	set<T>::const_iterator lhsIter, rhsIter;

	// lhs cannot be a subset of rhs if it contains more elements
	// than rhs
	if (lhs.size() > rhs.size())
		return false;

	// start at the beginning of each set
	lhsIter = lhs.begin();
	rhsIter = rhs.begin();

	// move through the elements of lhs
	while (lhsIter != lhs.end())
	{
		// if *lhsIter < *rhsIter, then *lhsIter is in lhs but not in
		// rhs. return false
		if (*lhsIter < *rhsIter)
			return false;
		// if *rhsIter < *lhsIter, keep looking for *lhsIter in rhs
		else if (*rhsIter < *lhsIter)
			rhsIter++;
		else
		{
			// have a match. move both iterators forward
			lhsIter++;
			rhsIter++;
		}
	}

	// all the elements in lhs are in rhs. return true
	return true;
}

/*
Run:

setB is a subset of setA
setC is not a subset of setA
*/
