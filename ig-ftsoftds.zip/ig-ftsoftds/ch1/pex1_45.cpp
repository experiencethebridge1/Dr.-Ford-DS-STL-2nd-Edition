#include <iostream>

#include "d_time24.h"

using namespace std;

// return true if t1 is later than t2; otherwise,
// return false
bool isLater(const time24& t1, const time24& t2);

int main()
{	
	// clock is 9:00 AM
	time24 clock(9,0), fivePM(17,0);
	int minutes;

	while (!isLater(clock,fivePM))
	{
		// output the current time
		cout << "Time: ";
		clock.writeTime();
		cout << endl;

		// enter a time in minutes and increment clock
		cout << "Enter an increment in minutes: ";
		cin >> minutes;
		clock.addTime(minutes);
	}

	cout << "Final time: ";
	clock.writeTime();
	cout << endl;

	return 0;
}

bool isLater(const time24& t1, const time24& t2)
{
	// compare the times in minutes
	return (t1.getHour()*60 + t1.getMinute()) >
			 (t2.getHour()*60 + t2.getMinute());
}

/*
Run:

Time:  9:00
Enter an increment in minutes: 300
Time: 14:00
Enter an increment in minutes: 150
Time: 16:30
Enter an increment in minutes: 25
Time: 16:55
Enter an increment in minutes: 3
Time: 16:58
Enter an increment in minutes: 2
Time: 17:00
Enter an increment in minutes: 5
Final time: 17:05
*/
