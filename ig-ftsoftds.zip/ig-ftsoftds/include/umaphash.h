#ifndef UMAPHASHKEY_CLASS
#define UMAPHASHKEY_CLASS

// a hash function object type that applies KeyHashFunc
// to the key in a miniPair object
template <typename Key, typename T, typename KeyHashFunc>
class umapHashKey
{
	public:
		unsigned int operator()(const miniPair<const Key, T>& item) const
		{
			return KeyHashFunc()(item.first);
		}
};

#endif	// UMAPHASHKEY_CLASS
