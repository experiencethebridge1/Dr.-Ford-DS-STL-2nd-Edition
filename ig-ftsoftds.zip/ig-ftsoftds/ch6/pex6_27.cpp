#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <list>
#include <string>

using namespace std;

// return an iterator pointing to the largest element
// in the list
template <typename T>
list<T>::iterator maxLoc(list<T>& aList);

int main()
{
	string strArr[] = {"insert", "erase", "template", "list"};
	list<string> strList(strArr, strArr+4);
	list<string>::iterator iter;

	while (!strList.empty())
	{
		iter = maxLoc(strList);
		cout << *iter << "  ";
		strList.erase(iter);
	}
	cout << endl;

   return 0;
}

template <typename T>
list<T>::iterator maxLoc(list<T>& aList)
{
	// iter moves through the list, and maxIter points to
	// the largest value found so far
	list<T>::iterator iter, maxIter;

	// if the list is emtpy, return aList.end()
	if (aList.empty())
		return aList.end();

	// assign iter and maxIter to point at the first list value.
	// *maxIter is the starting guess for the maximum list value
	iter = maxIter = aList.begin();

	// advance iter to the second list value.
	iter++;

	// advance through the remainder of the list and update
	// maxIter so it points to the largest value
	while (iter != aList.end())
	{
		if (*iter > *maxIter)
			maxIter = iter;
		iter++;
	}

	// return the iterator pointing to the largest value
	return maxIter;
}

/*
Run:

template  list  insert  erase
*/
