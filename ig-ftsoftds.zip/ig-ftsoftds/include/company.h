#ifndef COMPANY_CLASS
#define COMPANY_CLASS

#include <iostream>
#include <string>

using namespace std;

class company
{
	public:
		company(const string& nm = "", const string& prod = ""):
					name(nm), product(prod)
		{}

		string getName()
		{ return name; }

		string getProduct()
		{ return product; }

		// compare using the company name
		friend bool operator< (const company& lhs, const company& rhs)
		{
			return lhs.name < rhs.name;
		}

		friend bool operator== (const company& lhs, const company& rhs)
		{
			return lhs.name == rhs.name;
		}

		// output in format "name product"
		friend ostream& operator<< (ostream& ostr, const company& comp)
		{
			ostr << comp.name << ' ' << comp.product;

			return ostr;
		}

	 private:
		string name;
		string product;
};

#endif	// COMPANY_CLASS
