#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>

#include "d_graph.h"
#include "d_util.h"

using namespace std;

int main()
{	
	graph<char> g;
	// use to traverse the vertices of g
	graph<char>::iterator giter;
	// minimum path of the current vertex and
	// the path whose minimum weight is largest
	// so far
	list<char> minPath, maxMinPath;
	ifstream fin;
	// ending vertex for the minimum paths and
	// the current starting vertex with the
	// greatest minimum path distance to vertex
	char vertex, maxMinVertex;
	// current minimum path distance to vertex
	// and the largest distance so far
	int minPathDistance, maxMinPathDistance = 0;

	fin.open("graphB.dat");
	fin >> g;

	cout << "Enter a vertex: ";
	cin >> vertex;

	// traverse the vertices of g
	giter = g.begin();
	while (giter != g.end())
	{
		// only consider vertices other than g
		if (*giter != vertex)
		{
			// compute minimum path from *giter to vertex
			minPathDistance = minimumPath(g, *giter, vertex, minPath);

			// see if we have found a longer minimum path distance
			if (minPathDistance > maxMinPathDistance)
			{
				// record the vertex, the distance, and the path
				maxMinVertex = *giter;
				maxMinPathDistance = minPathDistance;
				maxMinPath = minPath;
			}
		}

		giter++;
	}

	// output the results
	cout << "Vertex with largest minimum-path value = "
		  << maxMinVertex << endl
		  << "Minimum-path value = " << maxMinPathDistance
		  << endl << "Minimum path = ";
	writeContainer(maxMinPath.begin(), maxMinPath.end());
	cout << endl;

	return 0;
}

/*
Run:

Enter a vertex: E
Vertex with largest minimum-path value = A
Minimum-path value = 20
Minimum path = A  B  C  D  F  E
*/
