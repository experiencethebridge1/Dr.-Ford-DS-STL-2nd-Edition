#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <set>
#include <string>

#include "d_setops.h"

using namespace std;

// determine whether lhs is a subset of rhs
template <typename T>
bool subset(const set<T>& lhs, const set<T>& rhs);

main()
{
	// initialize sets from the characters in the strings
	string strA = "hogtied", strB = "dog", strC = "horn";
	set<char> setA(strA.c_str(), strA.c_str()+strA.length()),
				 setB(strB.c_str(), strB.c_str()+strB.length()),
				 setC(strC.c_str(), strC.c_str()+strC.length());

	// is setB a subset of setA
	if (subset(setB, setA))
		cout << "setB is a subset of setA" << endl;
	else
		cout << "setB is not a subset of setA" << endl;

	// is setC a subset of setA
	if (subset(setC, setA))
		cout << "setC is a subset of setA" << endl;
	else
		cout << "setC is not a subset of setA" << endl;
	return 0;
}

template <typename T>
bool subset (const set<T>& lhs, const set<T>& rhs)
{
	// use the set operation * for intersection
	return lhs * rhs == lhs;
}

/*
Run:

setB is a subset of setA
setC is not a subset of setA
*/
