#ifdef __BORLANDC__
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
#endif	// __BORLANDC__

#include <iostream>
#include <vector>

#include "d_util.h"

using namespace std;

// reverse the order of the elements in v
template <typename T>
void reverseVector(vector<T>& v);

int main()
{
	int arr[] = {9, 12, 6, 24, 16, 8, 3, 19, 11, 4};
	int arrSize = sizeof(arr)/sizeof(int);
	vector<int> v(arr, arr+arrSize);

	// reverse v and output the modified vector
	reverseVector(v);
	writeVector(v);

   return 0;
}

template <typename T>
void reverseVector(vector<T>& v)
{
	T temp;
	int i, j;

	i = 0;
	j = v.size()-1;
	// exchange elements v[i] and v[j] until i >= j
	while (i < j)
	{
		temp = v[i];
		v[i] = v[j];
		v[j] = temp;

		// move i up and j down
		i++;
		j--;
	}
}

/*
Run:

4  11  19  3  8  16  24  6  12  9
*/
