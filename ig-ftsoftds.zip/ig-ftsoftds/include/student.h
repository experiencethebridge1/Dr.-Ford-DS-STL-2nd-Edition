#ifndef STUDENT_STUDENTATHLETE_CLASSES
#define STUDENT_STUDENTATHLETE_CLASSES

#include <iostream>
#include <string>

using namespace std;

class student
{
	public:
		// constructor. initialize the string data
		student(const string& name, const string& ssn):
			studSSN(ssn), studName(name)
		{}

		// output the name and ssn
		virtual void identify()
		{
			cout << "Student " << studName << "    "
				  << "Social Security Number " << studSSN
				  << endl;
		}

	protected:
		string studName, studSSN;
};

class studentAthlete: public student
{
	public:
		// constructor. initialize base class and studSport
		studentAthlete(const string& name, const string& ssn,
							const string& sport):
			student(name, ssn), studSport(sport)
		{}

		// derived class version of identify(). call the base class
		// version and output the sport
		virtual void identify()
		{
			student::identify();
			cout << "Sport " << studSport << endl;
		}

	protected:
		string studSport;
};

#endif	// STUDENT_STUDENTATHLETE_CLASSES
