#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>

#include "d_graph.h"
#include "d_util.h"

using namespace std;

int main()
{
	graph<char> g;
	set<char> neighbors;
	ifstream fin;
	char vertex;

	fin.open("graphA.dat");
	fin >> g;

	// insert edge (F,D)
	g.insertEdge('F', 'D', 1);
	// erase vertex B
	g.eraseVertex('B');
	// erase edge (A,D)
	g.eraseEdge('A', 'D');

	// prompt for a vertex and output its neighbors
	cout << "Enter a vertex: ";
	cin >> vertex;

	neighbors = g.getNeighbors(vertex);
	cout << "Neighbors of " << vertex << ": ";
	writeContainer(neighbors.begin(), neighbors.end());
	cout << endl;

	// insert new vertex G
	g.insertVertex('G');
	// add edges from and to G
	g.insertEdge('G', 'C', 1);
	g.insertEdge('G', 'F', 1);
	g.insertEdge('D', 'G', 1);

	// output the revised graph
	cout << g;

	return 0;
}

/*
Run:

Enter a vertex: C
Neighbors of C: A  F
A: in-degree 2  out-degree 0
    Edges:
G: in-degree 1  out-degree 2
    Edges: C (1)  F (1)
C: in-degree 2  out-degree 2
    Edges: A (1)  F (1)
D: in-degree 1  out-degree 2
    Edges: G (1)  E (1)
E: in-degree 1  out-degree 1
    Edges: A (1)
F: in-degree 2  out-degree 2
    Edges: C (1)  D (1)
*/
