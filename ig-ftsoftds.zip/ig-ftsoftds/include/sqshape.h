#ifndef SQUARESHAPE_CLASS
#define SQUARESHAPE_CLASS

#include "d_rectsh.h"

// declaration of squareShape class with base class rectShape
class squareShape: public rectShape
{
   public:
		// constructor sets base point, length of side, and color 
		squareShape(double xpos = 0.0, double ypos = 0.0,
                  double side = 0.0, shapeColor c = darkgray):
   		rectShape(xpos, ypos, side, side, c)
		{}

		// squareShape data access and update functions
		double getSide() const
		{
			// call base class function
			return getLength();
		}

		void setSide(double s)
		{
			// call base class function to set length
			// and width to s
			setSides(s,s);
		}
};

#endif	// SQUARESHAPE_CLASS
