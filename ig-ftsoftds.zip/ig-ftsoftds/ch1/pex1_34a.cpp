#include <iostream>

#include "accum.h"

using namespace std;

int main()
{
	accumulator	obj;

	cout << obj.getTotal() << endl;
	obj.addValue(3);
	obj.addValue(obj.getTotal()+3);
	cout << obj.getTotal() << endl;

	// using the constructor, create an object and 
	// assign it to obj
	obj = accumulator(8);
	obj.addValue();
	cout << obj.getTotal() << endl;

	return 0;
}

/*
Run:

0
9
9
*/
