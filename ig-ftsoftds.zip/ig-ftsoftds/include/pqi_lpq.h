#ifndef PQ_INTERFACE_AND_LISTPQ
#define PQ_INTERFACE_AND_LISTPQ

template <typename T>
class priorityQInterface
{
	public:
		virtual bool empty() const = 0;
			// check whether the priority queue is empty.
			// return true if it is empty, and false otherwise

		virtual void pop() = 0;
			// remove item of highest priority from the priority queue.
			// Precondition: the priority queue is not empty.
			// Postcondition: the priority queue has one less element

		virtual void push(const T& item) = 0;
			// insert the argument item into the priority queue.	
			// Postcondition:	the priority queue contains a new element
			
		virtual int size() const = 0;
			// return the number of items in the priority queue

		virtual T& top() = 0;
			// return a reference to the element having the highest priority.
			// Precondition: the priority queue is not empty

		virtual const T& top() const = 0;
			// constant version of top()
};

#include "d_orderl.h"
#include "d_except.h"

template <typename T>
class listPriorityQ: public priorityQInterface<T>
{
	public:
		bool empty() const;
		void pop();
		void push(const T& item);			
		int size() const;
		T& top();
		const T& top() const;

	private:
		// implements the priority queue
		orderedList<T> pqList;
};

template <typename T>
bool listPriorityQ<T>::empty() const
{
	// priority queue is empty if pqList is empty
	return pqList.empty();
}

template <typename T>
void listPriorityQ<T>::pop()
{
	if (pqList.size() == 0)
		throw underflowError("listPriorityQ top(): queue empty");

	// remove the highest priority element, which is at the back
	// of pqList
	pqList.pop_back();
}

template <typename T>
void listPriorityQ<T>::push(const T& item)
{
	// insert item into the ordered list
	pqList.insert(item);
}
	
template <typename T>
int listPriorityQ<T>::size() const
{
	// return size of pqList
	return pqList.size();
}

template <typename T>
T& listPriorityQ<T>::top()
{
	if (pqList.size() == 0)
		throw underflowError("listPriorityQ top(): queue empty");

	// highest priority element is the largest, which is at the back
	// of pqList
	return pqList.back();
}

template <typename T>
const T& listPriorityQ<T>::top() const
{
	if (pqList.size() == 0)
		throw underflowError("listPriorityQ top(): queue empty");

	// highest priority element is the largest, which is at the back
	// of pqList
	return pqList.back();
}

#endif	// PQ_INTERFACE_AND_LISTPQ
