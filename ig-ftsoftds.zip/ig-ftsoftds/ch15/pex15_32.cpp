#include <iostream>

#include "nqueens.h"

using namespace std;

int main ()
{
	// n is number of queens
	int n, row;

	cout << "Input the number of queens: ";
	cin >> n;

	// enter a starting row for queen in column 0
	cout << "Enter the row for the queen in column 0: ";
	cin >> row;
	cout << endl;

	vector<int> queenList(n);
	chessBoard board(n);

	// see if there is a solution
	if (queens(queenList, row, n))
	{
		board.setQueens(queenList);
		// display the solution
		board.drawBoard();
	}
	else
		cout << "No solution" << endl;

	return 0;
}

/*
Run 1:

Input the number of queens: 10
Enter the row for the queen in column 0: 5

     0  1  2  3  4  5  6  7  8  9
 0   -  Q  -  -  -  -  -  -  -  -
 1   -  -  -  -  -  Q  -  -  -  -
 2   -  -  Q  -  -  -  -  -  -  -
 3   -  -  -  -  -  -  Q  -  -  -
 4   -  -  -  -  -  -  -  -  -  Q
 5   Q  -  -  -  -  -  -  -  -  -
 6   -  -  -  -  -  -  -  -  Q  -
 7   -  -  -  -  Q  -  -  -  -  -
 8   -  -  -  -  -  -  -  Q  -  -
 9   -  -  -  Q  -  -  -  -  -  -

Run 2:

Input the number of queens: 6
Enter the row for the queen in column 0: 0

No solution
*/