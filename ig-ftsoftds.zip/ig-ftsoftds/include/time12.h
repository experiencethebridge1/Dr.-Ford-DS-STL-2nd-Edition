#ifndef TIME12_CLASS
#define TIME12_CLASS

#include <iostream>
#include <string>

#include "d_time24.h"

using namespace std;

// specifies clock time units
enum timeUnit {AM, PM};

// maintains clock time
class time12
{
	private:
		time24 t;
			// store time in 24-hour format

      time24 convert12To24(int h, int m, timeUnit tunit);
	      // build t from standard time
	public:
		time12(int h=12, int m=0, timeUnit tunit = AM);
			// initialize time24 data member t

		void addTime(int m);
			// add m minutes to update current time

		void readTime();
		void writeTime();
	      // I/O member functions use format HH:MM: AM (PM)
};

// take standard time and return the equivalent 24-hour time
time24 time12::convert12To24(int h, int m, timeUnit tunit)
{
	if (tunit == AM)
		// % maps 12 to 0
      return time24(h%12, m);			// AM hours
   else
		// map 12 to 0; add 12 so the hour in range 12 to 23
      return time24(h%12 + 12, m);	// PM hours
}

// constructor. initialize the time24 object t by converting
// from 12-hour to 24-hour time
time12::time12(int h, int m, timeUnit tunit)
{
   t = convert12To24(h,m,tunit);
}

// add m minutes to the current time
void time12::addTime(int m)
{
	t.addTime(m);
}

// read time in the format HH:MM <AM or PM unit>
void time12::readTime()
{
   // objects h, m, timeLabel, separator used to read the time
   int h, m;
   string timeLabel;
   char separator;   // use to discard ':'
   timeUnit tunit;   // use to create time24 object t

   cin >> h >> separator >> m >> timeLabel;

   // determine timeUnit equivalent of the string timeLabel
	if (timeLabel == "AM")
      tunit = AM;
   else
      tunit = PM;

   // build object t
   t = convert12To24(h,m,tunit);
}

// output time in the format HH:MM <AM or PM unit>
void time12::writeTime()
{
   // save current format flags and fill character
   long currentFlags = cout.flags();
   char currentFill = cout.fill();
   int hour, minute;

   // set fill char to '0' and enable right justification
   cout.fill('0');
   cout.setf(ios::right,ios::adjustfield);

   // retrieve the hour and minute of current time
   hour = t.getHour();
   minute = t.getMinute();

   // 0 through 11 is AM
   if (hour < 12)
   {
      if (hour == 0) // 0 is 12 AM
         hour = 12;
      cout << hour << ':';
      cout << setw(2) << minute
           << " AM";
   }
   else              // 12 through 23 is PM
   {
      hour -= 12;    // 12->0, 13->1, ..., 23->11
      if (hour == 0) // 0 is 12 PM
         hour = 12;
      cout << hour << ':';
      cout << setw(2) << minute
           << " PM";
   }

   // restore the fill char and the format flags
   cout.fill(currentFill);
   cout.setf(currentFlags);
}

#endif   // TIME12_CLASS
