#include <iostream>
#include <queue>

#include "d_random.h"

using namespace std;

int main()
{
	// declare an integer priority queue
	priority_queue<int> pq;
	randomNumber rnd;
	int i, count;

	// push 15 random numbers in the range from 0 to 4
	// onto the priority queue
	for (i=0;i < 15;i++)
		pq.push(rnd.random(5));

	// output the number of occurrences of i in pq
	for (i=4;i >= 0;i--)
	{
		// initialize count of number of occurrences of i
		// as 0
		count = 0;
		// count as long as the queue is not empty and the
		// largest value is i
		while (!pq.empty() && pq.top() == i)
		{
			count++;
			pq.pop();
		}
		// output i and the count
		cout << i << '(' << count << ')' << "  ";
	}
	cout << endl;

	return 0;
}

/*
Run 1:

4(3)  3(1)  2(2)  1(4)  0(5)

Run 2:

4(3)  3(4)  2(5)  1(0)  0(3)
*/
