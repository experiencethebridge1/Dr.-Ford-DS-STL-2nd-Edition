#ifdef _MSC_VER
// disable warning messages that identifier was truncated
// to 'number' characters in the debug information
#pragma warning(disable:4786)
#endif	// _MSC_VER

#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

#include "d_graph.h"
#include "d_matrix.h"

using namespace std;

// return the reachability matrix for graph g
template <typename T>
matrix<int> reachMat(graph<T>& g);

int main()
{
	// vertices are characters
	graph<char> g;
	// use to label the rows and columns of the reachability matrix
	graph<char>::iterator giter;
	// reachability matrix
	matrix<int> rm;
	ifstream graphIn;
	string fileName;
	int i, j;

	cout << "Enter the graph file name: ";
	cin >> fileName;

	graphIn.open(fileName.c_str());

	graphIn >> g;

	// compute the matrix
	rm = reachMat(g);

	cout << "Reachability matrix:" << endl << endl;

	// output the column labels
	giter = g.begin();
	cout << "  ";
	while (giter != g.end())
	{
		cout << setw(4) << *giter;
		giter++;
	}
	cout << endl;

	// output the matrix and the row labels
	giter = g.begin();
	for (i=0;i < rm.rows();i++)
	{
		cout << setw(2) << *giter;
		giter++;

		for (j=0;j < rm.cols();j++)
			cout << setw(4) << rm[i][j];
		cout << endl;
	}

	return 0;
}

template <typename T>
matrix<int> reachMat(graph<T>& g)
{
	// use to construct the rows and columns of the
	// reachability matrix
	graph<T>::iterator rowIter, colIter;
	// assigned the vertices reachable from the vertex
	// corresponding the the current row of the matrix
	set<T> reachSet;
	int n = g.numberOfVertices(), i, j;
	// the reachability matrix
	matrix<int> mat(n,n);

	// rowIter points to the first vertex, and i references
	// row 0
	rowIter = g.begin();
	i = 0;
	// each vertex generates a row of the matrix
	while (rowIter != g.end())
	{
		// use breadth-first search to determine all vertices
		// reachable from *rowIter
		reachSet = bfs(g, *rowIter);

		// construct the elements or row i, beginning at column j
		j = 0;
		// iterate through the graph vertices and see which ones are
		// reachable from *rowIter
		colIter = g.begin();
		while (colIter != g.end())
		{
			// if *colIter is in the set of vertices reachable from
			// *rowIter, the matrix entry is 1; otherwise it is 0
			if (reachSet.find(*colIter) != reachSet.end())
				mat[i][j] = 1;
			else
				mat[i][j] = 0;

			// advance the iterator and the column index
			colIter++;
			j++;
		}

		// advance row iterator and the row index
		rowIter++;
		i++;
	}

	return mat;
}

/*
Run 1:

Enter the graph file name: 16-38_r1.dat
Reachability matrix:

     A   B   C   D   E   F
 A   1   1   1   1   1   1
 B   1   1   1   1   1   1
 C   1   1   1   1   1   1
 D   1   1   1   1   1   1
 E   0   0   0   0   1   1
 F   0   0   0   0   1   1

Run 2:

Enter the graph file name: graphB.dat
Reachability matrix:

     A   B   C   D   E   F
 A   1   1   1   1   1   1
 B   1   1   1   1   1   1
 C   1   1   1   1   1   1
 D   0   0   0   1   1   1
 E   0   0   0   0   1   1
 F   0   0   0   0   1   1

Run 3:

Enter the graph file name: graphA.dat
Reachability matrix:

     A   B   C   D   E   F
 A   1   1   1   1   1   1
 B   1   1   1   1   1   1
 C   1   1   1   1   1   1
 D   1   1   1   1   1   1
 E   1   1   1   1   1   1
 F   1   1   1   1   1   1
*/
