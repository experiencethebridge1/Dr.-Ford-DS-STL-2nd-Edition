#ifndef DUALSTACK_CLASS
#define DUALSTACK_CLASS

#include <deque>

#include "d_except.h"

using namespace std;

enum stackNumber {One, Two};

template <typename T>
class dualStack
{
	public:
		dualStack();
			// constructor. set counts to 0

		void push(const T& item, stackNumber n);
		void pop(stackNumber n);

		T& top(stackNumber n);
		const T& top(stackNumber n) const;

		bool empty(stackNumber n) const;
		int size(stackNumber n) const;

	private:
		deque<T> dualStackElements;
		int count1, count2;
};

template <typename T>
dualStack<T>::dualStack(): count1(0), count2(0)
{}

template <typename T>
void dualStack<T>::push(const T& item, stackNumber n)
{
	if (n == One)
	{
		// stack One. push on the front of the deque and
		// increment count1
		dualStackElements.push_front(item);
		count1++;
	}
	else
	{
		// stack One. push on the back of the deque and
		// increment count2
		dualStackElements.push_back(item);
		count2++;
	}
}

template <typename T>
void dualStack<T>::pop(stackNumber n)
{
	if (n == One)
	{
		// if stack One is empty, throw underflowError exception
		if (count1 == 0)
			throw underflowError("dualStack pop(): stack One empty");
		// pop the front of the deque and decrement count1
		dualStackElements.pop_front();
		count1--;
	}
	else
	{
		// if stack Two is empty, throw underflowError exception
		if (count2 == 0)
			throw underflowError("dualStack pop(): stack Two empty");
		// pop the back of the deque and decrement count2
		dualStackElements.pop_back();
		count2--;
	}
}

template <typename T>
T& dualStack<T>::top(stackNumber n)
{
	if (n == One)
	{
		// if stack One is empty, throw underflowError exception
		if (count1 == 0)
			throw underflowError("dualStack top(): stack One empty");
		// return the front of the deque
		return dualStackElements.front();
	}
	else
	{
		// if stack Two is empty, throw underflowError exception
		if (count2 == 0)
			throw underflowError("dualStack top(): stack Two empty");
		// return the back of the deque
		return dualStackElements.back();
	}
}

template <typename T>
const T& dualStack<T>::top(stackNumber n) const
{
	if (n == One)
	{
		// if stack One is empty, throw underflowError exception
		if (count1 == 0)
			throw underflowError("dualStack top(): stack One empty");
		// return the front of the deque
		return dualStackElements.front();
	}
	else
	{
		// if stack Two is empty, throw underflowError exception
		if (count2 == 0)
			throw underflowError("dualStack top(): stack Two empty");
		// return the back of the deque
		return dualStackElements.back();
	}
}

template <typename T>
bool dualStack<T>::empty(stackNumber n) const
{
	if (n == One)
		return count1 == 0;
	else
		return count2 == 0;
}

template <typename T>
int dualStack<T>::size(stackNumber n) const
{
	if (n == One)
		return count1;
	else
		return count2;
}

#endif	// DUALSTACK_CLASS
