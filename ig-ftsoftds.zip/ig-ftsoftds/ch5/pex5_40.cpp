#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
// suppress the warning message that Borland's <vector> contains
// a condition that is always false
#pragma warn -8008
// suppress the warning message that Borland's <vector> contains
// unreachable code
#pragma warn -8066
#endif	// __BORLANDC__

#include <iostream>
#include <vector>

#include "dynt.h"

using namespace std;

template <typename T>
dynamicType<T> sum(const vector<dynamicType<T> >& v);

int main()
{
	dynamicType<int> arr[5] = {
		dynamicType<int> (3), dynamicType<int> (5),
		dynamicType<int> (8), dynamicType<int> (7),
		dynamicType<int> (2) };
	vector<dynamicType<int> > v(arr, arr+5);

	cout << sum(v) << endl;

	return 0;
}

template <typename T>
dynamicType<T> sum(const vector<dynamicType<T> >& v)
{
	T sum = T();
	int i;

	for (i=0;i < v.size(); i++)
		sum += v[i].getData();

	return dynamicType<T> (sum);
}

/*
Run:

25
*/
