#ifdef __BORLANDC__
// suppress the warning message about comparing signed and unsigned values
#pragma warn -8012
#endif	// __BORLANDC__

#include <iostream>
#include <stack>
#include <string>

#ifdef _MSC_VER
// compensates for VC++ 6.0 bug in getline() from <string>
#include "d_util.h"
#endif	// _MSC_VER

using namespace std;

int main()
{
	stack<int> s;
	string str;
	int poundIndex, i;
	bool matches;

	cout << "Input a string: ";
	// input a line of text
	getline(cin, str);
	// continue until the empty string is typed
	while (str.length() != 0)
	{
		// assume there is exactly one '#' in str.
		// find its index
		poundIndex = str.find_first_of('#');

		// for the string to match the pattern, there must
		// be exactly 2*poundIndex+1 characters in the string
		if (str.length() == 2*poundIndex+1)
		{
			// verify that the string matches the pattern.
			// push all characters in the index range
			// [poundIndex+1,str.length()) onto the stack
			for (i=poundIndex+1;i < str.length();i++)
				s.push(str[i]);

			// pop the stack and compare each character with
			// the corresponding one from the front of the
			// string in the range [0, poundIndex)
			for (i=0;i < poundIndex;i++)
			{
				// if the two characters don't match, the
				// the string does not exhibit the pattern
				if (s.top() != str[i])
					break;
				s.pop();
			}

			// match if the for completed; otherwise,
			// there is not a match
			if (i == poundIndex)
				matches = true;
			else
				matches = false;
		}
		else
			// string the wrong length. no match
			matches = false;

		// output the result
		if (matches)
			cout << str << " matches the pattern" << endl;
		else
			cout << str << " does not match the pattern" << endl;

		cout << endl;
		// get the next string
		cout << "Input a string: ";
		getline(cin, str);
	}

	return 0;
}

/*
Run:

Input a string: 1&A#A&1
1&A#A&1 matches the pattern

Input a string: 1&A#1&A
1&A#1&A does not match the pattern

Input a string: madamimadam#madamimadam
madamimadam#madamimadam matches the pattern

Input a string:
*/
