#ifndef GRAPH_CLASS
#define GRAPH_CLASS

#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <stack>
#include <queue>

#include "d_except.h"
#include "d_matrix.h"

using namespace std;

const int MAXGRAPHSIZE = 25;

// maintains vertex properties, including its set of
// neighbors
template <typename T>
class vertexInfo
{
	public:
		// used by graph algorithms
		enum vertexColor { WHITE, GRAY, BLACK };

		// iterator pointing at a pair<T,int> object in the vertex map
		map<T,int>::iterator vtxMapLoc;

		/// maintains the in-degree of the vertex
		int inDegree;

		/// maintains the out-degree of the vertex
		int outDegree;

		// indicates whether the object currently represents a vertex
		bool occupied;

		// indicate if a vertex is marked in an algorithm that traverses
		// the vertices of a graph
		vertexColor color;

		// available to algorithms for storing relevant data values
		int dataValue;

		// available to graph algorithms; holds parent which is
		// a vertex that has an edge terminating in the current vertex
		int parent;

		// default constructor
		vertexInfo(): inDegree(0), outDegree(0), occupied(true)
		{}

		// constructor with iterator pointing to the vertex in the map
		vertexInfo(map<T,int>::iterator iter):
				vtxMapLoc(iter), inDegree(0), outDegree(0), occupied(true)
		{}
};

template <typename T>
class graph
{
   public:

      class const_iterator: public map< T, int >::const_iterator
      {
         public:
            const_iterator()
            {}

				// converts a map iterator to a graph iterator
            const_iterator(map<T,int>::const_iterator i)
            {
					*((map< T, int >::const_iterator *)this) = i;
				}

				// return the vertex pointed to by the iterator
            const T& operator* () const
            {
               map<T,int>::const_iterator p = *this;

               return (*p).first;
            }
      };

		typedef const_iterator iterator;

		graph();
			// constructor. initialize numVertices and numEdges to 0

		graph(const graph<T>& g);
			// copy constructor

		graph<T>& operator= (const graph<T>& rhs);
			// overloaded assignment operator

		int numberOfVertices() const;
			// return the number of vertices in the graph

		int numberOfEdges() const;
			// return the number of edges in the graph

      bool empty() const;
			// is the graph empty?

		int getWeight(const T& v1, const T& v2) const;
			// return the weight of the edge (v1, v2). if the edge.
			// does not exist, return -1
			// Precondition: v1 and v2 are vertices in the graph. if not
			// the function throws the graphError exception

		void setWeight(const T& v1, const T& v2, int w);
			// update the weight of edge (v1, v2).
			// Precondition: v1 and v2 are vertices in the graph. if not,
			// the function throws the graphError exception
			// Postcondition: the weight of vertex (v1,v2) is w

		int inDegree(const T& v) const;
			// return the number of edges entering  v.
			// Precondition: v is a vertex in the graph. if not,
			// the function throws the graphError exception

		int outDegree(const T& v) const;
			// return the number of edges leaving  v.
			// Precondition: v is a vertex in the graph. if not,
			// the function throws the graphError exception

      set<T> getNeighbors(const T& v) const;
			// return a set containing the neighbors of v.
			// Precondition: v is a vertex in the graph. if not,
			// the function throws the graphError exception

		void insertEdge(const T& v1, const T& v2, int w);
			// add the edge (v1,v2) with specified weight to the graph.
			// Precondition: v1 and v2 are vertices in the graph. if not,
			// the function throws the graphError exception
			// Postcondition: The number of edges increases by 1

		void insertVertex(const T& v);
			// insert v into the graph.
			// Precondition: v is a vertex in the graph. if not,
			// the function throws the graphError exception.
			// Postcondition: the number of vertices increases by 1

		void eraseEdge(const T& v1, const T& v2);
			// erase edge (v1,v2) from the graph
			// Precondition: v1 and v2 are vertices in the graph. if not,
			// the function throws the graphError exception.
			// Postcondition: The number of edges decreases by 1

      void eraseVertex(const T& v);
			// erase v from the graph
			// Precondition: v is a vertex in the graph. if not,
			// the function throws the graphError exception.
			// Postconditions: The number of vertices decreases by 1,
			// and the operation removes all edges to or from v

		void clear();
			// remove all the vertices and edges from the graph

		iterator begin();
		iterator end();
		const_iterator begin() const;
		const_iterator end() const;
			// iterator functions returns corresponding map iterator

// "adjgalgs.h" implements the graph algorithms using inline code.
// this is necessary for the Borland C++ 5.5 compiler
#include "adjgalgs.h"

/*
		LISTING OF THE PROTOTYPES FOR THE GRAPH ALGORITHMS

		friend istream& operator>> (istream& istr, graph<T>& g);
			// input a graph

		friend ostream& operator<< (ostream& ostr, const graph<T>& g);
			// output a graph

		friend set<T> bfs(graph<T>& g, const T& sVertex);
			// perform the breadth-first traversal from sVertex and
			// return the set of visited vertices

*/

   private:
      typedef map<T,int> vertexMap;

		vertexMap vtxMap;
			// store vertex in a map with its name as the key and the index
			// of the corresponding vertexInfo object in the vInfo
			// vector as the value

      // adjacency matrix
      matrix<int> edge;

		int numVertices;
		int numEdges;
			// current size (vertices and edges) of the graph

		vector<vertexInfo<T> > vInfo;
			// list of vertexInfo objects corresponding to the vertices

		stack<int> availStack;
			// availability stack for storing unused indices in vInfo

      int getVertexPos(const T& vertex) const;
      	// member function to find vertex and identify its row
      	// in the adjacency matrix and its index in vInfo
};

template <typename T>
int graph<T>::getVertexPos(const T& v) const
{
	// iter used in map lookup
	vertexMap::const_iterator iter;
	// index that is returned
	int pos;

	// find the map entry with key v
	iter = vtxMap.find(v);

	// make sure v is in the map
	if (iter == vtxMap.end())
		pos = -1;
	else
		// the index into vInfo is the value of the map entry
		pos = (*iter).second;

	return pos;
}

template <typename T>
graph<T>::graph():
	edge(MAXGRAPHSIZE,MAXGRAPHSIZE,0), numVertices(0), numEdges(0)
{}

template <typename T>
graph<T>::graph(const graph<T>& g)
{
	*this = g;	// copy g to current object
}

// overloaded assignment operator
template <typename T>
graph<T>& graph<T>::operator= (const graph<T>& rhs)
{
	vertexMap::iterator mi;

	// can't copy a graph to itself
	if (this == &rhs)
		return *this;

	// copy rhs to current object
	vtxMap = rhs.vtxMap;
	vInfo = rhs.vInfo;
	numVertices = rhs.numVertices;
	numEdges = rhs.numEdges;
	edge = rhs.edge;
	availStack = rhs.availStack;

	// update each vtxMapLoc value of objects in vInfo so it points
	// to a key-value pair in the copy of rhs.vtxMap and not rhs.vtxMap
	for (mi=vtxMap.begin();mi != vtxMap.end();mi++)
			vInfo[(*mi).second].vtxMapLoc = mi;

	return *this;
}

template <typename T>
int graph<T>::numberOfVertices() const
{
   return numVertices;
}

template <typename T>
int graph<T>::numberOfEdges() const
{
   return numEdges;
}

template <typename T>
bool graph<T>::empty() const
{
   return numVertices == 0;
}

template <typename T>
int graph<T>::getWeight(const T& v1, const T& v2) const
{
   int pos1=getVertexPos(v1), pos2=getVertexPos(v2);

   if (pos1 == -1 || pos2 == -1)
		throw graphError("getWeight(): a vertex is not in the graph.");

   return edge[pos1][pos2];
}

template <typename T>
void graph<T>::setWeight(const T& v1, const T& v2, int w)
{
   int pos1=getVertexPos(v1), pos2=getVertexPos(v2);

   if (pos1 == -1 || pos2 == -1)
		throw graphError("setWeight(): a vertex is not in the graph.");

	// if the edge exists, assign the new weight; otherwise,
	// throw an exception
	if (edge[pos1][pos2] != 0)
		edge[pos1][pos2] = w;
	else
		throw graphError("graph setWeight(): edge not in the graph");
}

template <typename T>
int graph<T>::inDegree(const T& v) const
{
	// find the vInfo index for v
	int pos=getVertexPos(v);

	if (pos != -1)
		// in-degree is stored in vInfo[pos]
		return vInfo[pos].inDegree;
	else
		// throw an exception
		throw graphError("graph inDegree(): vertex not in the graph");
}

template <typename T>
int graph<T>::outDegree(const T& v) const
{
	// find the vInfo index for v
	int pos=getVertexPos(v);

	if (pos != -1)
		// out-degree is number of elements in the edge set
		return vInfo[pos].outDegree;
	else
		// throw an exception
		throw graphError("graph outDegree(): vertex not in the graph");
}

// return the list of all adjacent vertices
template <typename T>
set<T> graph<T>::getNeighbors(const T& v) const
{
	// set returned
	set<T> adjVertices;
   vertexMap::const_iterator vListIter;

   // look up pos in list to identify row in adjacency matrix
   int pos = getVertexPos(v);

   // if vertex not in list of vertices, terminate
   if (pos == -1)
      throw graphError("getNeighbors(): the vertex is not in the graph.");

   // include all vertices having a non-zero weighted edge
   // from v
   for(vListIter = vtxMap.begin();
          vListIter != vtxMap.end(); vListIter++)
      if (edge[pos][(*vListIter).second] > 0)
         adjVertices.insert((*vListIter).first);

   return adjVertices;
}

template <typename T>
void graph<T>::insertEdge(const T& v1,
                          const T& v2, int weight)
{
   int pos1=getVertexPos(v1), pos2=getVertexPos(v2);

   if (pos1 == -1 || pos2 == -1)
      throw graphError("insertEdge(): a vertex is not in the graph.");
	else if (pos1 == pos2)
		// we do not allow self-loops
		throw graphError("graph insertEdge(): self-loops are not allowed");

	// make sure the edge does not already exist
	if (edge[pos1][pos2] == 0)
	{
		// assign weight to the edge
		edge[pos1][pos2] = weight;
		// the out-degree of v1 increases by 1 and the in-degree
		// of v2 increases by 1
		vInfo[pos1].outDegree++;
		vInfo[pos2].inDegree++;
		// increment the number of edges
		numEdges++;
	}
}

template <typename T>
void graph<T>::insertVertex(const T& v)
{
	int index;

	if (numVertices + 1 > MAXGRAPHSIZE)
		throw graphError("graph insertVertex(): graph full");

	// attempt to insert v into the map with index 0.
	// if successful, insert an iterator pointing at it
	// into the vertex list at location index. index is obtained
	// from the availability stack or by creating a new entry
	// at the back of the vector. fix the map entry to refer
	// to index and increment numVertices. if the insertion did
	// not take place, the vertex already exists. generate an
	// exception
	pair<vertexMap::iterator, bool> result =
		vtxMap.insert(vertexMap::value_type(v,0));

	if (result.second)
	{
		// see if there is an entry in vInfo freed by an earlier
		// call to eraseVertex()
		if (!availStack.empty())
		{
			// yes. get its index
			index = availStack.top();
			availStack.pop();
			// assign the new vInfo entry
			vInfo[index] = vertexInfo<T>(result.first);
		}
		else
		{
			// no. we'll have to increase the size of vInfo
			vInfo.push_back(vertexInfo<T>(result.first));
			index = numVertices;
		}

		(*result.first).second = index;
		numVertices++;
	}
	else
		throw graphError("graph insertVertex(): vertex already in the graph");
}

template <typename T>
void graph<T>::eraseEdge(const T& v1, const T& v2)
{
   int pos1=getVertexPos(v1), pos2=getVertexPos(v2);

   if (pos1 == -1 || pos2 == -1)
      throw graphError("eraseEdge(): a vertex is not in the graph.");

	// clear the weight in the matrix
	edge[pos1][pos2] = 0;

	// the out-degree of v1 decreases by 1
	vInfo[pos1].outDegree--;
	// the in-degree of v2 decreases by 1
	vInfo[pos2].inDegree--;

	// the total number of edges decreases
	numEdges--;
}

// delete a vertex from vertex list and update the adjacency
// matrix to remove all edges linked to the vertex.
template <typename T>
void graph<T>::eraseVertex(const T& v)
{
	// use to search for and remove v from the map
	vertexMap::iterator mIter;
	// pos is index of v in the vertex list and its row
	// index in the matrix
	int pos, j;

	// search the map for the key v
	mIter = vtxMap.find(v);
	// if vertex is not present, terminate the erase
	if (mIter == vtxMap.end())
		// if v not in list of vertices, throw an exception
		throw graphError("graph eraseVertex(): vertex not in the graph");

	// obtain the index of v in vInfo
	pos = (*mIter).second;

	// put 0 entries in row pos and column pos, adjusting other data
	// as necessary
	for (j=0;j < numVertices;j++)
	{
		// no need to consider edge[pos][pos]
		if (j != pos)
		{
			// if an edge originates at v, decrement
			// in in-degree of the destination vertex
			if (edge[pos][j] != 0)
				vInfo[j].inDegree--;

			// if an edge terminates at v, decrement the
			// out-degree of the source vertex
			if (edge[j][pos] != 0)
				vInfo[j].outDegree--;
		}

		// clear the weights
		edge[pos][j] = 0;
		edge[j][pos] = 0;
	}

	// decrease tha number of edges by the number of edges originating
	// and terminating at v
	numEdges -= vInfo[pos].outDegree;
	numEdges -= vInfo[pos].inDegree;

	// erase vertex from the map and decrement number of vertices
	vtxMap.erase(mIter);
	numVertices--;

	// mark the vertex entry in vInfo as not occupied. the index pos is now
	// available. push it on the availability stack for use later if we
	// insert a vertex
	vInfo[pos].occupied = false;
	availStack.push(pos);
}

template <typename T>
void graph<T>::clear()
{
	int i, j;

	// clear the vertex list, vertex map, the
	// availability stack, and the entries of
	// the adjacency matrix
	vInfo.erase(vInfo.begin(), vInfo.end());

	vtxMap.erase(vtxMap.begin(), vtxMap.end());

	while(!availStack.empty())
		availStack.pop();

	for (i=0;i<MAXGRAPHSIZE;i++)
		for (j=0;j < MAXGRAPHSIZE;j++)
			edge[i][j] = 0;

	// set the number of vertices and edges to 0
	numVertices = 0;
	numEdges = 0;
}

// ITERATOR FUNCTIONS

// each graph iterator function returns
// the corresponding map iterator
template <typename T>
graph<T>::iterator graph<T>::begin()
{
  return graph<T>::iterator(vtxMap.begin());
}

template <typename T>
graph<T>::iterator graph<T>::end()
{
	return graph<T>::iterator(vtxMap.end());
}

template <typename T>
graph<T>::const_iterator graph<T>::begin() const
{
	return graph<T>::iterator(vtxMap.begin());
}

template <typename T>
graph<T>::const_iterator graph<T>::end() const
{
  return graph<T>::iterator(vtxMap.end());
}

#endif   // GRAPH_CLASS
