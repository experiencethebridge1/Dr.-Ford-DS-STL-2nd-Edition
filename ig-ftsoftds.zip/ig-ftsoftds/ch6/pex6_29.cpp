#include <iostream>
#include <list>

#include "d_random.h"

using namespace std;

// return the number of occurrences of item in aList
template <typename T>
int count(const list<T>& aList, const T& item);

int main()
{	
	list<int> intList;
	randomNumber rnd;
	int i, rndNumber;

	cout << "Generating 20 random integers in range from 0 to 4:"
		  << endl;
	// initialize intList with 20 random integers
	// in the range from 0 to 4
	for (i=0;i < 20;i++)
	{
		rndNumber = rnd.random(5);
		intList.push_back(rndNumber);
		cout << rndNumber << " ";
	}
	cout << endl << endl;

	// output the number of 0's, 1's, and so forth,
	// using count()
	cout << "Count totals:" << endl;
	for (i=0;i < 5;i++)
		cout << i << ": " << count(intList, i)
			  << endl;

	return 0;
}

template <typename T>
int count(const list<T>& aList, const T& item)
{
	int numOccurrences = 0;
	list<T>::const_iterator iter;

	// scan the list using iter
	iter = aList.begin();
	while (iter != aList.end())
	{
		// if *iter matches item, increment numOccurrences
		if (*iter == item)
			numOccurrences++;

		// move iter forward
		iter++;
	}
	// return the number of occurrences of item
	return numOccurrences;
}

/*
Run:

Generating 20 random integers in range from 0 to 4:
2 0 4 3 2 3 1 3 0 3 2 1 1 4 2 1 1 4 2 2

Count totals:
0: 2
1: 5
2: 6
3: 4
4: 3
*/
