#ifndef	ACCUMULATOR_CLASS
#define ACCUMULATOR_CLASS

#include <iostream>

using namespace std;

class accumulator
{
	public:
      // constructor initializes total 
		accumulator (int value = 0) : total(value)
		{}

		// access function 
      int getTotal()
		{
			return total;
		}

      // update the data member total
		void addValue(int value)
		{
			total += value;
		}

		// add value to the total in the current object
		accumulator& operator+= (int value);

		// return an object whose total is the negative of that in
		// the current object
		accumulator operator- ();

		// add two objects by adding their totals
		friend accumulator operator+
						(const accumulator& lhs, const accumulator& rhs);

		// output an object
		friend ostream& operator<< (ostream& ostr,
											 const accumulator& obj);

	private:
      // total accumulated by the object
      int total;
};

accumulator& accumulator::operator+= (int value)
{
	total += value;
	return *this;
}


accumulator accumulator::operator- ()
{
	return accumulator(-total);
} 
 

accumulator operator+
			(const accumulator& lhs, const accumulator& rhs)
{
	return accumulator(lhs.total + rhs.total);
}

ostream& operator<< (ostream& ostr, const accumulator& obj)
{
	ostr << obj.total;

	return ostr;
}

#endif	// ACCUMULATOR_CLASS
