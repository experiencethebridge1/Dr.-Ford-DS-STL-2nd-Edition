#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// recursive function that uses dynamic programming to improve
// its effciency
int fDyn(int n, vector<int>& fList);

int main()
{
	// vector used by fDyn() to hold already computed values
	vector<int> fList(21);
	int n;

	for (n=1;n <= 20;n++)
	{
		// fill fList with 0
		fill(fList.begin(), fList.end(), 0);

		cout << n << ": " << fDyn(n, fList) << endl;
	}

	return 0;
}

int fDyn(int n, vector<int>& fList)
{
	int fValue;

	// check for a previously computed result and return
	if (fList[n] != 0)
		return fList[n];
	
	// otherwise execute the recursive algorithm to obtain the result
	if (n == 1 || n == 2)						// stopping conditions
		fValue = 1;
	else
		fValue = 2*fDyn(n-1,fList) + 3*fDyn(n-2,fList);	// recursive step
	
	// store the result and return its value
	fList[n] = fValue;

	return fValue; 
}

/*
Run:

1: 1
2: 1
3: 5
4: 13
5: 41
6: 121
7: 365
8: 1093
9: 3281
10: 9841
11: 29525
12: 88573
13: 265721
14: 797161
15: 2391485
16: 7174453
17: 21523361
18: 64570081
19: 193710245
20: 581130733
*/
