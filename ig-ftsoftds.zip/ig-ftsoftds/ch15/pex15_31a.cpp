#include <iostream>

#include "d_util.h"	// for manipulator setreal()

using namespace std;

// use bisection to approximate the root of f() between
// a and b
double bisect(double f(double x),
				  double a, double b, double precision);

// f(x) = x^3 -2x - 3
double f(double x);

int main()
{
	double root;

	// find the root of f() between 1 and 2 using precision = 1.0e-15
	root = bisect(f, 1.0, 2.0, 1.0e-15);

	cout << "The root of x^3 - 2x - 3 between 1 and 2 is approximately "
		  << setreal(1,10) << root << endl;

	return 0;
}

double bisect(double f(double x),
				  double a, double b, double precision)
{
	double m;

	// m is the midpoint of a < x < b
	m = (a+b)/2.0;

	// if m is a root or the length of our interval has
	// become small enough, return m
	if (f(m) == 0.0 || (b-a) < precision)
		return m;
	else if (f(a) * f(m) < 0)
		// the root in the the interval a < x < m
		return bisect(f, a, m, precision);
	else
		// the root is in the interval m < x < b
		return bisect(f, m, b, precision);
}

double f(double x)
{
	return x*x*x -2.0*x - 3.0;
}

/*
Run:

The root of x^3 - 2x - 3 between 1 and 2 is approximately 1.8932891963
*/
