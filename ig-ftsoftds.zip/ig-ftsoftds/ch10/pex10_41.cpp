#include <iostream>

#include "d_stree.h"

using namespace std;

// counts the number of stree values in the iterator range
// [first, last)
template <typename T>
int count(stree<T>::iterator first,
			 stree<T>::iterator last);

int main()
{
	// tree intTree has values from the array intArr5
	int intArr[] = {22, 19, 87, 42, 9, 17, 1, 56, 48, 75};
	int arrSize = sizeof(intArr)/sizeof(int);
	stree<int> t(intArr, intArr+arrSize);
	// declare an integer tree iterator
	stree<int>::iterator iter;

	// output the number of tree elements using size()
	cout << "The number of elements in the tree using size() is "
		  << t.size() << endl;

	// output the number of tree elements using count()
	cout << "The number of elements in the tree using count() is "
		  << count<int>(t.begin(), t.end()) << endl;

	// output the number of elements in the range [9,42). use find()
	// to determine the iterator range
	cout << "The number of elements in the range [9,42) is "
		  << count<int>(t.find(9), t.find(42)) << endl;

   return 0;
}

template <typename T>
int count(stree<T>::iterator first,
				 stree<T>::iterator last)
{
	int total = 0;

	// increment total for each value in the range [first, last)
	while (first != last)
	{
		total++;
		first++;
	}

	return total;
}

/*
Run:

The number of elements in the tree using size() is 10
The number of elements in the tree using count() is 10
The number of elements in the range  [9,42) is 4
*/
